# -*- coding: utf-8 -*-
"""리트젠 영업 CRM 도우미.

사용자는 이 파일을 직접 실행할 필요가 없습니다.
Claude가 채팅 명령을 받아 아래 명령을 대신 실행합니다.

  py crm.py init                         폴더·엑셀 파일 생성 (이미 있으면 그대로 둠)
  py crm.py add <json파일>               고객/상담 등록 (중복 확인 후 신규·업데이트·확인필요)
  py crm.py import-visitors <엑셀> --event 전시회명 [--date 방문일]
  py crm.py find [조건...]               고객 검색
  py crm.py update-customer <고객ID> 필드=값 ...
  py crm.py resolve-review <확인ID> (--merge 고객ID | --new | --skip)
  py crm.py catalogs                     03_제품자료 폴더 → 제품자료목록 갱신
  py crm.py match-catalog <고객ID>       고객에게 맞는 카탈로그 확인
  py crm.py draft <json파일>             메일 초안 등록 (중복·동의·첨부 검사)
  py crm.py test-mail                    테스트 메일 초안 만들기 (내 메일 주소로)
  py crm.py send-check <메일ID...>       발송 직전 최종 검사 → Gmail 발송용 정보 출력
  py crm.py mark-sent <메일ID> --gmail-id <ID>
  py crm.py mark-failed <메일ID> --reason "사유"
  py crm.py mark-reply <메일ID> [--followup Y|N]
  py crm.py cancel-draft <메일ID>
  py crm.py test-ok                      테스트 수신 확인 → 실제 발송 활성화
  py crm.py auto-select                  자동 모드: 승인된 범위의 대상자 선별
  py crm.py status                       메일 발송 현황
  py crm.py tasks [--all]                남은 할 일(후속할일.xlsx)
  py crm.py task-add <json> / task-done <T-ID...> [--cancel] / task-update <T-ID> 기한=YYYY-MM-DD 할 일=...
  py crm.py todo [--date D] [--json]     매일 알림 내용 (오늘/기한 지남/회신 대응)
  py crm.py weekly [--date D] [--json]   월요일 주간 보고 내용
  py crm.py notify-test [--label 이름]   내 알림 주소로 보낼 테스트 메일 내용
  py crm.py notify-log daily|weekly|test --date D --gmail-id ID   알림 발송 기록(중복 방지)
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import json
import re
import shutil
import sys
from pathlib import Path

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

# ───────────────────────────── 경로 ─────────────────────────────
import os

# CRM_BASE 환경변수는 테스트용 (평소에는 이 파일의 두 단계 위 폴더 = 업무 폴더)
BASE = Path(os.environ.get("CRM_BASE") or Path(__file__).resolve().parents[2])
D_CONSULT = BASE / "01_상담자료"
D_VISIT = BASE / "02_방문자리스트"
D_PROD = BASE / "03_제품자료"
D_CUST = BASE / "04_고객관리"
D_MAIL = BASE / "05_메일관리"
D_CONF = BASE / "06_자동화설정"
D_DRAFT = D_MAIL / "초안"
D_SENT = D_MAIL / "발송완료"
D_BACKUP = D_CONF / "백업"
D_TEMP = D_CONF / "임시"

F_CUST = D_CUST / "고객통합리스트.xlsx"
F_CONS = D_CUST / "상담이력.xlsx"
F_MAIL = D_MAIL / "메일발송이력.xlsx"
F_PROD = D_PROD / "제품자료목록.xlsx"
F_TASK = D_CUST / "후속할일.xlsx"
F_SET = D_CONF / "발송설정.json"
F_LOG = D_CONF / "처리기록.json"

# ───────────────────────────── 열 정의 ─────────────────────────────
CUST_COLS = ["고객 ID", "전시회명", "방문일", "회사명", "이름", "직급", "이메일", "연락처",
             "관심 제품", "고객 구분", "영업 우선순위", "담당자", "진행 상태", "최종 연락일", "비고",
             "분류 근거", "국가", "언어", "수신 동의", "발송 제외", "자료 출처", "등록일", "수정일"]
REVIEW_COLS = ["확인 ID", "등록일", "확인 사유", "후보 고객 ID", "신규 자료 요약", "자료 출처",
               "처리 상태", "처리 결과", "원본 데이터(수정 금지)"]
CONS_COLS = ["상담 ID", "고객 ID", "상담일", "회사명", "이름", "관심 제품", "상담 내용", "고객 요구사항",
             "요청 자료", "후속 조치", "다음 연락 예정일", "자료 출처", "등록일"]
MAIL_COLS = ["고객 ID", "회사명", "이름", "이메일", "메일 제목", "메일 본문", "첨부파일", "발송일",
             "발송 상태", "실패 사유", "회신 여부", "후속 연락 필요 여부",
             "메일 ID", "메일 목적", "메일 유형", "Gmail 메시지 ID", "작성일", "회신일"]
TASK_COLS = ["할일 ID", "고객 ID", "회사명", "고객 담당자", "할 일", "기한", "구분", "상태", "관련 ID", "메모",
             "등록일", "완료일"]
PROD_COLS = ["제품군", "파일명", "언어", "최종 수정일", "최신 여부", "파일 경로", "비고"]

WIDE = {"메일 본문": 60, "상담 내용": 55, "고객 요구사항": 35, "비고": 40, "분류 근거": 40,
        "신규 자료 요약": 45, "원본 데이터(수정 금지)": 30, "확인 사유": 35, "후속 조치": 30,
        "요청 자료": 25, "메일 제목": 40, "첨부파일": 35, "파일 경로": 50, "파일명": 40,
        "이메일": 28, "회사명": 20, "관심 제품": 20, "전시회명": 22, "실패 사유": 25, "Gmail 메시지 ID": 22,
        "할 일": 45, "메모": 30}
WRAP = {"메일 본문", "상담 내용", "고객 요구사항", "비고", "분류 근거", "신규 자료 요약", "확인 사유", "후속 조치",
        "할 일", "메모"}

PRIORITY_FILL = {"A": "F8CBAD", "B": "FFE699", "C": "DDEBF7", "확인 필요": "D9D9D9"}
STATUS_FILL = {"발송완료": "C6EFCE", "발송실패": "FFC7CE", "초안": "FFF2CC", "취소": "D9D9D9"}

PURPOSES = ["방문감사", "제품소개", "상담후속", "요청자료전달", "카탈로그전달", "샘플테스트제안",
            "견적후속", "후속연락", "테스트"]
# 고객이 요청한 내용에 대한 회신 → 거래관계/요청응답 메일 (광고성 아님)
REQUEST_PURPOSES = {"상담후속", "요청자료전달", "견적후속"}
CONSULT_WORDS = ["상담", "말씀하신", "말씀해 주신", "논의", "미팅에서", "문의하신", "요청하신",
                 "discussed", "our conversation", "our discussion", "consultation", "our meeting",
                 "you mentioned", "you asked", "you requested", "as requested"]

DEFAULT_SETTINGS = {
    "발송모드": "수동",
    "테스트발송완료": False,
    "테스트수신주소": "",
    "발송계정": "Gmail (Claude Gmail 커넥터)",
    "회사정보": {
        "회사명": "리트젠",
        "회사명_영문": "LICHTZEN",
        "담당자": "",
        "담당자_영문": "",
        "직함": "",
        "전화": "",
        "주소": "",
        "홈페이지": "",
    },
    "자동발송조건": {
        "설명": "발송모드가 '자동'일 때만 사용. 비어 있는 항목은 '제한 없음'이 아니라 '해당 없음'으로 처리되어 아무에게도 보내지 않습니다.",
        "허용_메일목적": [],
        "허용_영업우선순위": [],
        "허용_전시회명": [],
        "허용_관심제품": [],
        "1회_최대발송수": 20,
    },
    "광고성메일_야간발송금지": True,
    "알림수신주소": "",
    "알림주소확인": False,
}

EMAIL_RE = re.compile(r"[A-Za-z0-9._%+\-']+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}")


# ───────────────────────────── 공통 도구 ─────────────────────────────
def die(msg: str) -> None:
    print(f"[중단] {msg}")
    sys.exit(1)


def today() -> str:
    return dt.date.today().isoformat()


def now() -> str:
    return dt.datetime.now().strftime("%Y-%m-%d %H:%M")


def s(v) -> str:
    if v is None:
        return ""
    if isinstance(v, dt.datetime):
        return v.strftime("%Y-%m-%d %H:%M") if (v.hour or v.minute) else v.strftime("%Y-%m-%d")
    if isinstance(v, dt.date):
        return v.isoformat()
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v).strip()


def parse_date(v) -> dt.date | None:
    v = s(v)
    m = re.search(r"(\d{4})[-./년\s]+(\d{1,2})[-./월\s]+(\d{1,2})", v)
    if not m:
        return None
    try:
        return dt.date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
    except ValueError:
        return None


def norm_date(v) -> str:
    d = parse_date(v)
    return d.isoformat() if d else s(v)


def norm_email(v) -> str:
    v = s(v).lower().replace("mailto:", "").strip(" <>;,")
    return v if EMAIL_RE.fullmatch(v) else ""


def phone_digits(v) -> str:
    d = re.sub(r"\D", "", s(v))
    if d.startswith("82") and len(d) >= 11:
        d = "0" + d[2:]
    return d


def fmt_phone(v) -> str:
    d = phone_digits(v)
    if re.fullmatch(r"01\d{8,9}", d):
        return f"{d[:3]}-{d[3:-4]}-{d[-4:]}"
    return s(v)


def is_mobile(d: str) -> bool:
    return bool(re.fullmatch(r"01\d{8,9}", d)) or (len(d) >= 10 and not d.startswith("0"))


def norm_company(v) -> str:
    v = s(v).lower()
    for t in ["주식회사", "(주)", "㈜", "（주）", "유한회사", "co.,ltd", "co., ltd", "co.ltd", "co ltd",
              "corporation", "corp.", "corp", "inc.", "inc", "ltd.", "ltd", "limited", "gmbh", "llc"]:
        v = v.replace(t, "")
    return re.sub(r"[\s.,\-_()&]", "", v)


def norm_name(v) -> str:
    return re.sub(r"[\s.,\-]", "", s(v).lower())


def has_hangul(v) -> bool:
    return bool(re.search(r"[가-힣]", s(v)))


def join_unique(*vals: str) -> str:
    out: list[str] = []
    for v in vals:
        for part in re.split(r"\s*[,/]\s*", s(v)):
            if part and part.lower() not in [o.lower() for o in out]:
                out.append(part)
    return ", ".join(out)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def load_json(path: Path, default):
    if path.exists():
        with open(path, encoding="utf-8-sig") as f:  # 메모장 저장(BOM)도 허용
            return json.load(f)
    return default


def save_json(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def settings() -> dict:
    cur = load_json(F_SET, {})
    merged = json.loads(json.dumps(DEFAULT_SETTINGS))
    for k, v in cur.items():
        if isinstance(v, dict) and isinstance(merged.get(k), dict):
            merged[k].update(v)
        else:
            merged[k] = v
    return merged


def next_id(prefix: str, rows: list[dict], col: str) -> str:
    n = 0
    for r in rows:
        m = re.fullmatch(rf"{prefix}-(\d+)", s(r.get(col)))
        if m:
            n = max(n, int(m.group(1)))
    return f"{prefix}-{n + 1:04d}"


# ───────────────────────────── 엑셀 읽기/쓰기 ─────────────────────────────
def read_sheet(path: Path, sheet: str) -> list[dict]:
    if not path.exists():
        return []
    wb = load_workbook(path)
    if sheet not in wb.sheetnames:
        return []
    ws = wb[sheet]
    header = [s(c.value) for c in ws[1]]
    rows = []
    for r in ws.iter_rows(min_row=2, values_only=True):
        if all(v in (None, "") for v in r):
            continue
        rows.append({h: s(v) for h, v in zip(header, r) if h})
    return rows


def backup(path: Path) -> None:
    if not path.exists():
        return
    D_BACKUP.mkdir(parents=True, exist_ok=True)
    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    shutil.copy2(path, D_BACKUP / f"{path.stem}_{stamp}{path.suffix}")
    olds = sorted(D_BACKUP.glob(f"{path.stem}_*{path.suffix}"))
    for old in olds[:-30]:  # 파일별 최근 30개만 보관
        old.unlink()


def write_book(path: Path, sheets: list[tuple[str, list[str], list[dict]]]) -> None:
    wb = Workbook()
    wb.remove(wb.active)
    thin = Side(style="thin", color="BFBFBF")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    head_fill = PatternFill("solid", fgColor="1F4E78")
    for name, cols, rows in sheets:
        ws = wb.create_sheet(name)
        ws.append(cols)
        for r in rows:
            ws.append([r.get(c, "") for c in cols])
        for i, c in enumerate(cols, 1):
            cell = ws.cell(row=1, column=i)
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = head_fill
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            cell.border = border
            ws.column_dimensions[cell.column_letter].width = WIDE.get(c, 14)
        for row in ws.iter_rows(min_row=2):
            for cell in row:
                col = cols[cell.column - 1]
                cell.border = border
                cell.alignment = Alignment(vertical="top", wrap_text=col in WRAP)
                if col == "영업 우선순위" and s(cell.value) in PRIORITY_FILL:
                    cell.fill = PatternFill("solid", fgColor=PRIORITY_FILL[s(cell.value)])
                if col == "발송 상태" and s(cell.value) in STATUS_FILL:
                    cell.fill = PatternFill("solid", fgColor=STATUS_FILL[s(cell.value)])
                if col == "처리 상태" and s(cell.value) == "대기":
                    cell.fill = PatternFill("solid", fgColor="FFC7CE")
        ws.row_dimensions[1].height = 30
        ws.freeze_panes = "C2"
        last = ws.cell(row=1, column=len(cols)).column_letter
        ws.auto_filter.ref = f"A1:{last}{max(ws.max_row, 1)}"
    path.parent.mkdir(parents=True, exist_ok=True)
    backup(path)
    try:
        wb.save(path)
    except PermissionError:
        die(f"'{path.name}' 파일이 엑셀에서 열려 있어 저장하지 못했습니다. 파일을 닫은 뒤 다시 요청해 주세요. (변경 내용은 저장되지 않았습니다)")


class Data:
    """세 개의 엑셀 파일을 한 번에 읽고 저장."""

    def __init__(self) -> None:
        self.customers = read_sheet(F_CUST, "고객목록")
        self.reviews = read_sheet(F_CUST, "확인필요")
        self.consults = read_sheet(F_CONS, "상담이력")
        self.mails = read_sheet(F_MAIL, "메일발송이력")
        self.tasks = read_sheet(F_TASK, "후속할일")

    def cust(self, cid: str) -> dict | None:
        return next((c for c in self.customers if c.get("고객 ID") == cid), None)

    def refresh_types(self) -> None:
        consulted = {c.get("고객 ID") for c in self.consults}
        for c in self.customers:
            c["고객 구분"] = "상담 고객" if c.get("고객 ID") in consulted else "일반 방문객"

    def save(self, cust=True, cons=False, mail=False, task=False) -> None:
        # 저장 전에 열려 있는 파일이 없는지 먼저 확인 → 일부만 저장되는 상황 방지
        targets = [p for p, flag in ((F_CUST, cust), (F_CONS, cons), (F_MAIL, mail), (F_TASK, task)) if flag]
        for p in targets:
            if p.exists():
                try:
                    with open(p, "r+b"):
                        pass
                except PermissionError:
                    die(f"'{p.name}' 파일이 엑셀에서 열려 있습니다. 닫은 뒤 다시 요청해 주세요. (아무것도 저장하지 않았습니다)")
        if cust:
            self.refresh_types()
            write_book(F_CUST, [("고객목록", CUST_COLS, self.customers), ("확인필요", REVIEW_COLS, self.reviews)])
        if cons:
            write_book(F_CONS, [("상담이력", CONS_COLS, self.consults)])
        if mail:
            write_book(F_MAIL, [("메일발송이력", MAIL_COLS, self.mails)])
        if task:
            write_book(F_TASK, [("후속할일", TASK_COLS, self.tasks)])

    def add_task(self, cid: str, todo: str, due: str, kind: str = "다음 연락", ref: str = "", memo: str = "") -> str:
        """할 일 1건 추가. 같은 고객·같은 할 일·같은 기한의 대기 건이 있으면 추가하지 않음."""
        c = self.cust(cid) or {}
        todo, due = s(todo), norm_date(due)
        for t in self.tasks:
            if t.get("고객 ID") == cid and t.get("상태") == "대기" and t.get("할 일") == todo and t.get("기한") == due:
                return f"(이미 있는 할 일 {t['할일 ID']})"
        tid = next_id("T", self.tasks, "할일 ID")
        self.tasks.append({"할일 ID": tid, "고객 ID": cid, "회사명": c.get("회사명", ""), "고객 담당자": c.get("이름", ""),
                           "할 일": todo, "기한": due, "구분": kind, "상태": "대기", "관련 ID": ref, "메모": memo,
                           "등록일": now(), "완료일": ""})
        return tid


# ───────────────────────────── 제품 / 카탈로그 ─────────────────────────────
CATEGORY_RULES = [  # (제품군, 정규식) — 위에서부터 우선
    ("UV 경화기", r"경화|curing|(?<![a-z])cur(e|er)(?![a-z])"),
    ("222nm", r"(?<!\d)222(?!\d)"),
    ("254nm", r"(?<!\d)254(?!\d)"),
    ("UV Lamp", r"lamp|램프"),
    ("UV LED", r"(?<![a-z])led(?![a-z])|uvled"),
    ("종합", r"종합|회사소개|company|general|brochure|corporate|overview"),
]


def detect_categories(text: str, first_only=False) -> list[str]:
    t = re.sub(r"[_\-]", " ", s(text).lower())
    found = [cat for cat, pat in CATEGORY_RULES if re.search(pat, t)]
    return found[:1] if first_only else found


def detect_lang(filename: str) -> str:
    t = filename.lower()
    if re.search(r"(^|[_\-\s(\[])(en|eng|english)([_\-\s)\].]|$)|영문", t):
        return "영어"
    if re.search(r"(^|[_\-\s(\[])(kr|ko|kor|korean)([_\-\s)\].]|$)|국문|한글", t):
        return "한국어"
    return "공통"


def scan_catalogs() -> tuple[list[dict], list[str]]:
    D_PROD.mkdir(parents=True, exist_ok=True)
    old = {r.get("파일 경로"): r for r in read_sheet(F_PROD, "제품자료목록")}
    rows = []
    for f in sorted(D_PROD.rglob("*")):
        if not f.is_file() or f.name.startswith("~$") or f.resolve() == F_PROD.resolve():
            continue
        if f.suffix.lower() not in {".pdf", ".pptx", ".ppt", ".docx", ".doc", ".jpg", ".jpeg", ".png", ".zip"}:
            continue
        cats = detect_categories(f.stem, first_only=True)
        rows.append({
            "제품군": cats[0] if cats else "미분류",
            "파일명": f.name,
            "언어": detect_lang(f.stem),
            "최종 수정일": dt.datetime.fromtimestamp(f.stat().st_mtime).strftime("%Y-%m-%d %H:%M"),
            "파일 경로": str(f.relative_to(BASE)),
            "비고": "" if cats else "파일명에 제품군(222nm/254nm/UV LED/UV Lamp/경화기/종합)을 넣어 주세요",
            "_mtime": f.stat().st_mtime,
        })
    # 제품군+언어별 가장 최근 파일 = 최신
    best: dict[tuple, dict] = {}
    for r in rows:
        key = (r["제품군"], r["언어"])
        if r["제품군"] != "미분류" and (key not in best or r["_mtime"] > best[key]["_mtime"]):
            best[key] = r
    for r in rows:
        r["최신 여부"] = "Y" if best.get((r["제품군"], r["언어"])) is r else ("" if r["제품군"] == "미분류" else "이전본")
    changes = []
    new_paths = {r["파일 경로"] for r in rows}
    for r in rows:
        o = old.get(r["파일 경로"])
        if not o:
            changes.append(f"추가됨: {r['파일명']} ({r['제품군']})")
        elif o.get("최종 수정일") != r["최종 수정일"]:
            changes.append(f"변경됨: {r['파일명']}")
    for pth in old:
        if pth not in new_paths:
            changes.append(f"삭제됨: {Path(pth).name}")
    return rows, changes


def save_catalog_list(rows: list[dict]) -> None:
    write_book(F_PROD, [("제품자료목록", PROD_COLS, rows)])


def match_catalogs(cust: dict) -> tuple[list[Path], list[str]]:
    """고객 관심 제품 → 최신 공식 카탈로그 목록, 경고."""
    rows, _ = scan_catalogs()
    latest = [r for r in rows if r["최신 여부"] == "Y"]
    lang = cust.get("언어") or "한국어"
    cats = detect_categories(cust.get("관심 제품", ""))
    cats = [c for c in cats if c != "종합"]
    warnings = []
    if not cats:
        if s(cust.get("관심 제품")):
            warnings.append(f"관심 제품 '{cust.get('관심 제품')}'에 맞는 제품군이 없어 종합 카탈로그로 대체합니다.")
        cats = ["종합"]
    files: list[Path] = []
    for cat in cats:
        cands = [r for r in latest if r["제품군"] == cat]
        pick = (next((r for r in cands if r["언어"] == lang), None)
                or next((r for r in cands if r["언어"] == "공통"), None))
        if not pick and cands:
            pick = cands[0]
            warnings.append(f"{cat}: {lang} 카탈로그가 없어 {pick['언어']}본을 사용합니다.")
        if not pick:
            warnings.append(f"[첨부 누락] '{cat}' 카탈로그가 03_제품자료 폴더에 없습니다.")
            continue
        p = BASE / pick["파일 경로"]
        if p not in files:
            files.append(p)
    return files, warnings


# ───────────────────────────── 분류 ─────────────────────────────
A_WORDS = ["견적", "테스트", "샘플", "구매", "발주", "도입", "단가", "가격", "납기", "계약", "시제품",
           "quote", "quotation", "sample", "samples", "test", "testing", "trial", "purchase", "price", "pricing", "poc"]
B_WORDS = ["사양", "스펙", "기술", "문의", "성능", "적용", "데이터시트", "자료", "검토",
           "spec", "specs", "specification", "technical", "datasheet", "performance", "application", "inquiry"]


def word_hits(words: list[str], text: str) -> list[str]:
    out = []
    for w in words:
        pat = rf"(?<![a-z]){re.escape(w)}(?![a-z])" if w.isascii() else re.escape(w)
        if re.search(pat, text):
            out.append(w)
    return out


def auto_priority(cust: dict, consults: list[dict]) -> tuple[str, str]:
    text = " ".join([" ".join(s(c.get(k)) for k in
                    ("상담 내용", "고객 요구사항", "요청 자료", "후속 조치")) for c in consults]).lower()
    if not (cust.get("이메일") or cust.get("연락처")) or not (cust.get("이름") or cust.get("회사명")):
        return "확인 필요", "자동: 이름/회사 또는 연락처(이메일·전화)가 부족함"
    a = word_hits(A_WORDS, text)
    if a:
        return "A", f"자동: 상담에 구매 신호 키워드({', '.join(a[:4])})"
    b = word_hits(B_WORDS, text)
    if b and consults:
        return "B", f"자동: 기술 문의 키워드({', '.join(b[:4])})"
    if consults and cust.get("관심 제품"):
        return "B", f"자동: 상담 기록 있음 + 관심 제품({cust.get('관심 제품')})"
    return "C", "자동: 일반 방문(구체적 상담·요청 없음)"


RANK = {"A": 3, "B": 2, "C": 1, "확인 필요": 0, "": -1}


def infer_country(rec: dict) -> tuple[str, str]:
    country = s(rec.get("국가"))
    if country:
        kr = country.replace(" ", "") in ("대한민국", "한국", "korea", "southkorea", "kr", "republicofkorea")
        return ("대한민국" if kr else country), ("한국어" if kr else "영어")
    d = phone_digits(rec.get("연락처"))
    email = norm_email(rec.get("이메일"))
    if has_hangul(rec.get("이름")) or has_hangul(rec.get("회사명")) or email.endswith(".kr") \
            or s(rec.get("연락처")).startswith("+82") or (d.startswith("0") and not s(rec.get("연락처")).startswith("+")):
        return "대한민국", "한국어"
    if email or d:
        return "해외(국가 미확인)", "영어"
    return "", ""


# ───────────────────────────── 중복 확인 · 등록 ─────────────────────────────
def same_script(a: str, b: str) -> bool:
    return has_hangul(a) == has_hangul(b)


def find_match(rec: dict, customers: list[dict]):
    """반환: ('update', 고객, 근거) | ('review', [후보ID], 사유) | ('new', None, 메모)"""
    e = norm_email(rec.get("이메일"))
    ph = phone_digits(rec.get("연락처"))
    nm = norm_name(rec.get("이름"))
    co = norm_company(rec.get("회사명"))

    if e:
        hit = [c for c in customers if norm_email(c.get("이메일")) == e]
        if hit:
            c = hit[0]
            cn = norm_name(c.get("이름"))
            if nm and cn and nm != cn and same_script(rec.get("이름"), c.get("이름")):
                return "review", [c["고객 ID"]], f"이메일은 같지만 이름이 다름 ({c.get('이름')} ↔ {rec.get('이름')}) — 공용 메일 가능성"
            return "update", c, "이메일 일치"
    if ph and is_mobile(ph):
        hit = [c for c in customers if phone_digits(c.get("연락처")) == ph]
        if hit:
            c = hit[0]
            ce = norm_email(c.get("이메일"))
            if e and ce and e != ce:
                return "review", [c["고객 ID"]], "휴대전화는 같지만 이메일이 다름"
            if (nm and nm == norm_name(c.get("이름"))) or (co and co == norm_company(c.get("회사명"))):
                return "update", c, "휴대전화 + 이름/회사 일치"
            return "review", [c["고객 ID"]], "휴대전화는 같지만 이름·회사가 다름"
    if nm and co:
        hit = [c for c in customers if norm_name(c.get("이름")) == nm and norm_company(c.get("회사명")) == co]
        if hit:
            c = hit[0]
            ce, cp = norm_email(c.get("이메일")), phone_digits(c.get("연락처"))
            if (e and ce and e != ce) or (ph and cp and ph != cp and is_mobile(ph) and is_mobile(cp)):
                return "review", [c["고객 ID"]], "이름·회사는 같지만 이메일/전화가 다름 (이직·변경 또는 다른 사람)"
            return "update", c, "이름 + 회사명 일치 (식별정보 충돌 없음)"
    if nm and not e and not ph:
        hit = [c for c in customers if norm_name(c.get("이름")) == nm]
        if hit:
            return "review", [c["고객 ID"] for c in hit], "이름만 같은 고객이 있음 (이메일·전화 없어 판단 불가)"
    if not (nm or co or e):
        return "review", [], "이름·회사·이메일이 모두 없어 고객을 특정할 수 없음"
    note = ""
    if nm and any(norm_name(c.get("이름")) == nm for c in customers):
        note = "동명이인 고객 있음(회사·연락처 다름)"
    return "new", None, note


def summarize(rec: dict) -> str:
    keys = ["전시회명", "회사명", "이름", "직급", "이메일", "연락처", "관심 제품"]
    return " / ".join(f"{k}:{rec[k]}" for k in keys if s(rec.get(k)))


CONSENT_Y = {"y", "yes", "예", "동의", "o", "true", "1", "동의함", "agree", "agreed"}
CONSENT_N = {"n", "no", "아니오", "아니요", "미동의", "거부", "x", "false", "0", "비동의", "disagree", "수신거부"}


def norm_consent(v) -> str:
    t = s(v).lower().replace(" ", "")
    if t in CONSENT_Y:
        return "Y"
    if t in CONSENT_N:
        return "N"
    return ""


def add_note(old: str, *new: str) -> str:
    out = s(old)
    for n in new:
        n = s(n)
        if n and n not in out:
            out = f"{out} / {n}" if out else n
    return out


def apply_record(data: Data, rec: dict, source: str, force_new: bool = False) -> str:
    """레코드 1건 처리. 결과 문자열 반환."""
    rec = {k: s(v) if not isinstance(v, (dict, list)) else v for k, v in rec.items()}
    raw_email = rec.get("이메일", "")
    if raw_email and not norm_email(raw_email):
        rec["비고"] = add_note(rec.get("비고", ""), f"이메일 형식 오류(원문: {raw_email})")
        rec["이메일"] = ""
    else:
        rec["이메일"] = norm_email(raw_email)
    rec["연락처"] = fmt_phone(rec.get("연락처", ""))
    rec["방문일"] = norm_date(rec.get("방문일", ""))
    rec["수신 동의"] = norm_consent(rec.get("수신 동의", ""))
    consult = rec.pop("상담", None)

    cid = rec.get("고객 ID", "")
    if cid:
        cust = data.cust(cid)
        if not cust:
            return f"실패: 고객 ID {cid} 없음"
        action, reason = "update", "고객 ID 직접 지정"
    elif force_new:
        action, cust, reason = "new", None, "확인 결과 별도 고객으로 등록"
    else:
        action, cust, reason = find_match(rec, data.customers)

    if action == "review":
        rid = next_id("R", data.reviews, "확인 ID")
        payload = dict(rec)
        if consult:
            payload["상담"] = consult
        data.reviews.append({
            "확인 ID": rid, "등록일": now(), "확인 사유": reason, "후보 고객 ID": ", ".join(cust or []),
            "신규 자료 요약": summarize(rec), "자료 출처": source, "처리 상태": "대기",
            "원본 데이터(수정 금지)": json.dumps(payload, ensure_ascii=False),
        })
        return f"확인필요 {rid}: {summarize(rec)} → {reason}"

    if action == "new":
        cid = next_id("C", data.customers, "고객 ID")
        country, lang = infer_country(rec)
        cust = {c: "" for c in CUST_COLS}
        cust.update({k: rec.get(k, "") for k in CUST_COLS if rec.get(k)})
        cust.update({"고객 ID": cid, "국가": rec.get("국가") or country, "언어": rec.get("언어") or lang,
                     "진행 상태": rec.get("진행 상태") or "신규", "자료 출처": source,
                     "등록일": now(), "수정일": now(), "발송 제외": rec.get("발송 제외", "")})
        if country == "대한민국" and not rec.get("국가"):
            cust["국가"] = "대한민국"
        if reason:
            cust["비고"] = add_note(cust.get("비고", ""), reason)
        if cust["수신 동의"] == "N":
            cust["발송 제외"] = "Y"
        data.customers.append(cust)
        result = f"신규 {cid}: {summarize(cust)}"
    else:
        cid = cust["고객 ID"]
        notes = []
        for k in ["회사명", "이름", "직급", "이메일", "연락처", "담당자", "국가", "언어"]:
            nv, ov = rec.get(k, ""), cust.get(k, "")
            if not nv:
                continue
            if not ov:
                cust[k] = nv
            elif k == "이메일" and norm_email(nv) != norm_email(ov):
                notes.append(f"다른 이메일 확인 필요: {nv}")
            elif k == "연락처" and phone_digits(nv) != phone_digits(ov):
                notes.append(f"다른 연락처 확인 필요: {nv}")
            elif k == "직급" and nv != ov:
                notes.append(f"직급 변경 {ov}→{nv}")
                cust[k] = nv
            elif k == "담당자" and nv != ov:
                cust[k] = nv
            elif k == "이름" and norm_name(nv) != norm_name(ov):
                notes.append(f"다른 이름 표기: {nv}")
            elif k == "회사명" and norm_company(nv) != norm_company(ov):
                notes.append(f"다른 회사명 표기: {nv}")
        cust["전시회명"] = join_unique(cust.get("전시회명", ""), rec.get("전시회명", ""))
        if rec.get("방문일"):
            cust["방문일"] = join_unique(cust.get("방문일", ""), rec["방문일"])
        cust["관심 제품"] = join_unique(cust.get("관심 제품", ""), rec.get("관심 제품", ""))
        if rec.get("진행 상태"):
            cust["진행 상태"] = rec["진행 상태"]
        if rec.get("수신 동의"):
            cust["수신 동의"] = rec["수신 동의"]
            if rec["수신 동의"] == "N":
                cust["발송 제외"] = "Y"
        if rec.get("발송 제외"):
            cust["발송 제외"] = rec["발송 제외"]
        cust["비고"] = add_note(cust.get("비고", ""), rec.get("비고", ""), *notes)
        cust["자료 출처"] = add_note(cust.get("자료 출처", ""), source)
        cust["수정일"] = now()
        result = f"업데이트 {cid} ({reason}): {summarize(cust)}" + (f" | 주의: {'; '.join(notes)}" if notes else "")

    # 상담 기록
    if consult:
        todos = consult.pop("할 일", None)  # [{"할 일": "...", "기한": "YYYY-MM-DD", "구분": "..."}]
        consult = {k: s(v) for k, v in consult.items()}
        sig = (cid, norm_date(consult.get("상담일") or today()), s(consult.get("상담 내용"))[:200])
        dup = any((c.get("고객 ID"), c.get("상담일"), s(c.get("상담 내용"))[:200]) == sig for c in data.consults)
        if dup:
            result += " | 같은 상담 내용이 이미 있어 상담이력은 추가하지 않음"
        else:
            sid = next_id("S", data.consults, "상담 ID")
            data.consults.append({
                "상담 ID": sid, "고객 ID": cid, "상담일": sig[1], "회사명": cust.get("회사명", ""),
                "이름": cust.get("이름", ""), "관심 제품": consult.get("관심 제품") or rec.get("관심 제품", ""),
                "상담 내용": consult.get("상담 내용", ""), "고객 요구사항": consult.get("고객 요구사항", ""),
                "요청 자료": consult.get("요청 자료", ""), "후속 조치": consult.get("후속 조치", ""),
                "다음 연락 예정일": norm_date(consult.get("다음 연락 예정일", "")), "자료 출처": source, "등록일": now(),
            })
            cust["최종 연락일"] = max(cust.get("최종 연락일", ""), sig[1])
            if cust.get("진행 상태") in ("", "신규"):
                cust["진행 상태"] = "상담 완료"
            result += f" | 상담 {sid} 등록"
            # 내가 할 일 → 후속할일 목록
            if not todos and (consult.get("후속 조치") or consult.get("다음 연락 예정일")):
                todos = [{"할 일": consult.get("후속 조치", ""), "기한": consult.get("다음 연락 예정일", "")}]
            made = []
            for t in (todos if isinstance(todos, list) else [todos] if todos else []):
                if isinstance(t, str):
                    t = {"할 일": t}
                made.append(data.add_task(cid, t.get("할 일", ""), t.get("기한", ""), t.get("구분") or "상담 후속", sid,
                                          t.get("메모", "")))
            if made:
                result += f" | 할 일 {', '.join(made)} 등록"

    # 우선순위 (Claude가 판단해 넘긴 값 우선, 없으면 키워드 자동)
    mine = [c for c in data.consults if c.get("고객 ID") == cid]
    if rec.get("영업 우선순위"):
        pr, why = rec["영업 우선순위"], rec.get("분류 근거") or "Claude 판단"
    else:
        pr, why = auto_priority(cust, mine)
    old = cust.get("영업 우선순위", "")
    if not old or old == "확인 필요" or RANK.get(pr, 0) >= RANK.get(old, 0) or rec.get("영업 우선순위"):
        cust["영업 우선순위"], cust["분류 근거"] = pr, f"[{today()}] {why}"
    return result + f" | 등급 {cust['영업 우선순위']}"


# ───────────────────────────── 명령: 등록/가져오기 ─────────────────────────────
def cmd_init(_):
    for d in [D_CONSULT / "명함사진", D_CONSULT / "상담기록", D_CONSULT / "녹음_녹취록", D_VISIT, D_PROD,
              D_CUST, D_DRAFT, D_SENT, D_BACKUP, D_TEMP]:
        d.mkdir(parents=True, exist_ok=True)
    made = []
    if not F_CUST.exists():
        write_book(F_CUST, [("고객목록", CUST_COLS, []), ("확인필요", REVIEW_COLS, [])]); made.append(F_CUST.name)
    if not F_CONS.exists():
        write_book(F_CONS, [("상담이력", CONS_COLS, [])]); made.append(F_CONS.name)
    if not F_MAIL.exists():
        write_book(F_MAIL, [("메일발송이력", MAIL_COLS, [])]); made.append(F_MAIL.name)
    if not F_PROD.exists():
        rows, _ = scan_catalogs(); save_catalog_list(rows); made.append(F_PROD.name)
    if not F_SET.exists():
        save_json(F_SET, DEFAULT_SETTINGS); made.append(F_SET.name)
    print("준비 완료." + (f" 새로 만든 파일: {', '.join(made)}" if made else " (모든 파일이 이미 있어 그대로 두었습니다)"))


def load_records(path: str) -> list[dict]:
    p = Path(path)
    if not p.exists():
        die(f"파일 없음: {path}")
    data = load_json(p, None)
    return data if isinstance(data, list) else [data]


def cmd_add(a):
    recs = load_records(a.json)
    data = Data()
    out = []
    for r in recs:
        src = s(r.pop("자료 출처", "")) or a.source or "채팅 입력"
        out.append(apply_record(data, r, src))
    data.save(cust=True, cons=True, task=True)
    print("\n".join(out))


SYNONYMS = {
    "이름": ["이름", "성명", "성함", "name", "fullname", "방문자명", "방문자", "담당자명", "참관객명"],
    "회사명": ["회사", "회사명", "기업명", "업체명", "소속", "소속기관", "기관명", "company", "companyname", "organization", "organisation"],
    "직급": ["직급", "직위", "직책", "title", "position", "jobtitle"],
    "부서": ["부서", "부서명", "department", "dept"],
    "이메일": ["이메일", "email", "e-mail", "메일", "이메일주소", "emailaddress", "mail"],
    "연락처": ["연락처", "전화", "전화번호", "휴대폰", "핸드폰", "휴대전화", "휴대폰번호", "phone", "mobile", "tel", "cellphone", "phonenumber"],
    "방문일": ["방문일", "방문일시", "스캔일시", "스캔시간", "스캔일", "등록일", "등록일시", "date", "scantime", "visitdate", "timestamp"],
    "관심 제품": ["관심제품", "관심분야", "관심품목", "interest", "interests", "product", "products", "interestedproduct"],
    "국가": ["국가", "country", "nation", "국적"],
    "수신 동의": ["수신동의", "마케팅동의", "마케팅수신동의", "광고수신동의", "정보수신동의", "이메일수신동의",
               "marketingconsent", "consent", "optin", "newsletter"],
    "비고": ["비고", "메모", "memo", "note", "notes", "comment", "comments"],
}


def header_key(h) -> str:
    t = re.sub(r"[\s_\-()\[\]]", "", s(h).lower())
    for k, syns in SYNONYMS.items():
        if t in [re.sub(r"[\s_\-]", "", x) for x in syns]:
            return k
    return ""


def read_table_file(path: Path) -> list[list]:
    if path.suffix.lower() == ".csv":
        for enc in ("utf-8-sig", "cp949"):
            try:
                with open(path, encoding=enc, newline="") as f:
                    return [row for row in csv.reader(f)]
            except UnicodeDecodeError:
                continue
        die("CSV 인코딩을 읽을 수 없습니다.")
    wb = load_workbook(path, read_only=True, data_only=True)
    ws = wb[wb.sheetnames[0]]
    return [list(r) for r in ws.iter_rows(values_only=True)]


def cmd_import(a):
    path = Path(a.file)
    if not path.is_absolute():
        path = (D_VISIT / path) if (D_VISIT / path).exists() else path.resolve()
    if not path.exists():
        die(f"파일 없음: {path}")
    log = load_json(F_LOG, {"가져온파일": {}})
    h = sha256(path)
    if h in log["가져온파일"] and not a.force:
        die(f"이 파일은 {log['가져온파일'][h]['일시']}에 이미 가져왔습니다. 다시 가져오려면 --force")
    table = read_table_file(path)
    hdr_idx, mapping = None, {}
    for i, row in enumerate(table[:15]):
        m = {j: header_key(v) for j, v in enumerate(row) if header_key(v)}
        if len(m) >= 2:
            hdr_idx, mapping = i, m
            break
    if hdr_idx is None:
        die("제목 행(이름/회사/이메일 등)을 찾지 못했습니다. Claude가 열 구성을 직접 확인해야 합니다.")
    unknown = [s(v) for j, v in enumerate(table[hdr_idx]) if s(v) and j not in mapping]
    data = Data()
    out, cnt = [], {"신규": 0, "업데이트": 0, "확인필요": 0}
    for row in table[hdr_idx + 1:]:
        rec: dict = {}
        for j, key in mapping.items():
            v = s(row[j]) if j < len(row) else ""
            if not v:
                continue
            if key == "부서":
                rec["비고"] = add_note(rec.get("비고", ""), f"부서: {v}")
            elif key == "비고":
                rec["비고"] = add_note(rec.get("비고", ""), v)
            elif key in rec:
                rec[key] = join_unique(rec[key], v)
            else:
                rec[key] = v
        if not any(rec.get(k) for k in ("이름", "회사명", "이메일", "연락처")):
            continue
        rec["전시회명"] = a.event or rec.get("전시회명", "")
        if a.date and not rec.get("방문일"):
            rec["방문일"] = a.date
        res = apply_record(data, rec, f"방문자리스트:{path.name}")
        cnt[res.split()[0]] = cnt.get(res.split()[0], 0) + 1
        out.append(res)
    data.save(cust=True, cons=False)
    log["가져온파일"][h] = {"파일": path.name, "일시": now(), "전시회명": a.event}
    save_json(F_LOG, log)
    print(f"가져오기 완료: {path.name} → 신규 {cnt.get('신규', 0)} / 업데이트 {cnt.get('업데이트', 0)} / 확인필요 {cnt.get('확인필요', 0)}")
    print(f"인식한 열: {', '.join(sorted(set(mapping.values())))}" + (f" | 인식 못한 열(무시됨): {', '.join(unknown)}" if unknown else ""))
    for o in out:
        print(" -", o)


def cmd_update_customer(a):
    data = Data()
    c = data.cust(a.id)
    if not c:
        die(f"고객 {a.id} 없음")
    for kv in a.fields:
        if "=" not in kv:
            die(f"'필드=값' 형식이 아님: {kv}")
        k, v = kv.split("=", 1)
        k = k.strip()
        if k not in CUST_COLS or k == "고객 ID":
            die(f"수정할 수 없는 필드: {k}")
        if k == "이메일" and v and not norm_email(v):
            die(f"이메일 형식 오류: {v}")
        if k == "수신 동의":
            v = norm_consent(v) or v
            if v == "N":
                c["발송 제외"] = "Y"
        if k == "영업 우선순위" and not any(x.startswith("분류 근거=") for x in a.fields):
            c["분류 근거"] = f"[{today()}] 담당자 지정"
        c[k] = v.strip()
    c["수정일"] = now()
    data.save(cust=True)
    print(f"{a.id} 수정 완료: " + ", ".join(a.fields))


def cmd_resolve(a):
    data = Data()
    r = next((x for x in data.reviews if x.get("확인 ID") == a.id), None)
    if not r:
        die(f"확인 항목 {a.id} 없음")
    if r.get("처리 상태") != "대기":
        die(f"{a.id}는 이미 처리됨: {r.get('처리 결과')}")
    rec = json.loads(r["원본 데이터(수정 금지)"])
    if a.skip:
        r["처리 상태"], r["처리 결과"] = "완료", f"[{now()}] 등록하지 않음"
        data.save(cust=True)
        print(f"{a.id}: 등록하지 않음으로 처리")
        return
    if a.merge:
        rec["고객 ID"] = a.merge
        res = apply_record(data, rec, r.get("자료 출처", "") + " (확인 후 통합)")
    else:
        res = apply_record(data, rec, r.get("자료 출처", "") + " (확인 후 신규)", force_new=True)
    r["처리 상태"], r["처리 결과"] = "완료", f"[{now()}] {res}"
    data.save(cust=True, cons=True, task=True)
    print(res)


# ───────────────────────────── 명령: 검색 ─────────────────────────────
def mail_sent_purposes(data: Data, cid: str) -> set[str]:
    return {m.get("메일 목적") for m in data.mails if m.get("고객 ID") == cid and m.get("발송 상태") == "발송완료"}


def cmd_find(a):
    data = Data()
    rows = data.customers
    t0 = dt.date.today()

    def contains(field, val):
        return lambda c: val.lower().replace(" ", "") in s(c.get(field)).lower().replace(" ", "")

    filters = []
    if a.name: filters.append(contains("이름", a.name))
    if a.company: filters.append(lambda c: norm_company(a.company) in norm_company(c.get("회사명")))
    if a.email: filters.append(contains("이메일", a.email))
    if a.event: filters.append(contains("전시회명", a.event))
    if a.priority: filters.append(lambda c: c.get("영업 우선순위") in a.priority.split(","))
    if a.type: filters.append(lambda c: c.get("고객 구분") == a.type)
    if a.product:
        cats = detect_categories(a.product)
        filters.append(lambda c: (set(cats) & set(detect_categories(c.get("관심 제품")))) if cats
                       else a.product.lower() in s(c.get("관심 제품")).lower())
    if a.added_today: filters.append(lambda c: s(c.get("등록일")).startswith(today()) or s(c.get("수정일")).startswith(today()))
    if a.no_mail:
        if a.no_mail == "any":
            filters.append(lambda c: not mail_sent_purposes(data, c["고객 ID"]))
        else:
            filters.append(lambda c: a.no_mail not in mail_sent_purposes(data, c["고객 ID"]))
    if a.consult_since or a.consult_until:
        since = parse_date(a.consult_since) or dt.date.min
        until = parse_date(a.consult_until) or dt.date.max
        ids = {cs["고객 ID"] for cs in data.consults if (d := parse_date(cs.get("상담일"))) and since <= d <= until}
        filters.append(lambda c: c["고객 ID"] in ids)
    if a.followup:
        due = set()
        for cs in data.consults:
            nd = parse_date(cs.get("다음 연락 예정일"))
            cd = parse_date(cs.get("상담일"))
            last = parse_date(data.cust(cs["고객 ID"]).get("최종 연락일")) if data.cust(cs["고객 ID"]) else None
            if nd and nd <= t0 and (not last or last < nd):
                due.add(cs["고객 ID"])
            elif not nd and cs.get("후속 조치") and cd and (not last or last <= cd):
                due.add(cs["고객 ID"])
        replies = {m["고객 ID"] for m in data.mails if m.get("후속 연락 필요 여부") == "Y"}
        filters.append(lambda c: c["고객 ID"] in due | replies)
    if not a.include_excluded and a.no_mail:
        filters.append(lambda c: c.get("발송 제외") != "Y")
    res = [c for c in rows if all(f(c) for f in filters)]
    order = {"A": 0, "B": 1, "C": 2, "확인 필요": 3}
    res.sort(key=lambda c: (order.get(c.get("영업 우선순위"), 9), c.get("고객 ID")))
    print(f"검색 결과 {len(res)}명")
    for c in res[: a.limit]:
        sent = ", ".join(sorted(mail_sent_purposes(data, c["고객 ID"]))) or "없음"
        flags = []
        if c.get("발송 제외") == "Y": flags.append("발송제외")
        if not c.get("이메일"): flags.append("이메일없음")
        print(f"- {c['고객 ID']} | {c.get('회사명')} | {c.get('이름')} {c.get('직급')} | {c.get('이메일')} | "
              f"관심:{c.get('관심 제품') or '-'} | {c.get('영업 우선순위')} | {c.get('고객 구분')} | {c.get('진행 상태')} | "
              f"최종연락:{c.get('최종 연락일') or '-'} | 발송한 메일:{sent} | 수신동의:{c.get('수신 동의') or '미확인'}"
              + (f" | ⚠{','.join(flags)}" if flags else ""))
        if a.detail:
            print(f"    분류 근거: {c.get('분류 근거')}  비고: {c.get('비고')}")
            for cs in [x for x in data.consults if x.get("고객 ID") == c["고객 ID"]]:
                print(f"    [{cs['상담 ID']} {cs.get('상담일')}] {cs.get('상담 내용')} | 요구:{cs.get('고객 요구사항')} | "
                      f"요청자료:{cs.get('요청 자료')} | 후속:{cs.get('후속 조치')} | 다음연락:{cs.get('다음 연락 예정일')}")
            for m in [x for x in data.mails if x.get("고객 ID") == c["고객 ID"]]:
                print(f"    [{m['메일 ID']}] {m.get('메일 목적')} | {m.get('발송 상태')} | {m.get('발송일')} | 회신:{m.get('회신 여부') or '-'}")
    if len(res) > a.limit:
        print(f"... 외 {len(res) - a.limit}명 (--limit 으로 더 보기)")
    pending = [r for r in data.reviews if r.get("처리 상태") == "대기"]
    if pending and a.show_reviews:
        print(f"\n확인 필요 {len(pending)}건")
        for r in pending:
            print(f"- {r['확인 ID']} | {r['확인 사유']} | 후보:{r.get('후보 고객 ID') or '-'} | {r['신규 자료 요약']}")


def cmd_reviews(_):
    data = Data()
    pending = [r for r in data.reviews if r.get("처리 상태") == "대기"]
    print(f"확인 필요 {len(pending)}건")
    for r in pending:
        print(f"- {r['확인 ID']} | {r['확인 사유']} | 후보:{r.get('후보 고객 ID') or '-'} | {r['신규 자료 요약']}")
        for cid in [x.strip() for x in s(r.get("후보 고객 ID")).split(",") if x.strip()]:
            c = data.cust(cid)
            if c:
                print(f"    후보 {cid}: {summarize(c)}")


# ───────────────────────────── 명령: 카탈로그 ─────────────────────────────
def cmd_catalogs(_):
    rows, changes = scan_catalogs()
    save_catalog_list(rows)
    print(f"제품자료 {len(rows)}개 확인. 변경 사항: " + ("; ".join(changes) if changes else "없음"))
    for r in rows:
        print(f"- [{r['제품군']}/{r['언어']}] {r['파일명']} | 최신:{r['최신 여부'] or '-'} | {r['최종 수정일']}"
              + (f" | {r['비고']}" if r["비고"] else ""))
    have = {r["제품군"] for r in rows if r["최신 여부"] == "Y"}
    missing = [c for c, _ in CATEGORY_RULES if c not in have]
    if missing:
        print("아직 없는 카탈로그: " + ", ".join(missing))


def cmd_match(a):
    data = Data()
    c = data.cust(a.id)
    if not c:
        die(f"고객 {a.id} 없음")
    files, warns = match_catalogs(c)
    print(f"{a.id} {c.get('회사명')} {c.get('이름')} | 관심 제품: {c.get('관심 제품') or '없음'} | 언어: {c.get('언어')}")
    for f in files:
        print(f"- 첨부: {f.name}")
    for w in warns:
        print(f"- ⚠ {w}")


# ───────────────────────────── 명령: 메일 ─────────────────────────────
def signature(lang: str) -> str:
    ci = settings()["회사정보"]
    if lang == "영어":
        lines = [ci.get("담당자_영문") or ci.get("담당자"), ci.get("직함"), ci.get("회사명_영문") or ci.get("회사명"),
                 ci.get("전화"), ci.get("홈페이지")]
    else:
        lines = [f"{ci.get('회사명')} {ci.get('담당자')} {ci.get('직함')}".strip(), ci.get("전화"), ci.get("주소"), ci.get("홈페이지")]
    return "\n".join(x for x in lines if s(x))


def ad_footer(lang: str, cust: dict) -> str:
    ci = settings()["회사정보"]
    if lang == "영어":
        return ("\n\n---\nThis email was sent by {co} ({tel}) to recipients who agreed to receive information. "
                "To unsubscribe, simply reply with \"Unsubscribe\".").format(co=ci.get("회사명_영문") or ci.get("회사명"), tel=ci.get("전화"))
    return ("\n\n---\n본 메일은 정보 수신에 동의하신 분께 발송되었습니다. 보낸 곳: {co} (연락처 {tel})\n"
            "더 이상 수신을 원하지 않으시면 이 메일에 '수신거부'라고 회신해 주세요.").format(co=ci.get("회사명"), tel=ci.get("전화"))


def mail_type(data: Data, cust: dict, purpose: str) -> str:
    if purpose == "테스트":
        return "테스트"
    consults = [c for c in data.consults if c.get("고객 ID") == cust["고객 ID"]]
    if purpose in REQUEST_PURPOSES and consults:
        return "요청응답"
    return "광고성"


def validate_mail(data: Data, m: dict, cust: dict | None, for_send: bool) -> list[str]:
    errs = []
    st = settings()
    purpose = m.get("메일 목적")
    is_test = purpose == "테스트"
    email = norm_email(m.get("이메일"))
    if not email:
        errs.append("이메일 주소가 없거나 형식이 잘못됨 (이메일을 임의로 만들지 않습니다)")
    if not is_test:
        if not cust:
            return errs + ["고객 정보 없음"]
        if norm_email(cust.get("이메일")) != email:
            errs.append("메일 주소가 고객통합리스트의 이메일과 다름")
        if cust.get("발송 제외") == "Y":
            errs.append("발송 제외(수신거부 포함) 고객")
        if purpose not in PURPOSES:
            errs.append(f"메일 목적은 다음 중 하나여야 함: {', '.join(PURPOSES)}")
        dup = [x for x in data.mails if x.get("고객 ID") == cust["고객 ID"] and x.get("메일 목적") == purpose
               and x.get("발송 상태") in ("초안", "발송완료") and x.get("메일 ID") != m.get("메일 ID")]
        if dup:
            errs.append(f"같은 목적({purpose}) 메일이 이미 있음: {dup[0]['메일 ID']} ({dup[0]['발송 상태']})")
        dup_addr = [x for x in data.mails if norm_email(x.get("이메일")) == email and x.get("메일 목적") == purpose
                    and x.get("고객 ID") != cust["고객 ID"] and x.get("발송 상태") in ("초안", "발송완료")]
        if email and dup_addr:
            errs.append(f"같은 이메일 주소로 같은 목적 메일이 이미 있음 (공용 메일): {dup_addr[0]['메일 ID']} → {dup_addr[0].get('이름')}")
        consults = [c for c in data.consults if c.get("고객 ID") == cust["고객 ID"]]
        if not consults:
            text = (m.get("메일 제목", "") + " " + m.get("메일 본문", "")).lower()
            used = [w for w in CONSULT_WORDS if w.lower() in text]
            if used:
                errs.append(f"상담 기록이 없는 고객인데 상담을 전제한 표현이 있음: {', '.join(used)}")
            if purpose in ("상담후속", "견적후속"):
                errs.append("상담 기록이 없는 고객에게 '상담후속/견적후속' 메일 불가")
        if m.get("메일 유형") == "광고성":
            if cust.get("수신 동의") != "Y":
                errs.append("광고성 메일인데 수신 동의(Y)가 확인되지 않음 → 고객통합리스트의 '수신 동의'를 확인해 주세요")
            if not m.get("메일 제목", "").startswith("(광고)"):
                errs.append("광고성 메일 제목은 '(광고)'로 시작해야 함")
    # 첨부
    for f in [x for x in s(m.get("첨부파일")).split(" | ") if x]:
        if not (BASE / f).exists():
            errs.append(f"첨부파일 없음: {f}")
    if m.get("_첨부필수") and not s(m.get("첨부파일")):
        errs.append("첨부파일이 누락됨")
    if for_send:
        if not st.get("테스트발송완료") and not is_test:
            errs.append("테스트 발송이 아직 완료되지 않아 실제 고객에게 보낼 수 없음 (먼저 '테스트 메일 보내줘')")
        if is_test and email != norm_email(st.get("테스트수신주소")):
            errs.append("테스트 메일은 발송설정.json의 '테스트수신주소'로만 보낼 수 있음")
        if m.get("발송 상태") not in ("초안", "발송실패"):
            errs.append(f"발송 상태가 '{m.get('발송 상태')}'라 보낼 수 없음 (초안·발송실패 건만 발송 가능)")
        h = dt.datetime.now().hour
        if m.get("메일 유형") == "광고성" and st.get("광고성메일_야간발송금지", True) and (h >= 21 or h < 8):
            errs.append("광고성 메일은 21시~다음날 8시 사이 발송 금지 (8시 이후 다시 요청)")
        ci = st["회사정보"]
        if not is_test and not (ci.get("담당자") and ci.get("전화")):
            errs.append("발송설정.json의 회사정보(담당자·전화)가 비어 있음 — 서명/발신자 정보가 필요")
    return errs


def write_draft_file(m: dict) -> Path:
    D_DRAFT.mkdir(parents=True, exist_ok=True)
    safe = re.sub(r'[<>:"/\\|?*\s]', "_", f"{m['메일 ID']}_{m.get('회사명')}_{m.get('이름')}")[:80]
    p = D_DRAFT / f"{safe}.txt"
    p.write_text(
        f"메일 ID: {m['메일 ID']}\n고객 ID: {m['고객 ID']}\n받는 사람: {m.get('이름')} <{m['이메일']}> ({m.get('회사명')})\n"
        f"목적: {m.get('메일 목적')} / 유형: {m.get('메일 유형')}\n첨부: {m.get('첨부파일') or '없음'}\n"
        f"제목: {m['메일 제목']}\n{'-' * 60}\n{m['메일 본문']}\n", encoding="utf-8")
    return p


def cmd_draft(a):
    recs = load_records(a.json)
    ci = settings()["회사정보"]
    if not (ci.get("담당자") and ci.get("전화")):
        die("발송설정.json의 회사정보(담당자 이름·전화번호)가 비어 있어 메일 서명과 발신자 정보를 넣을 수 없습니다. "
            "먼저 담당자 이름과 회사 전화번호를 알려주세요.")
    data = Data()
    out = []
    for r in recs:
        r = {k: s(v) if not isinstance(v, list) else v for k, v in r.items()}
        purpose = r.get("메일 목적", "")
        cust = data.cust(r.get("고객 ID", ""))
        if not cust:
            out.append(f"[실패] 고객 {r.get('고객 ID')} 없음"); continue
        lang = cust.get("언어") or "한국어"
        m = {c: "" for c in MAIL_COLS}
        m.update({"메일 ID": next_id("M", data.mails, "메일 ID"), "고객 ID": cust["고객 ID"], "회사명": cust.get("회사명"),
                  "이름": cust.get("이름"), "이메일": cust.get("이메일"), "메일 목적": purpose,
                  "메일 제목": r.get("메일 제목", ""), "메일 본문": r.get("메일 본문", "").rstrip(), "발송 상태": "초안",
                  "작성일": now()})
        m["메일 유형"] = mail_type(data, cust, purpose)
        if m["메일 유형"] == "광고성" and not m["메일 제목"].startswith("(광고)"):
            m["메일 제목"] = "(광고) " + m["메일 제목"]
        sig = signature(lang)
        if sig and sig not in m["메일 본문"]:
            m["메일 본문"] += "\n\n" + sig
        if m["메일 유형"] == "광고성":
            m["메일 본문"] += ad_footer(lang, cust)
        warns = []
        att = r.get("첨부파일", "자동")
        if att in ("없음", "none"):
            files = []
        elif att == "자동" or att == "":
            files, warns = match_catalogs(cust)
            m["_첨부필수"] = True
            if any(w.startswith("[첨부 누락]") for w in warns):
                out.append(f"[실패] {cust['고객 ID']} {cust.get('이름')}: " + "; ".join(w for w in warns if w.startswith("[첨부 누락]"))
                           + " → 카탈로그를 03_제품자료에 넣은 뒤 다시 요청해 주세요")
                continue
        else:
            names = att if isinstance(att, list) else [x.strip() for x in att.split(",")]
            files = []
            for n in names:
                cand = [f for f in D_PROD.rglob("*") if f.is_file() and f.name == n]
                files.append(cand[0] if cand else D_PROD / n)
            m["_첨부필수"] = True
        m["첨부파일"] = " | ".join(str(f.relative_to(BASE)) for f in files)
        errs = validate_mail(data, m, cust, for_send=False)
        if errs:
            out.append(f"[실패] {cust['고객 ID']} {cust.get('이름')}: " + "; ".join(errs))
            continue
        m.pop("_첨부필수", None)
        data.mails.append(m)
        p = write_draft_file(m)
        out.append(f"[초안] {m['메일 ID']} → {cust.get('이름')} <{m['이메일']}> | {m['메일 유형']} | 제목: {m['메일 제목']} | "
                   f"첨부: {', '.join(f.name for f in files) or '없음'} | 미리보기: {p.relative_to(BASE)}"
                   + (f" | ⚠ {'; '.join(warns)}" if warns else ""))
    data.save(cust=False, mail=True)
    print("\n".join(out))


def cmd_test_mail(_):
    st = settings()
    to = norm_email(st.get("테스트수신주소"))
    if not to:
        die("발송설정.json에 '테스트수신주소'가 없습니다.")
    data = Data()
    if any(m.get("메일 목적") == "테스트" and m.get("발송 상태") == "초안" for m in data.mails):
        die("이미 발송 대기 중인 테스트 메일 초안이 있습니다: " +
            ", ".join(m["메일 ID"] for m in data.mails if m.get("메일 목적") == "테스트" and m.get("발송 상태") == "초안"))
    files, warns = match_catalogs({"관심 제품": "", "언어": "한국어"})
    if not files:  # 카탈로그가 아직 없으면 첨부 기능 확인용 작은 파일을 사용
        f = D_CONF / "테스트첨부.txt"
        f.write_text("리트젠 CRM 첨부파일 테스트입니다.\n", encoding="utf-8")
        files = [f]
    m = {c: "" for c in MAIL_COLS}
    m.update({"메일 ID": next_id("M", data.mails, "메일 ID"), "고객 ID": "TEST", "회사명": "(테스트)", "이름": "테스트 수신자",
              "이메일": to, "메일 목적": "테스트", "메일 유형": "테스트", "발송 상태": "초안", "작성일": now(),
              "메일 제목": "[리트젠 CRM 테스트] 메일 연동 확인",
              "메일 본문": "리트젠 영업 CRM 메일 연동 테스트입니다.\n\n이 메일과 첨부파일이 정상적으로 도착했다면 Claude 채팅창에 "
                         "'테스트 메일 잘 받았어'라고 알려주세요. 그 후 실제 고객 발송이 가능해집니다.\n\n" + signature("한국어"),
              "첨부파일": " | ".join(str(f.relative_to(BASE)) for f in files)})
    data.mails.append(m)
    write_draft_file(m)
    data.save(cust=False, mail=True)
    print(f"테스트 초안 {m['메일 ID']} → {to} | 첨부: {', '.join(f.name for f in files)}")


def cmd_send_check(a):
    data = Data()
    ids = a.ids
    out, ok = [], []
    for mid in ids:
        m = next((x for x in data.mails if x.get("메일 ID") == mid), None)
        if not m:
            out.append({"메일 ID": mid, "발송가능": False, "사유": ["메일 ID 없음"]}); continue
        cust = data.cust(m.get("고객 ID"))
        errs = validate_mail(data, m, cust, for_send=True)
        # 같은 묶음 안에서 같은 고객·같은 목적 중복 방지
        key = (m.get("고객 ID"), m.get("메일 목적"))
        if m.get("메일 목적") != "테스트" and key in [(o["고객 ID"], o["메일 목적"]) for o in ok]:
            errs.append("이번 발송 묶음 안에 같은 고객·같은 목적 메일이 중복됨")
        if errs:
            out.append({"메일 ID": mid, "발송가능": False, "사유": errs}); continue
        atts = []
        for f in [x for x in s(m.get("첨부파일")).split(" | ") if x]:
            p = (BASE / f).resolve()
            atts.append({"filename": p.name, "content": f"sha256:{sha256(p)}:{p.as_posix()}",
                         "mimeType": MIME.get(p.suffix.lower(), "application/octet-stream")})
        item = {"메일 ID": mid, "발송가능": True, "고객 ID": m.get("고객 ID"), "메일 목적": m.get("메일 목적"),
                "to": [norm_email(m["이메일"])], "subject": m["메일 제목"], "body": m["메일 본문"], "attachments": atts}
        ok.append(item)
        out.append(item)
    print(json.dumps(out, ensure_ascii=False, indent=1))


MIME = {".pdf": "application/pdf", ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".zip": "application/zip", ".txt": "text/plain"}


def find_mail(data: Data, mid: str) -> dict:
    m = next((x for x in data.mails if x.get("메일 ID") == mid), None)
    if not m:
        die(f"메일 {mid} 없음")
    return m


def cmd_mark_sent(a):
    data = Data()
    m = find_mail(data, a.id)
    if m.get("발송 상태") == "발송완료":
        die(f"{a.id}는 이미 발송완료 상태입니다.")
    if not a.gmail_id:
        die("Gmail 메시지 ID가 없으면 발송완료로 기록하지 않습니다 (실제 발송 성공 확인 필요).")
    if m.get("메일 목적") != "테스트" and not settings().get("테스트발송완료"):
        die("테스트 발송이 완료되지 않은 상태에서는 고객 메일을 발송완료로 기록할 수 없습니다.")
    m.update({"발송 상태": "발송완료", "발송일": now(), "Gmail 메시지 ID": a.gmail_id, "실패 사유": "", "회신 여부": "N"})
    cust = data.cust(m.get("고객 ID"))
    if cust:
        cust["최종 연락일"] = today()
        if cust.get("진행 상태") in ("", "신규", "상담 완료"):
            cust["진행 상태"] = "메일 발송"
        cust["수정일"] = now()
    for p in D_DRAFT.glob(f"{a.id}_*.txt"):
        D_SENT.mkdir(parents=True, exist_ok=True)
        shutil.move(str(p), D_SENT / p.name)
    extra = []
    for tid in a.done or []:
        t = next((x for x in data.tasks if x.get("할일 ID") == tid), None)
        if t and t.get("상태") == "대기":
            t.update({"상태": "완료", "완료일": now(), "메모": add_note(t.get("메모", ""), f"{a.id} 발송으로 완료")})
            extra.append(f"할 일 {tid} 완료")
    if a.next and cust:
        extra.append("후속 할 일 " + data.add_task(cust["고객 ID"], a.next, a.due or "", "발송 후 후속", a.id))
    data.save(cust=bool(cust), mail=True, task=True)
    print(f"{a.id} 발송완료 기록 (Gmail ID {a.gmail_id})" + (" | " + ", ".join(extra) if extra else ""))


def cmd_mark_failed(a):
    data = Data()
    m = find_mail(data, a.id)
    if m.get("발송 상태") == "발송완료":
        die(f"{a.id}는 이미 발송완료 상태입니다.")
    m.update({"발송 상태": "발송실패", "실패 사유": f"[{now()}] {a.reason}"})
    data.save(cust=False, mail=True)
    print(f"{a.id} 발송실패 기록: {a.reason}")


def cmd_mark_reply(a):
    data = Data()
    m = find_mail(data, a.id)
    m["회신 여부"] = "Y"
    m["회신일"] = norm_date(a.date) if a.date else today()
    if a.followup:
        m["후속 연락 필요 여부"] = a.followup
    cust = data.cust(m.get("고객 ID"))
    tid = ""
    if cust and not a.unsubscribe and a.followup != "N":
        tid = data.add_task(cust["고객 ID"], a.todo or "회신 내용 확인 후 답변", a.due or m["회신일"], "회신 대응", a.id)
    if cust:
        cust["진행 상태"] = "회신 받음"
        cust["수정일"] = now()
        if a.unsubscribe:
            cust["발송 제외"], cust["수신 동의"] = "Y", "N"
            cust["비고"] = add_note(cust.get("비고", ""), f"{today()} 수신거부 회신")
            for t in data.tasks:  # 수신거부 고객의 남은 메일 관련 할 일은 메모만 남김(삭제하지 않음)
                if t.get("고객 ID") == cust["고객 ID"] and t.get("상태") == "대기":
                    t["메모"] = add_note(t.get("메모", ""), f"{today()} 수신거부 회신 — 메일 연락 금지")
    data.save(cust=bool(cust), mail=True, task=True)
    print(f"{a.id} 회신 기록" + (" + 수신거부 처리" if a.unsubscribe else "") + (f" | 회신 대응 할 일 {tid}" if tid else ""))


def cmd_cancel(a):
    data = Data()
    m = find_mail(data, a.id)
    if m.get("발송 상태") != "초안":
        die(f"{a.id}는 초안이 아니라 취소할 수 없습니다 ({m.get('발송 상태')})")
    m["발송 상태"] = "취소"
    for p in D_DRAFT.glob(f"{a.id}_*.txt"):
        p.unlink()
    data.save(cust=False, mail=True)
    print(f"{a.id} 초안 취소")


def cmd_test_ok(_):
    data = Data()
    sent = [m for m in data.mails if m.get("메일 목적") == "테스트" and m.get("발송 상태") == "발송완료"]
    if not sent:
        die("발송완료된 테스트 메일이 없습니다. 먼저 테스트 메일을 보내야 합니다.")
    st = load_json(F_SET, DEFAULT_SETTINGS)
    st["테스트발송완료"] = True
    st["테스트완료일시"] = now()
    save_json(F_SET, st)
    print("테스트 확인 완료 → 실제 고객 발송이 활성화되었습니다 (현재 모드: " + st.get("발송모드", "수동") + ")")


def cmd_auto_select(a):
    st = settings()
    if st.get("발송모드") != "자동":
        die("현재 발송모드가 '수동'입니다. 자동 발송을 하려면 먼저 사용자가 자동 모드와 조건을 승인해야 합니다.")
    if not st.get("테스트발송완료"):
        die("테스트 발송이 완료되지 않았습니다.")
    cond = st["자동발송조건"]
    purposes = cond.get("허용_메일목적") or []
    if not purposes:
        die("자동발송조건에 '허용_메일목적'이 비어 있어 대상이 없습니다.")
    data = Data()
    res = []
    for c in data.customers:
        if c.get("발송 제외") == "Y" or not norm_email(c.get("이메일")):
            continue
        if cond.get("허용_영업우선순위") and c.get("영업 우선순위") not in cond["허용_영업우선순위"]:
            continue
        if cond.get("허용_전시회명") and not any(e in c.get("전시회명", "") for e in cond["허용_전시회명"]):
            continue
        if cond.get("허용_관심제품"):
            want = set(sum((detect_categories(x) for x in cond["허용_관심제품"]), []))
            if not want & set(detect_categories(c.get("관심 제품"))):
                continue
        has = {(m.get("메일 목적")) for m in data.mails if m.get("고객 ID") == c["고객 ID"] and m.get("발송 상태") in ("초안", "발송완료")}
        for p in purposes:
            if p in has:
                continue
            consulted = any(x.get("고객 ID") == c["고객 ID"] for x in data.consults)
            if p in ("상담후속", "견적후속") and not consulted:
                continue
            if mail_type(data, c, p) == "광고성" and c.get("수신 동의") != "Y":
                continue
            res.append((c, p))
            break
    limit = int(cond.get("1회_최대발송수") or 20)
    print(f"자동 발송 대상 {len(res)}명 (이번 회차 최대 {limit}명)")
    for c, p in res[:limit]:
        print(f"- {c['고객 ID']} | {c.get('회사명')} | {c.get('이름')} | {c.get('이메일')} | 목적:{p} | "
              f"{c.get('고객 구분')} | 관심:{c.get('관심 제품') or '-'} | 언어:{c.get('언어')}")


def cmd_status(_):
    data = Data()
    st = settings()
    cnt: dict[str, int] = {}
    for m in data.mails:
        if m.get("메일 목적") == "테스트":
            continue
        cnt[m.get("발송 상태")] = cnt.get(m.get("발송 상태"), 0) + 1
    print(f"발송모드: {st.get('발송모드')} | 테스트 발송 완료: {'예' if st.get('테스트발송완료') else '아니오 (실제 고객 발송 잠김)'}")
    print(f"고객 {len(data.customers)}명 (A {sum(c.get('영업 우선순위') == 'A' for c in data.customers)} / "
          f"B {sum(c.get('영업 우선순위') == 'B' for c in data.customers)} / C {sum(c.get('영업 우선순위') == 'C' for c in data.customers)} / "
          f"확인 필요 {sum(c.get('영업 우선순위') == '확인 필요' for c in data.customers)}) | 상담 {len(data.consults)}건 | "
          f"확인필요 대기 {sum(r.get('처리 상태') == '대기' for r in data.reviews)}건")
    print("메일: " + (", ".join(f"{k} {v}건" for k, v in cnt.items()) or "아직 없음"))
    print(f"회신 받음 {sum(m.get('회신 여부') == 'Y' for m in data.mails)}건 | 후속 연락 필요 {sum(m.get('후속 연락 필요 여부') == 'Y' for m in data.mails)}건")
    for m in data.mails:
        if m.get("발송 상태") == "발송실패":
            print(f"- 실패 {m['메일 ID']} {m.get('이름')} <{m.get('이메일')}>: {m.get('실패 사유')}")
        if m.get("발송 상태") == "초안":
            print(f"- 대기 중인 초안 {m['메일 ID']} {m.get('이름')} | {m.get('메일 목적')} | {m.get('메일 제목')}")
    never = [c for c in data.customers if not mail_sent_purposes(data, c["고객 ID"]) and c.get("발송 제외") != "Y"]
    print(f"아직 메일을 한 번도 받지 않은 고객 {len(never)}명")
    print(f"남은 할 일 {sum(t.get('상태') == '대기' for t in data.tasks)}건")


# ───────────────────────────── 명령: 할 일 · 알림 · 주간 보고 ─────────────────────────────
WD = ["월", "화", "수", "목", "금", "토", "일"]


def ko_date(v) -> str:
    d = parse_date(v)
    return f"{d.isoformat()}({WD[d.weekday()]})" if d else "일정 미정"


def find_task(data: Data, tid: str) -> dict:
    t = next((x for x in data.tasks if x.get("할일 ID") == tid), None)
    if not t:
        die(f"할 일 {tid} 없음")
    return t


def cmd_task_add(a):
    data = Data()
    out = []
    for r in load_records(a.json):
        cid = s(r.get("고객 ID"))
        if not data.cust(cid):
            out.append(f"[실패] 고객 {cid} 없음"); continue
        out.append(data.add_task(cid, r.get("할 일", ""), r.get("기한", ""), r.get("구분") or "다음 연락",
                                 s(r.get("관련 ID")), s(r.get("메모"))))
    data.save(cust=False, task=True)
    print("할 일 등록: " + ", ".join(out))


def cmd_task_done(a):
    data = Data()
    for tid in a.ids:
        t = find_task(data, tid)
        t.update({"상태": "취소" if a.cancel else "완료", "완료일": now()})
        if a.note:
            t["메모"] = add_note(t.get("메모", ""), a.note)
    data.save(cust=False, task=True)
    print(("취소" if a.cancel else "완료") + " 처리: " + ", ".join(a.ids))


def cmd_task_update(a):
    data = Data()
    t = find_task(data, a.id)
    if t.get("상태") != "대기":
        die(f"{a.id}는 이미 {t.get('상태')} 상태입니다.")
    for kv in a.fields:
        k, _, v = kv.partition("=")
        k = k.strip()
        if k not in ("할 일", "기한", "구분", "메모"):
            die(f"수정할 수 없는 항목: {k} (할 일/기한/구분/메모만 가능)")
        if k == "기한" and v and not parse_date(v):
            die(f"날짜 형식 오류: {v} (YYYY-MM-DD)")
        if k == "기한" and t.get("기한") != norm_date(v):
            t["메모"] = add_note(t.get("메모", ""), f"{today()} 기한 변경 {t.get('기한') or '미정'}→{norm_date(v) or '미정'}")
        t[k] = norm_date(v) if k == "기한" else v.strip()
    data.save(cust=False, task=True)
    print(f"{a.id} 수정: " + ", ".join(a.fields))


def open_tasks(data: Data) -> list[dict]:
    ok = []
    for t in data.tasks:
        if t.get("상태") != "대기":
            continue
        c = data.cust(t.get("고객 ID")) or {}
        t = dict(t)
        t["회사명"] = c.get("회사명") or t.get("회사명")
        t["고객 담당자"] = c.get("이름") or t.get("고객 담당자")
        ok.append(t)
    return ok


def task_line(t: dict) -> str:
    who = " ".join(x for x in [t.get("회사명"), t.get("고객 담당자")] if x) or "(업체 미상)"
    memo = f" ※{t['메모']}" if "수신거부" in s(t.get("메모")) else ""
    return f"{who} / {t.get('할 일') or '확인 필요'} / {ko_date(t.get('기한'))}{memo}"


def cmd_tasks(a):
    data = Data()
    rows = data.tasks if a.all else open_tasks(data)
    rows = sorted(rows, key=lambda t: (t.get("기한") or "9999", t.get("할일 ID")))
    print(f"할 일 {len(rows)}건" + (" (전체)" if a.all else " (남은 것)"))
    for t in rows:
        print(f"- {t['할일 ID']} [{t.get('상태')}/{t.get('구분')}] {task_line(t)} | 관련:{t.get('관련 ID') or '-'}")


def notify_target() -> tuple[str, str]:
    st = settings()
    to = norm_email(st.get("알림수신주소"))
    if not to:
        return "", "발송설정.json에 '알림수신주소'가 없습니다."
    if not st.get("알림주소확인"):
        return "", "알림수신주소가 아직 사용자 확인 전입니다."
    return to, ""


def notify_sent(kind: str, d: str) -> str:
    log = load_json(F_LOG, {})
    return s(log.get("알림발송", {}).get(f"{kind}:{d}", {}).get("일시"))


def emit(kind: str, d: dt.date, subject: str, body: str, has_content: bool, as_json: bool, force: bool) -> None:
    to, why = notify_target()
    send, reason = True, ""
    if not has_content:
        send, reason = False, "오늘은 알릴 할 일이 없어 메일을 보내지 않습니다."
    elif not to:
        send, reason = False, why
    elif notify_sent(kind, d.isoformat()) and not force:
        send, reason = False, f"이미 {notify_sent(kind, d.isoformat())}에 보냈습니다."
    if as_json:
        print(json.dumps({"보낼메일": send, "사유": reason, "종류": kind, "기준일": d.isoformat(),
                          "to": [to] if to else [], "subject": subject, "body": body}, ensure_ascii=False, indent=1))
    else:
        print(f"[{'발송 대상' if send else '발송 안 함'}] {reason}\n받는 사람: {to or '-'}\n제목: {subject}\n{'-' * 50}\n{body}")


def ref_date(v: str) -> dt.date:
    return parse_date(v) if v else dt.date.today()


def cmd_todo(a):
    """매일 알림: 오늘 연락할 업체 / 기한 지난 업체 / 회신 대응할 업체."""
    d = ref_date(a.date)
    data = Data()
    tasks = open_tasks(data)
    reply = [t for t in tasks if t.get("구분") == "회신 대응"]
    rest = [t for t in tasks if t.get("구분") != "회신 대응"]
    due_today = [t for t in rest if parse_date(t.get("기한")) == d]
    overdue = [t for t in rest if (x := parse_date(t.get("기한"))) and x < d]
    key = lambda t: (t.get("기한") or "9999", t.get("할일 ID"))
    lines = [f"{d.isoformat()}({WD[d.weekday()]}) 리트젠 CRM 후속 알림", ""]
    for title, rows in (("■ 오늘 연락할 업체", due_today), ("■ 기한이 지난 업체", overdue), ("■ 회신에 대응할 업체", reply)):
        if rows:
            lines.append(f"{title} ({len(rows)}건)")
            lines += [f"- {task_line(t)}" for t in sorted(rows, key=key)]
            lines.append("")
    lines.append("형식: 업체명 / 내가 할 일 / 기한")
    has = bool(due_today or overdue or reply)
    subject = f"[리트젠 CRM] {d.month}/{d.day}({WD[d.weekday()]}) 오늘 할 일 {len(due_today) + len(overdue) + len(reply)}건"
    emit("daily", d, subject, "\n".join(lines), has, a.json, a.force)


def cmd_weekly(a):
    """월요일 보고: 이번 주 할 일·밀린 일 → 지난주 활동 → 진행 중 업체별 다음 조치."""
    d = ref_date(a.date)
    mon = d - dt.timedelta(days=d.weekday())
    sun = mon + dt.timedelta(days=6)
    lmon, lsun = mon - dt.timedelta(days=7), mon - dt.timedelta(days=1)
    data = Data()
    tasks = open_tasks(data)
    key = lambda t: (t.get("기한") or "9999", t.get("할일 ID"))
    in_last = lambda v: (x := parse_date(v)) is not None and lmon <= x <= lsun
    this_week = [t for t in tasks if (x := parse_date(t.get("기한"))) and d <= x <= sun]
    overdue = [t for t in tasks if (x := parse_date(t.get("기한"))) and x < d]
    reply = [t for t in tasks if t.get("구분") == "회신 대응" and t not in this_week and t not in overdue]
    undated = [t for t in tasks if not parse_date(t.get("기한")) and t not in reply]
    L = [f"리트젠 CRM 주간 보고 ({mon.isoformat()} 주)", ""]
    L.append("1. 이번 주 우선 할 일")
    rows = sorted(this_week, key=key) + sorted(reply, key=key)
    L += [f"- {task_line(t)}" for t in rows] or ["- 없음"]
    L.append("")
    L.append("2. 밀린 일 (기한 지남)")
    L += [f"- {task_line(t)}" for t in sorted(overdue, key=key)] or ["- 없음"]
    if undated:
        L.append("")
        L.append("   일정 미정")
        L += [f"- {task_line(t)}" for t in undated]
    L.append("")
    L.append(f"3. 지난주 활동 ({lmon.month}/{lmon.day}(월) ~ {lsun.month}/{lsun.day}(일))")
    new_c = [c for c in data.customers if in_last(c.get("등록일"))]
    cons = [c for c in data.consults if in_last(c.get("상담일"))]
    sent = [m for m in data.mails if m.get("메일 목적") != "테스트" and m.get("발송 상태") == "발송완료" and in_last(m.get("발송일"))]
    reps = [m for m in data.mails if m.get("회신 여부") == "Y" and in_last(m.get("회신일"))]
    L.append(f"- 신규 업체 {len(new_c)}곳" + (": " + ", ".join(c.get("회사명") or c.get("이름") for c in new_c) if new_c else ""))
    L.append(f"- 상담 {len(cons)}건" + (": " + ", ".join(f"{c.get('회사명')}({c.get('관심 제품') or '-'})" for c in cons) if cons else ""))
    L.append(f"- 발송 {len(sent)}건" + (": " + ", ".join(f"{m.get('회사명')}({m.get('메일 목적')})" for m in sent) if sent else ""))
    L.append(f"- 회신 {len(reps)}건" + (": " + ", ".join(m.get("회사명") for m in reps) if reps else ""))
    if not (new_c or cons or sent or reps):
        L.append("  (지난주 활동 없음)")
    L.append("")
    L.append("4. 진행 중 업체별 다음 조치")
    prog = [c for c in data.customers if c.get("진행 상태") not in ("수주", "보류")
            and (c.get("고객 구분") == "상담 고객" or any(t.get("고객 ID") == c["고객 ID"] for t in tasks))]
    for c in sorted(prog, key=lambda c: (RANK.get(c.get("영업 우선순위"), -1) * -1, c["고객 ID"])):
        mine = sorted([t for t in tasks if t.get("고객 ID") == c["고객 ID"]], key=key)
        nxt = mine[0] if mine else {}
        who = " ".join(x for x in [c.get("회사명"), c.get("이름")] if x)
        L.append(f"- {who} [{c.get('진행 상태') or '-'}/{c.get('영업 우선순위') or '-'}] 다음 조치: "
                 f"{nxt.get('할 일') or '확인 필요'} / {ko_date(nxt.get('기한')) if nxt else '일정 미정'}"
                 + (f" (외 {len(mine) - 1}건)" if len(mine) > 1 else ""))
    if not prog:
        L.append("- 진행 중인 업체 없음")
    subject = f"[리트젠 CRM] 주간 보고 {mon.month}/{mon.day}(월) — 이번 주 {len(rows)}건 · 밀린 일 {len(overdue)}건"
    emit("weekly", mon, subject, "\n".join(L), True, a.json, a.force)


def cmd_notify_test(a):
    to, why = notify_target()
    if not to:
        die(why)
    data = Data()
    stamp = now()
    tasks = open_tasks(data)
    body = (f"리트젠 CRM 알림 메일 테스트입니다. ({a.label or '수동 테스트'})\n\n"
            f"CRM을 읽은 시각: {stamp}\n"
            f"- 고객 {len(data.customers)}명 / 상담 {len(data.consults)}건 / 남은 할 일 {len(tasks)}건\n"
            f"- 고객통합리스트 최종 수정: {dt.datetime.fromtimestamp(F_CUST.stat().st_mtime).strftime('%Y-%m-%d %H:%M') if F_CUST.exists() else '-'}\n\n"
            "이 메일이 도착했다면 Claude 채팅창에 '알림 테스트 메일 받았어'라고 알려주세요.")
    print(json.dumps({"to": [to], "subject": f"[리트젠 CRM] 알림 테스트 ({a.label or '수동'}) {stamp}", "body": body},
                     ensure_ascii=False, indent=1))


def cmd_notify_log(a):
    log = load_json(F_LOG, {"가져온파일": {}})
    log.setdefault("알림발송", {})[f"{a.kind}:{norm_date(a.date)}"] = {"일시": now(), "Gmail 메시지 ID": a.gmail_id}
    save_json(F_LOG, log)
    print(f"알림 발송 기록: {a.kind} {norm_date(a.date)} (Gmail ID {a.gmail_id})")


# ───────────────────────────── 실행 ─────────────────────────────
def main():
    ap = argparse.ArgumentParser(description="리트젠 영업 CRM 도우미")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("init").set_defaults(fn=cmd_init)
    p = sub.add_parser("add"); p.add_argument("json"); p.add_argument("--source", default=""); p.set_defaults(fn=cmd_add)
    p = sub.add_parser("import-visitors"); p.add_argument("file"); p.add_argument("--event", default="")
    p.add_argument("--date", default=""); p.add_argument("--force", action="store_true"); p.set_defaults(fn=cmd_import)
    p = sub.add_parser("find")
    for opt in ["--name", "--company", "--email", "--event", "--priority", "--type", "--product", "--no-mail",
                "--consult-since", "--consult-until"]:
        p.add_argument(opt, default="")
    p.add_argument("--added-today", action="store_true"); p.add_argument("--followup", action="store_true")
    p.add_argument("--detail", action="store_true"); p.add_argument("--include-excluded", action="store_true")
    p.add_argument("--show-reviews", action="store_true"); p.add_argument("--limit", type=int, default=100)
    p.set_defaults(fn=cmd_find)
    sub.add_parser("reviews").set_defaults(fn=cmd_reviews)
    p = sub.add_parser("update-customer"); p.add_argument("id"); p.add_argument("fields", nargs="+"); p.set_defaults(fn=cmd_update_customer)
    p = sub.add_parser("resolve-review"); p.add_argument("id"); g = p.add_mutually_exclusive_group(required=True)
    g.add_argument("--merge"); g.add_argument("--new", action="store_true"); g.add_argument("--skip", action="store_true")
    p.set_defaults(fn=cmd_resolve)
    sub.add_parser("catalogs").set_defaults(fn=cmd_catalogs)
    p = sub.add_parser("match-catalog"); p.add_argument("id"); p.set_defaults(fn=cmd_match)
    p = sub.add_parser("draft"); p.add_argument("json"); p.set_defaults(fn=cmd_draft)
    sub.add_parser("test-mail").set_defaults(fn=cmd_test_mail)
    p = sub.add_parser("send-check"); p.add_argument("ids", nargs="+"); p.set_defaults(fn=cmd_send_check)
    p = sub.add_parser("mark-sent"); p.add_argument("id"); p.add_argument("--gmail-id", required=True)
    p.add_argument("--done", nargs="*"); p.add_argument("--next", default=""); p.add_argument("--due", default="")
    p.set_defaults(fn=cmd_mark_sent)
    p = sub.add_parser("mark-failed"); p.add_argument("id"); p.add_argument("--reason", required=True); p.set_defaults(fn=cmd_mark_failed)
    p = sub.add_parser("mark-reply"); p.add_argument("id"); p.add_argument("--followup", choices=["Y", "N"])
    p.add_argument("--unsubscribe", action="store_true"); p.add_argument("--date", default="")
    p.add_argument("--todo", default=""); p.add_argument("--due", default=""); p.set_defaults(fn=cmd_mark_reply)
    p = sub.add_parser("task-add"); p.add_argument("json"); p.set_defaults(fn=cmd_task_add)
    p = sub.add_parser("task-done"); p.add_argument("ids", nargs="+"); p.add_argument("--note", default="")
    p.add_argument("--cancel", action="store_true"); p.set_defaults(fn=cmd_task_done)
    p = sub.add_parser("task-update"); p.add_argument("id"); p.add_argument("fields", nargs="+"); p.set_defaults(fn=cmd_task_update)
    p = sub.add_parser("tasks"); p.add_argument("--all", action="store_true"); p.set_defaults(fn=cmd_tasks)
    for name, fn in (("todo", cmd_todo), ("weekly", cmd_weekly)):
        p = sub.add_parser(name); p.add_argument("--date", default=""); p.add_argument("--json", action="store_true")
        p.add_argument("--force", action="store_true"); p.set_defaults(fn=fn)
    p = sub.add_parser("notify-test"); p.add_argument("--label", default=""); p.set_defaults(fn=cmd_notify_test)
    p = sub.add_parser("notify-log"); p.add_argument("kind", choices=["daily", "weekly", "test"])
    p.add_argument("--date", required=True); p.add_argument("--gmail-id", required=True); p.set_defaults(fn=cmd_notify_log)
    p = sub.add_parser("cancel-draft"); p.add_argument("id"); p.set_defaults(fn=cmd_cancel)
    sub.add_parser("test-ok").set_defaults(fn=cmd_test_ok)
    sub.add_parser("auto-select").set_defaults(fn=cmd_auto_select)
    sub.add_parser("status").set_defaults(fn=cmd_status)
    a = ap.parse_args()
    a.fn(a)


if __name__ == "__main__":
    main()
