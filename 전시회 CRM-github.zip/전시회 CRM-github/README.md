# 리트젠(LICHTZEN) 전시회 CRM

전시회 방문자·상담 고객 관리와 맞춤 메일 발송을 돕는 엑셀 기반 CRM 도구입니다.
이 저장소에는 **코드와 문서만** 있고, 실제 고객·방문자·메일 자료와 실제 설정은 들어 있지 않습니다.

## 구성
| 경로 | 내용 |
|---|---|
| `06_자동화설정/scripts/crm.py` | 현재 쓰는 CRM 스크립트 (엑셀 파일 관리, Claude가 실행) |
| `06_자동화설정/발송설정.example.json` | 발송 설정 예시 (가짜 값) |
| `99_PROGRAM/` | 이전 웹앱 설계안 코드 (`app/`, `tests/`, `config/`) — 현재 미사용 |
| `00_START_HERE/01_설계서_v1.md` | 99_PROGRAM 설계서 |
| `CLAUDE.md`, `초보자용 사용방법.md` | 업무 규칙 / 사용 안내 |
| `01_~06_` 빈 폴더 | 업무 자료 폴더 자리 (`.gitkeep`만 있음) |

## 처음 시작하기 (새 PC에서)
1. Python 3.11+ 설치 후 의존성 설치
   ```
   py -m pip install -r 99_PROGRAM/requirements.txt
   ```
   (`06_자동화설정/scripts/crm.py`는 `openpyxl`만 필요합니다.)
2. 폴더·빈 엑셀 만들기: `py "06_자동화설정\scripts\crm.py" init`
   → `발송설정.json`이 기본값으로 생성됩니다. 예시를 쓰려면 `발송설정.example.json`을 복사해 `발송설정.json`으로 이름을 바꾸고 실제 값으로 고치세요.
3. `발송설정.json`, `처리기록.json`, 업무 폴더 안 자료는 `.gitignore`로 커밋되지 않습니다.

## 테스트
```
cd 99_PROGRAM
py -m pytest -q
```
테스트는 임시 폴더와 가상 데이터(`tests/demo_data.py`)만 사용합니다.
