"""정규화: 이름(한/영), 회사명, 이메일, 전화번호, 국가, 날짜. AI를 쓰지 않는 일반 코드."""
from __future__ import annotations

import re
import unicodedata
from datetime import date, datetime, timedelta

import phonenumbers

HANGUL_RE = re.compile(r"[가-힣]")


def clean(v) -> str:
    if v is None:
        return ""
    s = unicodedata.normalize("NFKC", str(v)).strip()
    s = re.sub(r"\s+", " ", s)
    return "" if s.lower() in ("nan", "none", "null", "-", "n/a") else s


def has_hangul(s: str) -> bool:
    return bool(s and HANGUL_RE.search(s))


# ───────── 한글 로마자 변환 ─────────
_CHO = ["g", "kk", "n", "d", "tt", "r", "m", "b", "pp", "s", "ss", "", "j", "jj", "ch", "k", "t", "p", "h"]
_JUNG = ["a", "ae", "ya", "yae", "eo", "e", "yeo", "ye", "o", "wa", "wae", "oe", "yo", "u", "wo", "we", "wi",
         "yu", "eu", "ui", "i"]
_JONG = ["", "k", "k", "k", "n", "n", "n", "t", "l", "k", "m", "l", "l", "l", "p", "l", "m", "p", "p", "t", "t",
         "ng", "t", "t", "k", "t", "p", "t"]


def romanize(s: str) -> str:
    out = []
    for ch in s:
        code = ord(ch) - 0xAC00
        if 0 <= code < 11172:
            out.append(_CHO[code // 588] + _JUNG[(code % 588) // 28] + _JONG[code % 28])
        else:
            out.append(ch)
    return "".join(out)


# 성씨별 영문 표기 변형
SURNAMES = {
    "김": ["kim", "gim"], "이": ["lee", "yi", "rhee", "i", "rhie"], "박": ["park", "pak", "bak"],
    "최": ["choi", "choe", "chae"], "정": ["jung", "jeong", "chung", "joung"], "강": ["kang", "gang"],
    "조": ["cho", "jo", "joe"], "윤": ["yoon", "yun"], "장": ["jang", "chang"], "임": ["lim", "im", "rim", "yim"],
    "한": ["han"], "오": ["oh", "o"], "서": ["seo", "suh", "so"], "신": ["shin", "sin"], "권": ["kwon", "gwon"],
    "황": ["hwang"], "안": ["ahn", "an"], "송": ["song"], "류": ["ryu", "yoo", "yu", "lyu"],
    "유": ["yoo", "yu", "ryu"], "홍": ["hong"], "전": ["jeon", "jun", "chun"], "고": ["ko", "go", "koh"],
    "문": ["moon", "mun"], "양": ["yang"], "손": ["son", "sohn"], "배": ["bae", "pae"], "백": ["baek", "paik", "paek"],
    "허": ["heo", "huh", "hur"], "남": ["nam"], "심": ["shim", "sim"], "노": ["noh", "roh", "no", "ro"],
    "하": ["ha"], "곽": ["kwak", "gwak"], "성": ["sung", "seong"], "차": ["cha"], "주": ["joo", "ju", "chu"],
    "우": ["woo", "wu", "u"], "구": ["koo", "gu", "ku"], "민": ["min"], "나": ["na", "ra"], "진": ["jin", "chin"],
    "지": ["ji", "chi"], "엄": ["um", "eom"], "채": ["chae"], "원": ["won"], "천": ["chun", "cheon"],
    "방": ["bang", "pang"], "공": ["kong", "gong"], "현": ["hyun", "hyeon"], "함": ["ham"], "변": ["byun", "byeon"],
    "염": ["yeom", "yum"], "여": ["yeo", "yu"], "추": ["choo", "chu"], "도": ["do", "doh"], "소": ["so"],
    "석": ["seok", "suk"], "선": ["sun", "seon"], "설": ["seol", "sul"], "마": ["ma"], "길": ["gil", "kil"],
    "연": ["yeon", "yun"], "위": ["wi", "wee"], "표": ["pyo"], "명": ["myung", "myeong"], "기": ["ki", "gi"],
    "반": ["ban", "pan"], "왕": ["wang"], "금": ["keum", "geum"], "옥": ["ok"], "육": ["yook", "yuk"],
    "인": ["in"], "맹": ["maeng"], "제": ["je"], "모": ["mo"], "탁": ["tak"], "국": ["kook", "guk"],
    "은": ["eun"], "편": ["pyeon", "pyun"], "용": ["yong"], "남궁": ["namgoong", "namgung"],
    "황보": ["hwangbo"], "제갈": ["jegal"], "선우": ["sunwoo", "seonu"], "독고": ["dokgo"], "사공": ["sagong"],
}
COMPOUND_SURNAMES = {"남궁", "황보", "제갈", "선우", "독고", "사공", "서문", "동방"}


def loose(s: str) -> str:
    """영문 표기 차이를 흡수한 비교용 문자열 (Jeong=Jung, Kim=Gim, Lee≈Li ...)."""
    s = re.sub(r"[^a-z]", "", (s or "").lower())
    s = s.replace("rh", "r")
    for a, b in (("tch", "j"), ("ch", "j"), ("sh", "s"), ("oo", "u"), ("ou", "u"), ("ee", "i"), ("eo", "u"),
                 ("eu", "u"), ("ui", "i"), ("ae", "e"), ("ai", "e"), ("wo", "o")):
        s = s.replace(a, b)
    s = re.sub(r"([aeiouy])h", r"\1", s)
    s = s.translate(str.maketrans("ktplfv", "gdbrbb"))
    s = re.sub(r"(.)\1+", r"\1", s)
    return s


def split_korean_name(name: str) -> tuple[str, str]:
    n = "".join(HANGUL_RE.findall(name or ""))
    if len(n) >= 3 and n[:2] in COMPOUND_SURNAMES:
        return n[:2], n[2:]
    if len(n) >= 2:
        return n[0], n[1:]
    return n, ""


def split_name_field(value: str) -> tuple[str, str]:
    """'홍길동 / Gil-dong Hong' 같은 값을 (한글, 영문) 으로 분리."""
    v = clean(value)
    ko = "".join(HANGUL_RE.findall(v))
    en = re.sub(r"[가-힣/()\[\]]", " ", v)
    en = re.sub(r"\s+", " ", en).strip(" ,-")
    if not re.search(r"[A-Za-z]", en):
        en = ""
    return ko, en


def _korean_name_keys(name: str) -> set[str]:
    sur, given = split_korean_name(name)
    if not sur:
        return set()
    g = loose(romanize(given))
    variants = SURNAMES.get(sur, []) + [romanize(sur)]
    return {f"{loose(v)}|{g}" for v in variants}


def _latin_name_keys(name: str) -> set[str]:
    s = clean(name)
    if "," in s:
        last, first = s.split(",", 1)
        return {f"{loose(last)}|{loose(first)}"}
    tokens = [t for t in s.split(" ") if re.search(r"[A-Za-z]", t)]
    if not tokens:
        return set()
    if len(tokens) == 1:
        return {f"|{loose(tokens[0])}"}
    return {f"{loose(tokens[0])}|{loose(''.join(tokens[1:]))}",
            f"{loose(tokens[-1])}|{loose(''.join(tokens[:-1]))}"}


def name_keys(name_ko: str, name_en: str) -> set[str]:
    keys: set[str] = set()
    if clean(name_ko) and has_hangul(name_ko):
        keys |= _korean_name_keys(name_ko)
    if clean(name_en):
        keys |= _latin_name_keys(name_en)
    return {k for k in keys if k.strip("|")}


def name_ko_exact(name_ko: str) -> str:
    return "".join(HANGUL_RE.findall(name_ko or ""))


# ───────── 회사명 ─────────
_KO_LEGAL = ["주식회사", "(주)", "유한회사", "(유)", "유한책임회사", "합자회사", "합명회사", "재단법인", "사단법인",
             "(재)", "(사)", "株式会社", "有限公司", "(株)", "(유한)"]
_EN_LEGAL_RE = re.compile(r"\b(co|company|ltd|limited|inc|incorporated|corp|corporation|llc|gmbh|pte|plc|"
                          r"s\.?a|ag|bv|kk|srl|spa)\b\.?", re.I)


def company_key(name: str) -> str:
    n = clean(name).lower()
    if not n:
        return ""
    for t in _KO_LEGAL:
        n = n.replace(t.lower(), " ")
    n = _EN_LEGAL_RE.sub(" ", n)
    return re.sub(r"[^0-9a-z가-힣]", "", n)


def key_script(key: str) -> str:
    return "ko" if has_hangul(key) else "en"


# ───────── 이메일 ─────────
FREE_EMAIL_DOMAINS = {"gmail.com", "naver.com", "daum.net", "hanmail.net", "kakao.com", "nate.com", "hotmail.com",
                      "outlook.com", "live.com", "yahoo.com", "yahoo.co.kr", "icloud.com", "me.com", "msn.com",
                      "korea.com", "empas.com", "paran.com", "qq.com", "163.com", "126.com", "aol.com"}
GENERIC_LOCAL_PARTS = {"info", "sales", "contact", "admin", "office", "support", "help", "marketing", "service",
                       "webmaster", "master", "hr", "cs", "biz", "business", "team", "mail", "korea", "hello",
                       "inquiry", "enquiry", "order", "orders", "rnd", "lab"}


def split_multi(v) -> list[str]:
    return [x for x in (clean(p) for p in re.split(r"[;,/\n]| or ", clean(v))) if x]


def norm_email(v) -> str:
    e = clean(v).lower().replace(" ", "").strip("<>;,.")
    if e.startswith("mailto:"):
        e = e[7:]
    return e if re.fullmatch(r"[^@\s]+@[^@\s]+\.[a-z]{2,}", e) else ""


def email_is_generic(e: str) -> bool:
    return e.split("@")[0] in GENERIC_LOCAL_PARTS


def corporate_domain(e: str) -> str:
    if "@" not in e:
        return ""
    d = e.split("@", 1)[1]
    return "" if d in FREE_EMAIL_DOMAINS else d


# ───────── 국가 ─────────
_COUNTRIES = [
    ("대한민국", "KR", ["대한민국", "한국", "korea", "south korea", "republic of korea", "korea, republic of", "kr", "kor", "rok"]),
    ("미국", "US", ["미국", "usa", "us", "united states", "united states of america", "america"]),
    ("일본", "JP", ["일본", "japan", "jp", "jpn"]), ("중국", "CN", ["중국", "china", "cn", "chn", "prc"]),
    ("대만", "TW", ["대만", "taiwan", "tw"]), ("홍콩", "HK", ["홍콩", "hong kong", "hk"]),
    ("베트남", "VN", ["베트남", "vietnam", "viet nam", "vn"]), ("태국", "TH", ["태국", "thailand", "th"]),
    ("인도네시아", "ID", ["인도네시아", "indonesia"]), ("말레이시아", "MY", ["말레이시아", "malaysia", "my"]),
    ("싱가포르", "SG", ["싱가포르", "singapore", "sg"]), ("필리핀", "PH", ["필리핀", "philippines", "ph"]),
    ("인도", "IN", ["인도", "india"]), ("독일", "DE", ["독일", "germany", "de", "deutschland"]),
    ("영국", "GB", ["영국", "uk", "united kingdom", "england", "gb"]), ("프랑스", "FR", ["프랑스", "france", "fr"]),
    ("이탈리아", "IT", ["이탈리아", "italy"]), ("스페인", "ES", ["스페인", "spain", "es"]),
    ("네덜란드", "NL", ["네덜란드", "netherlands", "nl", "holland"]), ("스위스", "CH", ["스위스", "switzerland", "ch"]),
    ("폴란드", "PL", ["폴란드", "poland", "pl"]), ("러시아", "RU", ["러시아", "russia", "ru"]),
    ("튀르키예", "TR", ["튀르키예", "터키", "turkey", "türkiye", "tr"]), ("캐나다", "CA", ["캐나다", "canada", "ca"]),
    ("멕시코", "MX", ["멕시코", "mexico", "mx"]), ("브라질", "BR", ["브라질", "brazil", "br"]),
    ("호주", "AU", ["호주", "australia", "au"]), ("아랍에미리트", "AE", ["아랍에미리트", "uae", "united arab emirates", "ae"]),
    ("사우디아라비아", "SA", ["사우디아라비아", "사우디", "saudi arabia", "ksa"]), ("이스라엘", "IL", ["이스라엘", "israel", "il"]),
]
_COUNTRY_LOOKUP = {alias: (disp, code) for disp, code, aliases in _COUNTRIES for alias in aliases}
_CODE_TO_DISPLAY = {code: disp for disp, code, _ in _COUNTRIES}


def norm_country(v) -> tuple[str, str | None]:
    c = clean(v)
    if not c:
        return "", None
    hit = _COUNTRY_LOOKUP.get(c.lower())
    return hit if hit else (c, None)


def country_from_code(code: str | None) -> str:
    return _CODE_TO_DISPLAY.get(code or "", code or "")


# ───────── 전화번호 ─────────
def norm_phone(v, region: str | None = None) -> tuple[str, bool, str] | None:
    """반환: (E164, 휴대폰 여부, 국가코드) 또는 None."""
    raw = clean(v)
    if not raw:
        return None
    raw = raw.replace("(0)", "")
    digits = re.sub(r"\D", "", raw)
    if len(digits) < 7:
        return None
    if not raw.startswith("+"):
        if digits.startswith("82") and len(digits) >= 11 and not digits.startswith("820"):
            raw = "+" + digits
        elif digits.startswith("0082"):
            raw = "+" + digits[2:]
    try:
        num = phonenumbers.parse(raw, region or "KR")
    except phonenumbers.NumberParseException:
        return None
    if not phonenumbers.is_possible_number(num):
        return None
    e164 = phonenumbers.format_number(num, phonenumbers.PhoneNumberFormat.E164)
    cc = phonenumbers.region_code_for_number(num) or ""
    if num.country_code == 82:
        mobile = str(num.national_number).startswith(("10", "11", "16", "17", "18", "19"))
    else:
        mobile = phonenumbers.number_type(num) in (phonenumbers.PhoneNumberType.MOBILE,
                                                    phonenumbers.PhoneNumberType.FIXED_LINE_OR_MOBILE)
    return e164, mobile, cc


def pretty_phone(e164: str) -> str:
    try:
        num = phonenumbers.parse(e164, None)
    except phonenumbers.NumberParseException:
        return e164
    fmt = phonenumbers.PhoneNumberFormat.NATIONAL if num.country_code == 82 else phonenumbers.PhoneNumberFormat.INTERNATIONAL
    return phonenumbers.format_number(num, fmt)


# ───────── 날짜 ─────────
_DT_FORMATS = ["%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d", "%Y/%m/%d %H:%M:%S", "%Y/%m/%d %H:%M", "%Y/%m/%d",
               "%Y.%m.%d %H:%M:%S", "%Y.%m.%d %H:%M", "%Y.%m.%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M",
               "%m/%d/%Y %H:%M:%S", "%m/%d/%Y %H:%M", "%m/%d/%Y", "%Y. %m. %d. %p %I:%M:%S", "%Y. %m. %d. %p %I:%M",
               "%Y. %m. %d %H:%M:%S", "%Y. %m. %d %H:%M", "%Y. %m. %d.", "%Y. %m. %d", "%Y%m%d%H%M%S", "%Y%m%d"]


def parse_dt(v) -> datetime | None:
    if v is None or v == "":
        return None
    if isinstance(v, datetime):
        return v.replace(microsecond=0)
    if isinstance(v, date):
        return datetime(v.year, v.month, v.day)
    if isinstance(v, (int, float)) and 20000 < float(v) < 80000:
        return (datetime(1899, 12, 30) + timedelta(days=float(v))).replace(microsecond=0)
    s = clean(v).replace("오전", "AM").replace("오후", "PM")
    for fmt in _DT_FORMATS:
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            continue
    return None
