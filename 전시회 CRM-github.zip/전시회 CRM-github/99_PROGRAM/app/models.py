"""데이터베이스 테이블 정의.

RAW 테이블(raw_*)은 추가만 가능합니다. 수정/삭제는 DB 트리거로 막혀 있고,
유일한 예외는 관리자의 '개인정보 파기'(purged_at 기록과 함께 마스킹)입니다.
"""
from __future__ import annotations

from datetime import datetime
from typing import Optional

from sqlalchemy import (JSON, Boolean, DateTime, Float, Index, Integer, String,
                        Text, UniqueConstraint)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


def now() -> datetime:
    return datetime.now().replace(microsecond=0)


class Base(DeclarativeBase):
    pass


# ───────────────────────── 기준 정보 ─────────────────────────
class Counter(Base):
    __tablename__ = "id_counters"
    prefix: Mapped[str] = mapped_column(String(40), primary_key=True)
    value: Mapped[int] = mapped_column(Integer, default=0)


class Setting(Base):
    __tablename__ = "settings"
    key: Mapped[str] = mapped_column(String(80), primary_key=True)
    value: Mapped[Optional[dict]] = mapped_column(JSON)


class Staff(Base):
    __tablename__ = "staff"
    id: Mapped[str] = mapped_column(String(20), primary_key=True)  # STF-001
    name: Mapped[str] = mapped_column(String(100))
    email: Mapped[Optional[str]] = mapped_column(String(200))
    phone: Mapped[Optional[str]] = mapped_column(String(50))
    signature: Mapped[Optional[str]] = mapped_column(Text)
    role: Mapped[str] = mapped_column(String(20), default="영업")  # 관리자/영업/조회
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=now)


class Event(Base):
    __tablename__ = "events"
    id: Mapped[str] = mapped_column(String(20), primary_key=True)  # EVT-2026-001
    name: Mapped[str] = mapped_column(String(200))
    type: Mapped[str] = mapped_column(String(30), default="전시회")
    start_date: Mapped[Optional[datetime]] = mapped_column(DateTime)
    end_date: Mapped[Optional[datetime]] = mapped_column(DateTime)
    location: Mapped[Optional[str]] = mapped_column(String(200))
    folder_name: Mapped[str] = mapped_column(String(200))
    status: Mapped[str] = mapped_column(String(20), default="준비")  # 준비/진행/종료/상담등록완료
    consult_closed_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    memo: Mapped[Optional[str]] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=now)


# ───────────────────────── RAW (원본) ─────────────────────────
class RawFile(Base):
    __tablename__ = "raw_files"
    id: Mapped[str] = mapped_column(String(20), primary_key=True)  # RAWF-000001
    event_id: Mapped[Optional[str]] = mapped_column(String(20), index=True)
    kind: Mapped[str] = mapped_column(String(20))  # qr/card/note/recording/other
    original_name: Mapped[str] = mapped_column(String(300))
    stored_path: Mapped[Optional[str]] = mapped_column(String(500))
    original_sha256: Mapped[str] = mapped_column(String(64), unique=True)  # 중복 업로드 차단용, 변경 안 됨
    sha256: Mapped[str] = mapped_column(String(64))  # 현재 파일 해시 (파기 처리 시 바뀜)
    size: Mapped[int] = mapped_column(Integer, default=0)
    meta: Mapped[Optional[dict]] = mapped_column(JSON)
    uploaded_by: Mapped[Optional[str]] = mapped_column(String(100))
    uploaded_at: Mapped[datetime] = mapped_column(DateTime, default=now)
    purged_at: Mapped[Optional[datetime]] = mapped_column(DateTime)


class RawQrRow(Base):
    __tablename__ = "raw_qr_rows"
    __table_args__ = (UniqueConstraint("event_id", "row_hash", name="uq_qr_event_rowhash"),)
    id: Mapped[str] = mapped_column(String(20), primary_key=True)  # RAW-QR-000001
    event_id: Mapped[str] = mapped_column(String(20), index=True)
    file_id: Mapped[str] = mapped_column(String(20), index=True)
    sheet: Mapped[Optional[str]] = mapped_column(String(100))
    row_index: Mapped[int] = mapped_column(Integer)
    row_hash: Mapped[str] = mapped_column(String(64))
    raw_json: Mapped[dict] = mapped_column(JSON)  # 원본 열 그대로
    name: Mapped[Optional[str]] = mapped_column(String(200))
    name_en: Mapped[Optional[str]] = mapped_column(String(200))
    company: Mapped[Optional[str]] = mapped_column(String(300))
    department: Mapped[Optional[str]] = mapped_column(String(200))
    title: Mapped[Optional[str]] = mapped_column(String(200))
    email: Mapped[Optional[str]] = mapped_column(String(300))
    mobile: Mapped[Optional[str]] = mapped_column(String(100))
    phone: Mapped[Optional[str]] = mapped_column(String(100))
    country: Mapped[Optional[str]] = mapped_column(String(100))
    scanned_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    interest: Mapped[Optional[str]] = mapped_column(Text)
    memo: Mapped[Optional[str]] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=now)
    purged_at: Mapped[Optional[datetime]] = mapped_column(DateTime)


class RawCard(Base):
    __tablename__ = "raw_cards"
    id: Mapped[str] = mapped_column(String(20), primary_key=True)  # RAW-CARD-000001
    event_id: Mapped[Optional[str]] = mapped_column(String(20), index=True)
    file_id: Mapped[Optional[str]] = mapped_column(String(20))
    name: Mapped[Optional[str]] = mapped_column(String(200))
    name_en: Mapped[Optional[str]] = mapped_column(String(200))
    company: Mapped[Optional[str]] = mapped_column(String(300))
    company_en: Mapped[Optional[str]] = mapped_column(String(300))
    department: Mapped[Optional[str]] = mapped_column(String(200))
    title: Mapped[Optional[str]] = mapped_column(String(200))
    email: Mapped[Optional[str]] = mapped_column(String(300))
    mobile: Mapped[Optional[str]] = mapped_column(String(100))
    phone: Mapped[Optional[str]] = mapped_column(String(100))
    address: Mapped[Optional[str]] = mapped_column(Text)
    website: Mapped[Optional[str]] = mapped_column(String(300))
    country: Mapped[Optional[str]] = mapped_column(String(100))
    entry_method: Mapped[str] = mapped_column(String(20), default="manual")  # manual/ocr
    ocr_status: Mapped[str] = mapped_column(String(20), default="none")  # none/pending/done
    captured_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    entered_by: Mapped[Optional[str]] = mapped_column(String(100))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=now)
    purged_at: Mapped[Optional[datetime]] = mapped_column(DateTime)


class RawNote(Base):
    __tablename__ = "raw_notes"
    id: Mapped[str] = mapped_column(String(20), primary_key=True)  # RAW-NOTE-000001
    event_id: Mapped[Optional[str]] = mapped_column(String(20), index=True)
    content_hash: Mapped[str] = mapped_column(String(64), unique=True)
    customer_id_hint: Mapped[Optional[str]] = mapped_column(String(20))
    name: Mapped[Optional[str]] = mapped_column(String(200))
    company: Mapped[Optional[str]] = mapped_column(String(300))
    email: Mapped[Optional[str]] = mapped_column(String(300))
    mobile: Mapped[Optional[str]] = mapped_column(String(100))
    channel: Mapped[str] = mapped_column(String(30), default="현장 상담")
    consulted_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    staff_id: Mapped[Optional[str]] = mapped_column(String(20))
    content: Mapped[str] = mapped_column(Text)
    file_path: Mapped[Optional[str]] = mapped_column(String(500))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=now)
    purged_at: Mapped[Optional[datetime]] = mapped_column(DateTime)


class RawRecording(Base):
    __tablename__ = "raw_recordings"
    id: Mapped[str] = mapped_column(String(20), primary_key=True)  # RAW-REC-000001
    event_id: Mapped[Optional[str]] = mapped_column(String(20), index=True)
    file_id: Mapped[str] = mapped_column(String(20))
    customer_id_hint: Mapped[Optional[str]] = mapped_column(String(20))
    name: Mapped[Optional[str]] = mapped_column(String(200))
    company: Mapped[Optional[str]] = mapped_column(String(300))
    recorded_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    staff_id: Mapped[Optional[str]] = mapped_column(String(20))
    consent: Mapped[bool] = mapped_column(Boolean, default=False)
    consent_method: Mapped[Optional[str]] = mapped_column(String(200))
    stt_status: Mapped[str] = mapped_column(String(20), default="pending")  # pending/done/failed
    transcript_path: Mapped[Optional[str]] = mapped_column(String(500))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=now)
    purged_at: Mapped[Optional[datetime]] = mapped_column(DateTime)


class RawOther(Base):
    __tablename__ = "raw_others"
    id: Mapped[str] = mapped_column(String(20), primary_key=True)  # RAW-ETC-000001
    event_id: Mapped[Optional[str]] = mapped_column(String(20), index=True)
    file_id: Mapped[str] = mapped_column(String(20))
    customer_id_hint: Mapped[Optional[str]] = mapped_column(String(20))
    description: Mapped[Optional[str]] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=now)
    purged_at: Mapped[Optional[datetime]] = mapped_column(DateTime)


# ───────────────────────── 통합 데이터 ─────────────────────────
class Company(Base):
    __tablename__ = "companies"
    id: Mapped[str] = mapped_column(String(20), primary_key=True)  # COM-000001
    name: Mapped[str] = mapped_column(String(300))
    name_en: Mapped[Optional[str]] = mapped_column(String(300))
    country: Mapped[Optional[str]] = mapped_column(String(100))
    industry: Mapped[Optional[str]] = mapped_column(String(200))
    domain: Mapped[Optional[str]] = mapped_column(String(200), index=True)
    memo: Mapped[Optional[str]] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), default="active")  # active/merged
    merged_into: Mapped[Optional[str]] = mapped_column(String(20))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=now)


class CompanyAlias(Base):
    __tablename__ = "company_aliases"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    company_id: Mapped[str] = mapped_column(String(20), index=True)
    alias: Mapped[str] = mapped_column(String(300))
    alias_key: Mapped[str] = mapped_column(String(300), index=True)
    source: Mapped[Optional[str]] = mapped_column(String(50))


class Customer(Base):
    __tablename__ = "customers"
    id: Mapped[str] = mapped_column(String(20), primary_key=True)  # CUS-000001
    company_id: Mapped[Optional[str]] = mapped_column(String(20), index=True)
    company_display: Mapped[Optional[str]] = mapped_column(String(300))
    name_ko: Mapped[Optional[str]] = mapped_column(String(200))
    name_en: Mapped[Optional[str]] = mapped_column(String(200))
    department: Mapped[Optional[str]] = mapped_column(String(200))
    title: Mapped[Optional[str]] = mapped_column(String(200))
    email: Mapped[Optional[str]] = mapped_column(String(300))
    mobile: Mapped[Optional[str]] = mapped_column(String(100))
    phone: Mapped[Optional[str]] = mapped_column(String(100))
    country: Mapped[Optional[str]] = mapped_column(String(100))
    is_domestic: Mapped[Optional[bool]] = mapped_column(Boolean)
    language: Mapped[Optional[str]] = mapped_column(String(20))
    owner_staff_id: Mapped[Optional[str]] = mapped_column(String(20))
    overrides: Mapped[Optional[dict]] = mapped_column(JSON)  # 담당자가 직접 수정한 값 (우선 적용)
    ai_summary: Mapped[Optional[str]] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), default="active")  # active/merged/purged
    merged_into: Mapped[Optional[str]] = mapped_column(String(20))
    first_seen_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    last_contact_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=now)
    purged_at: Mapped[Optional[datetime]] = mapped_column(DateTime)


class RawLink(Base):
    """RAW 원본 1건이 어느 고객에 연결되어 있는지 (통합/분리의 단위)."""
    __tablename__ = "raw_links"
    __table_args__ = (UniqueConstraint("raw_type", "raw_id", name="uq_rawlink"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    raw_type: Mapped[str] = mapped_column(String(20))
    raw_id: Mapped[str] = mapped_column(String(20))
    customer_id: Mapped[str] = mapped_column(String(20), index=True)
    event_id: Mapped[Optional[str]] = mapped_column(String(20))
    seen_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    decision_id: Mapped[Optional[str]] = mapped_column(String(20))
    linked_at: Mapped[datetime] = mapped_column(DateTime, default=now)


class CustomerIdentifier(Base):
    __tablename__ = "customer_identifiers"
    __table_args__ = (Index("ix_ident_kind_value", "kind", "value"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    customer_id: Mapped[str] = mapped_column(String(20), index=True)
    kind: Mapped[str] = mapped_column(String(20))
    value: Mapped[str] = mapped_column(String(300))
    raw_link_id: Mapped[Optional[int]] = mapped_column(Integer)


class MatchDecision(Base):
    __tablename__ = "match_decisions"
    id: Mapped[str] = mapped_column(String(20), primary_key=True)  # MRG-000001
    raw_type: Mapped[Optional[str]] = mapped_column(String(20))
    raw_id: Mapped[Optional[str]] = mapped_column(String(20))
    candidate_customer_id: Mapped[Optional[str]] = mapped_column(String(20))
    chosen_customer_id: Mapped[Optional[str]] = mapped_column(String(20))
    score: Mapped[Optional[int]] = mapped_column(Integer)
    evidence: Mapped[Optional[list]] = mapped_column(JSON)
    decision: Mapped[str] = mapped_column(String(30))
    decided_by: Mapped[Optional[str]] = mapped_column(String(100))
    decided_at: Mapped[datetime] = mapped_column(DateTime, default=now)


class MergeHistory(Base):
    __tablename__ = "merge_history"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    action: Mapped[str] = mapped_column(String(20))  # merge / detach
    source_customer: Mapped[str] = mapped_column(String(20))  # 자료가 빠져나간 고객
    target_customer: Mapped[str] = mapped_column(String(20))  # 자료가 옮겨간 고객
    moved: Mapped[dict] = mapped_column(JSON)
    reason: Mapped[Optional[str]] = mapped_column(Text)
    actor: Mapped[Optional[str]] = mapped_column(String(100))
    at: Mapped[datetime] = mapped_column(DateTime, default=now)
    reverted_at: Mapped[Optional[datetime]] = mapped_column(DateTime)


class Visit(Base):
    __tablename__ = "visits"
    __table_args__ = (UniqueConstraint("customer_id", "event_id", name="uq_visit"),)
    id: Mapped[str] = mapped_column(String(20), primary_key=True)  # VIS-000001
    customer_id: Mapped[str] = mapped_column(String(20), index=True)
    event_id: Mapped[str] = mapped_column(String(20), index=True)
    first_seen_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=now)


class Consultation(Base):
    __tablename__ = "consultations"
    id: Mapped[str] = mapped_column(String(20), primary_key=True)  # CON-000001
    customer_id: Mapped[str] = mapped_column(String(20), index=True)
    event_id: Mapped[Optional[str]] = mapped_column(String(20), index=True)
    raw_note_id: Mapped[Optional[str]] = mapped_column(String(20), unique=True)
    channel: Mapped[str] = mapped_column(String(30), default="현장 상담")
    consulted_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    staff_id: Mapped[Optional[str]] = mapped_column(String(20))
    content: Mapped[str] = mapped_column(Text)
    ai_status: Mapped[str] = mapped_column(String(20), default="대기")  # 대기/완료/해당없음
    created_at: Mapped[datetime] = mapped_column(DateTime, default=now)


class Activity(Base):
    """담당자가 직접 남기는 활동(전화, 메모, 미팅 등). 방문·명함·상담은 자동으로 타임라인에 표시."""
    __tablename__ = "activities"
    id: Mapped[str] = mapped_column(String(20), primary_key=True)  # ACT-000001
    customer_id: Mapped[str] = mapped_column(String(20), index=True)
    event_id: Mapped[Optional[str]] = mapped_column(String(20))
    type: Mapped[str] = mapped_column(String(30))
    occurred_at: Mapped[datetime] = mapped_column(DateTime, default=now)
    title: Mapped[Optional[str]] = mapped_column(String(300))
    detail: Mapped[Optional[str]] = mapped_column(Text)
    staff_id: Mapped[Optional[str]] = mapped_column(String(20))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=now)


# ───────────────────────── 관리 ─────────────────────────
class ReviewItem(Base):
    __tablename__ = "review_items"
    id: Mapped[str] = mapped_column(String(20), primary_key=True)  # REV-000001
    kind: Mapped[str] = mapped_column(String(30))  # match / unassigned / ocr / data_conflict
    status: Mapped[str] = mapped_column(String(20), default="open")  # open / resolved
    customer_id: Mapped[Optional[str]] = mapped_column(String(20), index=True)
    candidate_customer_id: Mapped[Optional[str]] = mapped_column(String(20))
    raw_type: Mapped[Optional[str]] = mapped_column(String(20))
    raw_id: Mapped[Optional[str]] = mapped_column(String(20))
    decision_id: Mapped[Optional[str]] = mapped_column(String(20))
    summary: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=now)
    resolved_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    resolved_by: Mapped[Optional[str]] = mapped_column(String(100))
    resolution: Mapped[Optional[str]] = mapped_column(String(100))


class ProcessingLog(Base):
    __tablename__ = "processing_log"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    at: Mapped[datetime] = mapped_column(DateTime, default=now)
    actor: Mapped[Optional[str]] = mapped_column(String(100))
    action: Mapped[str] = mapped_column(String(50))
    target: Mapped[Optional[str]] = mapped_column(String(100))
    detail: Mapped[Optional[str]] = mapped_column(Text)


class PurgeLog(Base):
    """개인정보 파기 기록. 개인정보 자체는 남기지 않고 ID와 건수만 기록."""
    __tablename__ = "purge_log"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    at: Mapped[datetime] = mapped_column(DateTime, default=now)
    actor: Mapped[Optional[str]] = mapped_column(String(100))
    target_type: Mapped[str] = mapped_column(String(20))
    target_id: Mapped[str] = mapped_column(String(20))
    reason: Mapped[str] = mapped_column(Text)
    detail: Mapped[Optional[dict]] = mapped_column(JSON)


class AiUsage(Base):
    """AI 사용량/비용 기록 (M4부터 사용)."""
    __tablename__ = "ai_usage"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    at: Mapped[datetime] = mapped_column(DateTime, default=now)
    mode: Mapped[str] = mapped_column(String(20))  # api / manual
    task: Mapped[str] = mapped_column(String(50))
    model: Mapped[Optional[str]] = mapped_column(String(50))
    input_tokens: Mapped[int] = mapped_column(Integer, default=0)
    output_tokens: Mapped[int] = mapped_column(Integer, default=0)
    cost_usd: Mapped[float] = mapped_column(Float, default=0.0)
    ref_id: Mapped[Optional[str]] = mapped_column(String(30))


RAW_MODELS = {
    "qr": RawQrRow,
    "card": RawCard,
    "note": RawNote,
    "recording": RawRecording,
    "other": RawOther,
}
RAW_PREFIX = {"qr": "RAW-QR", "card": "RAW-CARD", "note": "RAW-NOTE", "recording": "RAW-REC", "other": "RAW-ETC"}
RAW_LABEL = {"qr": "QR 방문", "card": "명함", "note": "상담 기록", "recording": "상담 녹음", "other": "기타 자료"}

# 고객 ID를 참조하는 가공 테이블 (통합/분리 시 함께 이동)
CUSTOMER_REF_MODELS = {"consultations": Consultation, "activities": Activity}
