"""DB 연결, 초기화, ID 발급, 처리 이력 기록."""
from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime

from sqlalchemy import create_engine, event, inspect, text
from sqlalchemy.orm import Session, sessionmaker

from . import paths
from .models import Base, Counter, ProcessingLog

_engine = None
_SessionLocal = None

DB_FILENAME = "lichtzen_crm.db"

# RAW 보호 트리거: 삭제 금지 + (QR/상담 원본) 수정 금지. 개인정보 파기(purged_at 기록) 때만 수정 허용.
RAW_PROTECT_TRIGGERS = [
    *[
        f"""CREATE TRIGGER IF NOT EXISTS trg_{t}_no_delete BEFORE DELETE ON {t}
            BEGIN SELECT RAISE(ABORT, 'RAW 데이터는 삭제할 수 없습니다'); END;"""
        for t in ("raw_files", "raw_qr_rows", "raw_cards", "raw_notes", "raw_recordings", "raw_others")
    ],
    *[
        f"""CREATE TRIGGER IF NOT EXISTS trg_{t}_no_update BEFORE UPDATE ON {t}
            WHEN NEW.purged_at IS NULL
            BEGIN SELECT RAISE(ABORT, 'RAW 데이터는 수정할 수 없습니다'); END;"""
        for t in ("raw_qr_rows", "raw_notes")
    ],
]


def db_path():
    return paths.p("11_DATABASE", DB_FILENAME)


def get_engine():
    global _engine, _SessionLocal
    if _engine is None:
        paths.p("11_DATABASE").mkdir(parents=True, exist_ok=True)
        _engine = create_engine(
            f"sqlite:///{db_path().as_posix()}",
            connect_args={"check_same_thread": False, "timeout": 30},
        )

        @event.listens_for(_engine, "connect")
        def _on_connect(dbapi_conn, _record):
            cur = dbapi_conn.cursor()
            cur.execute("PRAGMA journal_mode=WAL")
            cur.execute("PRAGMA synchronous=NORMAL")
            cur.close()

        _SessionLocal = sessionmaker(bind=_engine, expire_on_commit=False)
    return _engine


def reset_engine() -> None:
    """DB 파일을 교체(복구)하거나 테스트 폴더를 바꿀 때 연결을 끊습니다."""
    global _engine, _SessionLocal
    if _engine is not None:
        _engine.dispose()
    _engine = None
    _SessionLocal = None


def init_db() -> None:
    engine = get_engine()
    Base.metadata.create_all(engine)
    _add_missing_columns(engine)
    with engine.begin() as conn:
        for sql in RAW_PROTECT_TRIGGERS:
            conn.execute(text(sql))


def _add_missing_columns(engine) -> None:
    """프로그램 업데이트로 새 열이 추가되면 기존 DB에 자동으로 추가 (데이터 유지)."""
    insp = inspect(engine)
    with engine.begin() as conn:
        for table in Base.metadata.sorted_tables:
            if not insp.has_table(table.name):
                continue
            existing = {c["name"] for c in insp.get_columns(table.name)}
            for col in table.columns:
                if col.name not in existing:
                    coltype = col.type.compile(engine.dialect)
                    conn.execute(text(f'ALTER TABLE {table.name} ADD COLUMN "{col.name}" {coltype}'))


def new_session() -> Session:
    get_engine()
    return _SessionLocal()


@contextmanager
def session_scope():
    s = new_session()
    try:
        yield s
        s.commit()
    except Exception:
        s.rollback()
        raise
    finally:
        s.close()


def next_id(s: Session, prefix: str, width: int = 6) -> str:
    c = s.get(Counter, prefix)
    if c is None:
        c = Counter(prefix=prefix, value=0)
        s.add(c)
    c.value += 1
    s.flush()
    return f"{prefix}-{c.value:0{width}d}"


def next_event_id(s: Session, year: int) -> str:
    return next_id(s, f"EVT-{year}", 3)


def log(s: Session, action: str, target: str | None = None, detail: str | None = None, actor: str | None = None) -> None:
    s.add(ProcessingLog(at=datetime.now().replace(microsecond=0), actor=actor, action=action, target=target, detail=detail))
