"""개인정보 파기(삭제 요청 대응)와 보존기간 관리. 관리자 전용 기능.

RAW 원본 보존이 원칙이지만, 정보주체의 삭제 요청이나 보존기간 만료 시에는
해당 고객의 개인정보를 '[파기됨]'으로 바꾸고 사진·녹음 파일을 삭제합니다.
업로드했던 QR 엑셀 원본 파일 안의 해당 행도 마스킹합니다.
파기 기록(purge_log)에는 개인정보 없이 ID·건수·사유만 남깁니다.
"""
from __future__ import annotations

import csv
import io
from datetime import datetime, timedelta
from pathlib import Path

from openpyxl import load_workbook
from sqlalchemy import delete, func, select
from sqlalchemy.orm import Session

from . import db, paths
from .ingest import sha256
from .models import (Activity, Consultation, Customer, CustomerIdentifier, PurgeLog, RawCard, RawFile, RawLink,
                     RawNote, RawOther, RawQrRow, RawRecording, ReviewItem, now)

MASK = "[파기됨]"


class PurgeError(Exception):
    pass


def _delete_file(relpath: str | None) -> bool:
    f = paths.absolute(relpath)
    if f and f.exists():
        f.unlink()
        return True
    return False


def _mask_qr_rows_in_file(rf: RawFile, row_indexes: list[int]) -> None:
    f = paths.absolute(rf.stored_path)
    if not f or not f.exists():
        return
    if f.suffix.lower() in (".xlsx", ".xlsm"):
        wb = load_workbook(f)
        ws = wb[rf.meta.get("sheet")] if rf.meta and rf.meta.get("sheet") in wb.sheetnames else wb.worksheets[0]
        for r in row_indexes:
            for cell in ws[r]:
                if cell.value not in (None, ""):
                    cell.value = MASK
        wb.save(f)
        wb.close()
    elif f.suffix.lower() == ".csv":
        raw = f.read_bytes()
        for enc in ("utf-8-sig", "cp949"):
            try:
                text = raw.decode(enc)
                break
            except UnicodeDecodeError:
                continue
        rows = list(csv.reader(io.StringIO(text)))
        for r in row_indexes:
            if 0 < r <= len(rows):
                rows[r - 1] = [MASK if c else c for c in rows[r - 1]]
        buf = io.StringIO()
        csv.writer(buf, lineterminator="\n").writerows(rows)
        f.write_bytes(buf.getvalue().encode("utf-8-sig"))
    rf.sha256 = sha256(f.read_bytes())
    meta = dict(rf.meta or {})
    meta["masked_rows"] = sorted(set(meta.get("masked_rows", []) + row_indexes))
    rf.meta = meta


def purge_customer(s: Session, customer_id: str, reason: str, actor: str | None) -> dict:
    reason = (reason or "").strip()
    if not reason:
        raise PurgeError("파기 사유를 입력해 주세요")
    cust = s.get(Customer, customer_id)
    if cust is None:
        raise PurgeError("고객을 찾을 수 없습니다")
    if cust.status == "purged":
        raise PurgeError("이미 파기된 고객입니다")
    if cust.status == "merged":
        raise PurgeError(f"이 고객은 {cust.merged_into} 로 통합되었습니다. 통합된 고객 ID로 파기해 주세요")
    t = now()
    counts = {"qr": 0, "card": 0, "note": 0, "recording": 0, "other": 0, "files_deleted": 0, "consultations": 0}
    qr_by_file: dict[str, list[int]] = {}
    for link in s.scalars(select(RawLink).where(RawLink.customer_id == cust.id)):
        if link.raw_type == "qr":
            r = s.get(RawQrRow, link.raw_id)
            if r and not r.purged_at:
                qr_by_file.setdefault(r.file_id, []).append(r.row_index)
                for fld in ("name", "name_en", "company", "department", "title", "email", "mobile", "phone",
                            "interest", "memo"):
                    setattr(r, fld, MASK if getattr(r, fld) else getattr(r, fld))
                r.raw_json = {k: (MASK if v else v) for k, v in (r.raw_json or {}).items()}
                r.purged_at = t
                counts["qr"] += 1
        elif link.raw_type == "card":
            r = s.get(RawCard, link.raw_id)
            if r and not r.purged_at:
                for fld in ("name", "name_en", "company", "company_en", "department", "title", "email", "mobile",
                            "phone", "address", "website"):
                    setattr(r, fld, MASK if getattr(r, fld) else getattr(r, fld))
                if r.file_id:
                    rf = s.get(RawFile, r.file_id)
                    counts["files_deleted"] += _delete_file(rf.stored_path)
                    rf.purged_at = t
                r.purged_at = t
                counts["card"] += 1
        elif link.raw_type == "note":
            r = s.get(RawNote, link.raw_id)
            if r and not r.purged_at:
                counts["files_deleted"] += _delete_file(r.file_path)
                r.name, r.company, r.email, r.mobile, r.content = MASK, MASK, MASK, MASK, MASK
                r.purged_at = t
                counts["note"] += 1
        elif link.raw_type == "recording":
            r = s.get(RawRecording, link.raw_id)
            if r and not r.purged_at:
                rf = s.get(RawFile, r.file_id)
                counts["files_deleted"] += _delete_file(rf.stored_path) + _delete_file(r.transcript_path)
                rf.purged_at = t
                r.name, r.company, r.purged_at = MASK, MASK, t
                counts["recording"] += 1
        elif link.raw_type == "other":
            r = s.get(RawOther, link.raw_id)
            if r and not r.purged_at:
                rf = s.get(RawFile, r.file_id)
                counts["files_deleted"] += _delete_file(rf.stored_path)
                rf.purged_at = t
                r.description, r.purged_at = MASK, t
                counts["other"] += 1
    for file_id, rows in qr_by_file.items():
        _mask_qr_rows_in_file(s.get(RawFile, file_id), rows)
    for c in s.scalars(select(Consultation).where(Consultation.customer_id == cust.id)):
        c.content = MASK
        counts["consultations"] += 1
    for a in s.scalars(select(Activity).where(Activity.customer_id == cust.id)):
        a.title, a.detail = MASK, MASK
    s.execute(delete(CustomerIdentifier).where(CustomerIdentifier.customer_id == cust.id))
    for ri in s.scalars(select(ReviewItem).where(ReviewItem.status == "open", ReviewItem.customer_id == cust.id)):
        ri.status, ri.resolved_at, ri.resolved_by, ri.resolution = "resolved", t, actor, "개인정보 파기"
        ri.summary = MASK
    for fld in ("name_ko", "name_en", "department", "title", "email", "mobile", "phone", "ai_summary"):
        setattr(cust, fld, MASK if fld == "name_ko" else None)
    cust.overrides, cust.status, cust.purged_at, cust.updated_at = {}, "purged", t, t
    s.add(PurgeLog(at=t, actor=actor, target_type="customer", target_id=cust.id, reason=reason, detail=counts))
    db.log(s, "개인정보 파기", cust.id, f"사유: {reason}", actor)
    s.flush()
    return counts


def last_activity(s: Session, cid: str) -> datetime | None:
    """실제 접촉 기준 마지막 활동일 (방문·명함·상담·연락). 접촉 일시가 없으면 등록일."""
    vals = [
        s.scalar(select(func.max(RawLink.seen_at)).where(RawLink.customer_id == cid)),
        s.scalar(select(func.max(Consultation.consulted_at)).where(Consultation.customer_id == cid)),
        s.scalar(select(func.max(Activity.occurred_at)).where(Activity.customer_id == cid)),
    ]
    vals = [v for v in vals if v]
    if not vals:
        return s.scalar(select(func.max(RawLink.linked_at)).where(RawLink.customer_id == cid))
    return max(vals)


def retention_candidates(s: Session, years: int) -> list[dict]:
    limit = now() - timedelta(days=365 * years)
    out = []
    for c in s.scalars(select(Customer).where(Customer.status == "active")):
        last = last_activity(s, c.id)
        if last and last < limit:
            out.append({"customer": c, "last": last})
    return out
