"""LICHTZEN CRM 명령 프로그램. Claude Code가 사용자의 요청을 받아 이 명령을 실행합니다.

실행: 99_PROGRAM\\.venv\\Scripts\\python.exe 99_PROGRAM\\crm.py <명령> ...
도움말: crm.py -h, crm.py <명령> -h
"""
from __future__ import annotations

import argparse
import shutil
import sys
import unicodedata
from datetime import datetime
from pathlib import Path

from sqlalchemy import func, or_, select

from . import backup, db, excel_export, ingest, matching, paths, privacy, services, stats
from .models import (RAW_LABEL, Activity, Company, CompanyAlias, Consultation, Customer, CustomerIdentifier, Event,
                     MatchDecision, MergeHistory, ProcessingLog, PurgeLog, RawCard, RawFile, RawLink, RawNote,
                     ReviewItem, Staff, now)
from .normalize import clean, company_key, parse_dt
from .settings import AI_MODELS, AI_TASKS, get_settings, masked_api_key, save_settings

ACTIVITY_TYPES = ["전화 상담", "이메일 발송", "이메일 수신", "문자 발송", "문자 수신", "카탈로그 전달", "기술자료 전달",
                  "방문 미팅", "샘플 제공", "제품 테스트", "견적 요청", "견적 제출", "발주 협의", "발주 완료", "담당자 메모",
                  "다음 연락 예정"]
QR_EXT = {".xlsx", ".xlsm", ".csv"}


class CliError(Exception):
    pass


# ───────────────────────── 출력 도우미 ─────────────────────────
def _w(s: str) -> int:
    return sum(2 if unicodedata.east_asian_width(ch) in "WF" else 1 for ch in s)


def _cut(s: str, n: int) -> str:
    s = " ".join(str(s).split())
    if _w(s) <= n:
        return s
    out = ""
    for ch in s:
        if _w(out + ch) > n - 1:
            break
        out += ch
    return out + "…"


def _v(x) -> str:
    if x is None:
        return ""
    if isinstance(x, datetime):
        return x.strftime("%Y-%m-%d %H:%M")
    if isinstance(x, bool):
        return "예" if x else "아니오"
    return str(x)


def table(headers: list[str], rows: list[list], maxw: int = 36) -> None:
    rows = [[_cut(_v(c), maxw) for c in r] for r in rows]
    widths = [max([_w(h)] + [_w(r[i]) for r in rows]) for i, h in enumerate(headers)]

    def line(cells):
        return "  ".join(c + " " * (widths[i] - _w(c)) for i, c in enumerate(cells)).rstrip()

    print(line(headers))
    print("  ".join("-" * w for w in widths))
    for r in rows:
        print(line(r))
    if not rows:
        print("(없음)")


def section(title: str) -> None:
    print(f"\n■ {title}")


def kv(pairs: list[tuple[str, object]]) -> None:
    for k, v in pairs:
        if v not in (None, ""):
            print(f"  {k}: {_v(v)}")


# ───────────────────────── 공통 ─────────────────────────
def actor_name(s, by: str | None) -> str:
    if by:
        return by
    st = s.scalar(select(Staff).where(Staff.active.is_(True)).order_by(Staff.id))
    return st.name if st else "Claude"


def staff_id_of(s, by: str | None) -> str | None:
    if not by:
        st = s.scalar(select(Staff).where(Staff.active.is_(True)).order_by(Staff.id))
        return st.id if st else None
    st = s.get(Staff, by) or s.scalar(select(Staff).where(Staff.name == by))
    return st.id if st else None


def require_event(s, eid: str) -> Event:
    ev = s.get(Event, eid)
    if ev is None:
        raise CliError(f"행사 {eid} 가 없습니다. 'crm.py event list' 로 확인하세요")
    return ev


def require_customer(s, cid: str) -> Customer:
    c = s.get(Customer, cid)
    if c is None:
        raise CliError(f"고객 {cid} 가 없습니다")
    if c.status == "merged":
        print(f"(참고) {cid} 는 {c.merged_into} 로 통합된 고객입니다 → {c.merged_into} 를 표시합니다")
        return require_customer(s, c.merged_into)
    return c


def after_ingest(s, event_ids, by) -> None:
    counts, warns = services.after_ingest(s, event_ids, by)
    print(f"자동 매칭: {services.counts_message(counts)}")
    for w in warns:
        print("⚠", w)
    print("엑셀 갱신 완료")


def who(c: Customer | None) -> str:
    if c is None:
        return ""
    return f"{c.name_ko or c.name_en or '(이름 없음)'}{' / ' + c.name_en if c.name_ko and c.name_en else ''}" \
           f" · {c.company_display or '회사 미상'}"


# ───────────────────────── 명령: 현황 ─────────────────────────
def cmd_status(s, a):
    d = stats.dashboard(s)
    cfg = get_settings(s)
    print("LICHTZEN CRM 현황")
    kv([("전체 고객", d["customers"]), ("전체 기업", d["companies"]), ("행사", d["events"]),
        ("누적 상담", d["consultations"]), ("재방문 고객", d["revisit"]),
        ("국내 / 해외", f"{d['domestic']} / {d['overseas']}"), ("확인 필요 항목", d["reviews"]),
        ("명함 OCR 대기", d["ocr_pending"]), ("AI 분석 대기 상담", d["ai_pending"]),
        ("AI 모드", "수동 (Claude Code 처리, API 미사용)" if cfg["ai"]["mode"] == "manual" else "API 자동"),
        ("업무 폴더", paths.base_dir())])
    inbox = [f for f in paths.p("00_START_HERE", "INBOX").rglob("*") if f.is_file() and "_처리완료" not in f.parts]
    if inbox:
        print(f"  INBOX 미처리 파일: {len(inbox)}개")
    section("행사별")
    rows = []
    for e in s.scalars(select(Event).order_by(Event.start_date)):
        sm = stats.event_summary(s, e.id)
        rows.append([e.id, e.name, e.start_date.strftime("%Y-%m-%d") if e.start_date else "", e.status, sm["visitors"],
                     sm["상담 고객"], sm["일반 방문객"], sm["확인 필요 고객"], sm["new"], sm["revisit"]])
    table(["행사 ID", "행사명", "시작일", "상태", "방문", "상담", "일반", "확인필요", "신규", "재방문"], rows)


# ───────────────────────── 명령: 행사 ─────────────────────────
def cmd_event_add(s, a):
    ev = services.create_event(s, a.name, a.type, a.start or "", a.end or "", a.location or "", a.memo or "",
                               actor_name(s, a.by))
    s.commit()
    excel_export.refresh_all(s, [ev.id])
    print(f"행사 등록: {ev.id} {ev.name}")
    print(f"원본 폴더: 01_RAW_DATA/{ev.folder_name}")


def cmd_event_list(s, a):
    rows = []
    for e in s.scalars(select(Event).order_by(Event.start_date)):
        sm = stats.event_summary(s, e.id)
        rows.append([e.id, e.name, e.type, e.start_date.strftime("%Y-%m-%d") if e.start_date else "",
                     e.end_date.strftime("%Y-%m-%d") if e.end_date else "", e.location, e.status, sm["visitors"]])
    table(["행사 ID", "행사명", "유형", "시작", "종료", "장소", "상태", "방문 고객"], rows)


def cmd_event_show(s, a):
    ev = require_event(s, a.event_id)
    sm = stats.event_summary(s, ev.id)
    print(f"{ev.id} {ev.name} ({ev.type})")
    kv([("기간", f"{_v(ev.start_date)[:10]} ~ {_v(ev.end_date)[:10]}"), ("장소", ev.location), ("상태", ev.status),
        ("상담 등록 완료", ev.consult_closed_at), ("원본 폴더", f"01_RAW_DATA/{ev.folder_name}")])
    kv([("방문 고객", sm["visitors"]), ("상담 고객", sm["상담 고객"]), ("일반 방문객", sm["일반 방문객"]),
        ("확인 필요", sm["확인 필요 고객"]), ("신규 / 기존", f"{sm['new']} / {sm['existing']}"), ("재방문", sm["revisit"]),
        ("명함 OCR 대기", sm["ocr_pending"]), ("녹음 변환 대기", sm["stt_pending"])])
    rows = stats.classify_event(s, ev.id)
    if a.cat:
        rows = [r for r in rows if a.cat in r["category"]]
    section(f"방문 고객 {len(rows)}명" + (f" ({a.cat})" if a.cat else ""))
    table(["고객 ID", "이름", "회사", "이메일", "휴대폰", "분류", "신규", "재방문"],
          [[r["customer"].id, r["customer"].name_ko or r["customer"].name_en, r["customer"].company_display,
            r["customer"].email, r["customer"].mobile, r["category"], "신규" if r["is_new"] else "기존",
            "재방문" if r["is_revisit"] else ""] for r in rows])


def cmd_event_status(s, a):
    ev = services.set_event_status(s, a.event_id, a.status, actor_name(s, a.by))
    s.commit()
    print(f"{ev.id} 상태 → {ev.status}")


# ───────────────────────── 명령: 수집 ─────────────────────────
def _files(items: list[str]) -> list[Path]:
    out = []
    for it in items:
        p = Path(it)
        if p.is_dir():
            out += [f for f in sorted(p.iterdir()) if f.is_file()]
        elif p.exists():
            out.append(p)
        else:
            raise CliError(f"파일을 찾을 수 없습니다: {it}")
    return out


def cmd_import_qr(s, a):
    require_event(s, a.event_id)
    by = actor_name(s, a.by)
    ok = 0
    for f in _files(a.files):
        try:
            r = ingest.ingest_qr(s, a.event_id, f.name, f.read_bytes(), by)
            s.commit()
            ok += 1
            print(f"✔ {f.name}: {r['added']}행 추가, 중복 {r['skipped']}행 제외")
            print(f"  인식한 열: {', '.join(f'{k}→{v}' for k, v in r['mapping'].items())}")
            if r["unmapped"]:
                print(f"  인식 못 한 열(원본에는 보존): {', '.join(r['unmapped'])}")
        except ingest.IngestError as e:
            s.rollback()
            print(f"✖ {f.name}: {e}")
    if ok:
        after_ingest(s, [a.event_id], by)


def cmd_import_card(s, a):
    by = actor_name(s, a.by)
    fields = {k: getattr(a, k) or "" for k in ingest.CARD_FIELDS}
    files = _files(a.file) if a.file else []
    if len(files) > 1 and any(fields.values()):
        raise CliError("명함 정보를 직접 입력할 때는 사진을 1장만 지정하세요")
    targets = files or [None]
    n = 0
    for f in targets:
        try:
            card = ingest.ingest_card(s, a.event, f.name if f else None, f.read_bytes() if f else None,
                                      fields if len(targets) == 1 else {}, by, parse_dt(a.at) if a.at else None)
            s.commit()
            n += 1
            print(f"✔ {card.id} {'(OCR 대기)' if card.ocr_status == 'pending' else ''} {f.name if f else ''}")
        except ingest.IngestError as e:
            s.rollback()
            print(f"✖ {f.name if f else '명함'}: {e}")
    if n:
        after_ingest(s, [a.event], by)


def _read_text(a) -> str:
    if a.text_file:
        return Path(a.text_file).read_text(encoding="utf-8")
    return a.text or ""


def cmd_import_note(s, a):
    by = actor_name(s, a.by)
    note = ingest.ingest_note(s, a.event, _read_text(a), by, customer_id=a.customer, name=a.name or "",
                              company=a.company or "", email=a.email or "", mobile=a.mobile or "",
                              channel=a.channel, consulted_at=parse_dt(a.at) if a.at else None,
                              staff_id=staff_id_of(s, a.staff or a.by))
    s.commit()
    print(f"✔ 상담 원본 저장: {note.id}")
    after_ingest(s, [a.event], by)
    link = s.scalar(select(RawLink).where(RawLink.raw_type == "note", RawLink.raw_id == note.id))
    if link:
        c = s.get(Customer, link.customer_id)
        con = s.scalar(select(Consultation).where(Consultation.raw_note_id == note.id))
        print(f"→ 고객 {c.id} {who(c)} 에 연결, 상담 ID {con.id if con else ''}")
        ri = s.scalar(select(ReviewItem).where(ReviewItem.raw_id == note.id, ReviewItem.status == "open"))
        if ri:
            print(f"⚠ 동일인 확인 필요: {ri.id} — {ri.summary}")


def cmd_import_recording(s, a):
    by = actor_name(s, a.by)
    f = Path(a.file)
    rec = ingest.ingest_recording(s, a.event, f.name, f.read_bytes(), by, consent=bool(a.consent),
                                  consent_method=a.consent or "", customer_id=a.customer, name=a.name or "",
                                  company=a.company or "", recorded_at=parse_dt(a.at) if a.at else None,
                                  staff_id=staff_id_of(s, a.staff or a.by))
    s.commit()
    print(f"✔ 녹음 등록: {rec.id} (텍스트 변환은 M4 단계)")
    after_ingest(s, [a.event], by)


def cmd_import_other(s, a):
    by = actor_name(s, a.by)
    n = 0
    for f in _files(a.files):
        try:
            o = ingest.ingest_other(s, a.event, f.name, f.read_bytes(), by, description=a.desc or "",
                                    customer_id=a.customer)
            s.commit()
            n += 1
            print(f"✔ {o.id} {f.name}")
        except ingest.IngestError as e:
            s.rollback()
            print(f"✖ {f.name}: {e}")
    if n:
        after_ingest(s, [a.event], by)


def cmd_inbox(s, a):
    """INBOX 폴더의 파일을 종류별로 자동 등록. INBOX/EVT-xxxx-xxx/ 하위 폴더는 그 행사로 등록."""
    inbox = paths.p("00_START_HERE", "INBOX")
    done_dir = inbox / "_처리완료" / datetime.now().strftime("%Y%m%d")
    by = actor_name(s, a.by)
    jobs: list[tuple[Path, str | None]] = []
    for f in sorted(inbox.iterdir()):
        if f.is_file():
            jobs.append((f, a.event_id))
        elif f.is_dir() and f.name.startswith("EVT-"):
            eid = "-".join(f.name.split("-")[:3]).split("_")[0]
            jobs += [(x, eid) for x in sorted(f.iterdir()) if x.is_file()]
    if not jobs:
        print("INBOX 에 처리할 파일이 없습니다")
        return
    touched = set()
    for f, eid in jobs:
        ext = f.suffix.lower()
        if eid is None:
            print(f"… {f.name}: 행사가 지정되지 않아 건너뜀 (crm.py inbox <행사ID>)")
            continue
        if s.get(Event, eid) is None:
            print(f"✖ {f.name}: 행사 {eid} 가 없음")
            continue
        if ext in ingest.AUDIO_EXT:
            print(f"… {f.name}: 녹음은 동의 확인이 필요해 자동 등록하지 않음 → import recording ... --consent '동의 방식'")
            continue
        if a.dry_run:
            kind = "QR 엑셀" if ext in QR_EXT else ("명함 사진(OCR 대기)" if ext in ingest.IMAGE_EXT else "기타 자료")
            print(f"[미리보기] {f.name} → {eid} {kind}")
            continue
        try:
            if ext in QR_EXT:
                r = ingest.ingest_qr(s, eid, f.name, f.read_bytes(), by)
                print(f"✔ {f.name} → {eid} QR {r['added']}행 추가, 중복 {r['skipped']}행 제외")
            elif ext in ingest.IMAGE_EXT:
                card = ingest.ingest_card(s, eid, f.name, f.read_bytes(), {}, by)
                print(f"✔ {f.name} → {eid} 명함 {card.id} (OCR 대기)")
            else:
                o = ingest.ingest_other(s, eid, f.name, f.read_bytes(), by)
                print(f"✔ {f.name} → {eid} 기타 자료 {o.id}")
            s.commit()
            touched.add(eid)
            result = "처리"
        except ingest.IngestError as e:
            s.rollback()
            if "이미 업로드된 파일" not in str(e):
                print(f"✖ {f.name}: {e} (INBOX 에 그대로 둠)")
                continue
            print(f"= {f.name}: {e}")
            result = "중복"
        done_dir.mkdir(parents=True, exist_ok=True)
        target = done_dir / f"{result}_{f.name}"
        i = 1
        while target.exists():
            target = done_dir / f"{result}_{i}_{f.name}"
            i += 1
        shutil.move(str(f), target)
    if touched:
        after_ingest(s, sorted(touched), by)
    if not a.dry_run:
        print(f"처리한 파일은 INBOX/_처리완료/{done_dir.name}/ 로 옮겼습니다 (원본은 01_RAW_DATA 에 보관)")


def cmd_process(s, a):
    after_ingest(s, [], actor_name(s, a.by))
    s.commit()


# ───────────────────────── 명령: 고객 ─────────────────────────
def cmd_customer_search(s, a):
    q = clean(" ".join(a.query))
    like = f"%{q}%"
    conds = [Customer.name_ko.like(like), Customer.name_en.like(like), Customer.company_display.like(like),
             Customer.email.like(like), Customer.id.like(like)]
    digits = "".join(ch for ch in q if ch.isdigit())
    if len(digits) >= 4:
        conds.append(Customer.id.in_(select(CustomerIdentifier.customer_id).where(
            CustomerIdentifier.kind.in_(("mobile", "landline")),
            CustomerIdentifier.value.like(f"%{digits.lstrip('0')}%"))))
    conds.append(Customer.company_id.in_(select(CompanyAlias.company_id).where(CompanyAlias.alias.like(like))))
    custs = list(s.scalars(select(Customer).where(Customer.status == "active", or_(*conds)).order_by(Customer.id)))
    vidx = stats.visit_index(s)
    review = stats.review_customer_ids(s)
    table(["고객 ID", "이름", "영문", "회사", "직급", "이메일", "휴대폰", "방문 행사", "비고"],
          [[c.id, c.name_ko, c.name_en, c.company_display, c.title, c.email, c.mobile, len(vidx.get(c.id, [])),
            "확인 필요" if c.id in review else ""] for c in custs[:100]])
    if len(custs) > 100:
        print(f"... 외 {len(custs) - 100}명")


def customer_timeline(s, cid: str) -> list[list]:
    evs = {e.id: e.name for e in s.scalars(select(Event))}
    items = []
    for l in matching.links_of(s, cid):
        label = {"qr": "전시회 방문(QR)", "card": "명함 등록", "note": "상담", "recording": "상담 녹음",
                 "other": "기타 자료"}[l.raw_type]
        detail = ""
        if l.raw_type == "note":
            n = s.get(RawNote, l.raw_id)
            if n:
                label, detail = n.channel, n.content
        items.append([l.seen_at or l.linked_at, label, evs.get(l.event_id, ""), detail, l.raw_id])
    for act in s.scalars(select(Activity).where(Activity.customer_id == cid)):
        items.append([act.occurred_at, act.type, evs.get(act.event_id, ""), act.title or "", act.id])
    items.sort(key=lambda x: x[0] or datetime.min)
    if items:
        items[0][1] = "★최초 접촉 · " + items[0][1]
    return items


def cmd_customer_show(s, a):
    c = require_customer(s, a.customer_id)
    if c.status == "purged":
        print(f"{c.id}: 개인정보가 파기된 고객입니다 ({_v(c.purged_at)})")
        return
    comp = s.get(Company, c.company_id) if c.company_id else None
    staff = {x.id: x.name for x in s.scalars(select(Staff))}
    print(f"{c.id}  {who(c)}")
    kv([("부서/직급", " ".join(x for x in (c.department, c.title) if x)), ("이메일", c.email), ("휴대폰", c.mobile),
        ("전화", c.phone), ("국가", c.country), ("구분", "국내" if c.is_domestic else ("해외" if c.is_domestic is False else "")),
        ("언어", c.language), ("기업", f"{comp.id} {comp.name}{' / ' + comp.name_en if comp.name_en else ''}" if comp else ""),
        ("담당자", staff.get(c.owner_staff_id)), ("최초 접촉", c.first_seen_at),
        ("직접 수정한 값", ", ".join(f"{k}={v}" for k, v in (c.overrides or {}).items())),
        ("AI 요약", c.ai_summary)])
    evs = {e.id: e for e in s.scalars(select(Event))}
    section("방문 이력")
    rows = []
    for eid in stats.visit_index(s).get(c.id, []):
        cat = next((r["category"] for r in stats.classify_event(s, eid) if r["customer"].id == c.id), "")
        rows.append([eid, evs[eid].name if eid in evs else "", cat])
    table(["행사 ID", "행사명", "분류"], rows)
    section("상담 이력 (과거 → 현재, 덮어쓰지 않음)")
    for con in s.scalars(select(Consultation).where(Consultation.customer_id == c.id).order_by(Consultation.consulted_at)):
        print(f"  [{con.id}] {_v(con.consulted_at)} · {con.channel} · {evs[con.event_id].name if con.event_id in evs else '행사 외'}"
              f" · 담당 {staff.get(con.staff_id, '')} · AI분석 {con.ai_status}")
        for line in con.content.splitlines():
            print(f"      {line}")
    section("활동 타임라인")
    table(["일시", "활동", "행사", "내용", "원본 ID"], customer_timeline(s, c.id), maxw=50)
    if not a.brief:
        section("연결된 원본 자료 · 통합 근거 (잘못 붙은 자료는 'crm.py detach <고객ID> <연결번호>')")
        rows = []
        for l in matching.links_of(s, c.id):
            d = s.get(MatchDecision, l.decision_id) if l.decision_id else None
            ev = "; ".join(f"{e['항목']}({e['점수']:+d})" if e["점수"] else e["항목"] for e in (d.evidence or [])) if d else ""
            dec = {"auto_merge": "자동 통합", "new": "신규 생성", "review": "확인 필요로 생성",
                   "manual_assign": "직접 지정"}.get(d.decision, d.decision) if d else ""
            rows.append([l.id, RAW_LABEL.get(l.raw_type), l.raw_id, l.event_id, _v(l.seen_at), dec,
                         d.score if d and d.score is not None else "", ev])
        table(["연결번호", "종류", "원본 ID", "행사", "일시", "판정", "점수", "근거"], rows, maxw=60)
        hist = list(s.scalars(select(MergeHistory).where(or_(MergeHistory.source_customer == c.id,
                                                             MergeHistory.target_customer == c.id))))
        if hist:
            section("통합·분리 기록 (되돌리기: 'crm.py undo <기록번호>')")
            table(["기록번호", "작업", "자료 나간 고객", "자료 들어간 고객", "일시", "사유", "되돌림"],
                  [[h.id, "통합" if h.action == "merge" else "분리", h.source_customer, h.target_customer, h.at,
                    h.reason, _v(h.reverted_at)] for h in hist])
        if comp:
            others = list(s.scalars(select(Customer).where(Customer.company_id == comp.id, Customer.status == "active",
                                                           Customer.id != c.id)))
            if others:
                section(f"같은 기업의 다른 담당자 ({comp.name})")
                table(["고객 ID", "이름", "부서", "직급", "이메일"],
                      [[o.id, o.name_ko or o.name_en, o.department, o.title, o.email] for o in others])
    reviews = list(s.scalars(select(ReviewItem).where(ReviewItem.status == "open", or_(
        ReviewItem.customer_id == c.id, ReviewItem.candidate_customer_id == c.id))))
    for ri in reviews:
        print(f"\n⚠ 확인 필요 {ri.id}: {ri.summary}")


EDITABLE = {"name_ko", "name_en", "department", "title", "email", "mobile", "phone", "country", "language"}


def cmd_customer_edit(s, a):
    vals = {}
    for item in a.values:
        if "=" not in item:
            raise CliError(f"'항목=값' 형식이어야 합니다: {item}")
        k, v = item.split("=", 1)
        if k == "owner":
            c = require_customer(s, a.customer_id)
            c.owner_staff_id = staff_id_of(s, v) if v else None
            continue
        if k not in EDITABLE:
            raise CliError(f"수정할 수 없는 항목: {k} (가능: {', '.join(sorted(EDITABLE))}, owner)")
        vals[k] = v
    if vals:
        matching.set_overrides(s, a.customer_id, vals, actor_name(s, a.by))
    s.commit()
    excel_export.export_master(s)
    print("저장했습니다 (직접 수정한 값은 자동 갱신보다 우선합니다. 값을 비우면 자동값으로 돌아감)")


def cmd_activity(s, a):
    c = require_customer(s, a.customer_id)
    if a.type not in ACTIVITY_TYPES:
        raise CliError(f"활동 종류는 다음 중 하나: {', '.join(ACTIVITY_TYPES)}")
    act = Activity(id=db.next_id(s, "ACT"), customer_id=c.id, event_id=a.event, type=a.type, title=clean(a.text),
                   occurred_at=parse_dt(a.at) if a.at else now(), staff_id=staff_id_of(s, a.by), created_at=now())
    s.add(act)
    c.last_contact_at = max(x for x in (c.last_contact_at, act.occurred_at) if x)
    db.log(s, "활동 기록", c.id, a.type, actor_name(s, a.by))
    s.commit()
    print(f"✔ {act.id} {c.id} {a.type}: {act.title}")


def cmd_detach(s, a):
    link = s.get(RawLink, a.link_id)
    if link is None or link.customer_id != a.customer_id:
        raise CliError("해당 고객의 연결번호가 아닙니다. 'crm.py customer show <고객ID>' 로 확인하세요")
    new = matching.detach_link(s, a.link_id, actor_name(s, a.by), a.reason or "")
    s.commit()
    excel_export.refresh_all(s)
    print(f"✔ {link.raw_type} {link.raw_id} 를 분리해 새 고객 {new.id} 를 만들었습니다 ({who(new)})")


def cmd_merge(s, a):
    hist = matching.merge_customers(s, a.source, a.target, actor_name(s, a.by), a.reason or "담당자 수동 통합")
    s.commit()
    excel_export.refresh_all(s)
    print(f"✔ {a.source} → {a.target} 통합 (되돌리기: crm.py undo {hist.id})")


def cmd_undo(s, a):
    matching.undo_history(s, a.history_id, actor_name(s, a.by))
    s.commit()
    excel_export.refresh_all(s)
    print(f"✔ 기록 {a.history_id} 를 되돌렸습니다")


# ───────────────────────── 명령: 기업 ─────────────────────────
def cmd_company_list(s, a):
    qy = select(Company).where(Company.status == "active")
    if a.query:
        like = f"%{' '.join(a.query)}%"
        qy = qy.where(or_(Company.name.like(like), Company.name_en.like(like), Company.domain.like(like),
                          Company.id.in_(select(CompanyAlias.company_id).where(CompanyAlias.alias.like(like)))))
    counts = dict(s.execute(select(Customer.company_id, func.count()).where(Customer.status == "active")
                            .group_by(Customer.company_id)).all())
    table(["기업 ID", "회사명", "영문명", "도메인", "국가", "고객 수"],
          [[c.id, c.name, c.name_en, c.domain, c.country, counts.get(c.id, 0)] for c in s.scalars(qy.order_by(Company.id))])


def cmd_company_show(s, a):
    comp = s.get(Company, a.company_id)
    if comp is None:
        raise CliError("기업을 찾을 수 없습니다")
    print(f"{comp.id}  {comp.name}{' / ' + comp.name_en if comp.name_en else ''}")
    kv([("도메인", comp.domain), ("국가", comp.country),
        ("표기(별칭)", ", ".join(x.alias for x in s.scalars(select(CompanyAlias).where(CompanyAlias.company_id == comp.id))))])
    members = list(s.scalars(select(Customer).where(Customer.company_id == comp.id, Customer.status == "active")))
    section(f"소속 담당자 {len(members)}명")
    vidx = stats.visit_index(s)
    table(["고객 ID", "이름", "부서", "직급", "이메일", "휴대폰", "방문 행사"],
          [[m.id, m.name_ko or m.name_en, m.department, m.title, m.email, m.mobile, len(vidx.get(m.id, []))] for m in members])
    section("기업 통합 영업 히스토리")
    rows = []
    for m in members:
        for t in customer_timeline(s, m.id):
            rows.append([t[0], m.name_ko or m.name_en, t[1], t[2], t[3]])
    rows.sort(key=lambda x: x[0] or datetime.min)
    table(["일시", "담당자", "활동", "행사", "내용"], rows, maxw=50)


def cmd_company_alias(s, a):
    k = company_key(a.alias)
    owner = s.scalar(select(CompanyAlias.company_id).where(CompanyAlias.alias_key == k))
    if owner and owner != a.company_id:
        raise CliError(f"이 표기는 이미 {owner} 기업에 등록되어 있습니다")
    if not owner:
        s.add(CompanyAlias(company_id=a.company_id, alias=clean(a.alias), alias_key=k, source="manual"))
        s.commit()
    print(f"✔ {a.company_id} 에 표기 '{a.alias}' 추가")


# ───────────────────────── 명령: 확인 필요 ─────────────────────────
def _cust_brief(s, c: Customer | None) -> list[str]:
    if c is None:
        return ["(없음)"]
    evs = stats.visit_index(s).get(c.id, [])
    return [f"{c.id} {c.name_ko or ''} {c.name_en or ''}".strip(), f"회사: {c.company_display or ''}",
            f"부서/직급: {c.department or ''} {c.title or ''}", f"이메일: {c.email or ''}",
            f"휴대폰: {c.mobile or ''}  전화: {c.phone or ''}", f"방문 행사: {', '.join(evs)}"]


def cmd_review_list(s, a):
    q = select(ReviewItem).order_by(ReviewItem.id)
    if not a.all:
        q = q.where(ReviewItem.status == "open")
    items = list(s.scalars(q))
    if not items:
        print("확인 필요 항목이 없습니다")
        return
    for ri in items:
        print(f"\n[{ri.id}] {'처리됨: ' + (ri.resolution or '') if ri.status != 'open' else ''}")
        print(f"  {ri.summary}")
        if ri.kind == "match":
            left = _cust_brief(s, s.get(Customer, ri.customer_id))
            right = _cust_brief(s, s.get(Customer, ri.candidate_customer_id))
            print("  ┌ 새로 들어온 자료")
            for x in left:
                print(f"  │  {x}")
            print("  ├ 기존 고객 후보")
            for x in right:
                print(f"  │  {x}")
            d = s.get(MatchDecision, ri.decision_id) if ri.decision_id else None
            if d:
                print("  └ 판단 근거: " + "; ".join(f"{e['항목']}({e['점수']:+d})" for e in d.evidence or []) +
                      f" = {d.score}점")
            if ri.status == "open":
                print(f"    → 같은 사람: crm.py review same {ri.id} / 다른 사람: crm.py review different {ri.id}")
        else:
            print(f"    → 고객 지정: crm.py review assign {ri.id} <고객ID>")


def cmd_review_decide(s, a, same: bool):
    matching.resolve_review(s, a.review_id, same, actor_name(s, a.by))
    s.commit()
    excel_export.refresh_all(s)
    print(f"✔ {a.review_id}: {'같은 사람 → 통합' if same else '다른 사람으로 확정'}")


def cmd_review_assign(s, a):
    matching.assign_raw(s, a.review_id, a.customer_id, actor_name(s, a.by))
    s.commit()
    excel_export.refresh_all(s)
    print(f"✔ {a.review_id}: {a.customer_id} 에 연결")


# ───────────────────────── 명령: 관리 ─────────────────────────
def cmd_export(s, a):
    for w in excel_export.refresh_all(s):
        print("⚠", w)
    db.log(s, "엑셀 전체 갱신", None, None, actor_name(s, a.by))
    s.commit()
    print("✔ 모든 엑셀을 다시 만들었습니다")
    for f in ("01_RAW_DATA/00_ALL_EVENTS/RAW_전체행사.xlsx", "02_CUSTOMER_MASTER/LICHTZEN_CRM_통합관리.xlsx",
              "02_CUSTOMER_MASTER/전체고객통합.xlsx", "02_CUSTOMER_MASTER/전체기업통합.xlsx",
              "03_CONSULTATION_HISTORY/전체상담이력.xlsx", "10_REVIEW_REQUIRED/확인필요항목.xlsx"):
        print("  -", f)
    print("  - 행사별: 01_RAW_DATA/<행사>/RAW_<행사ID>.xlsx, 08_REPORTS/행사별/<행사ID>_통합.xlsx")


def cmd_backup(s, a):
    if a.list:
        table(["파일", "크기(KB)", "일시"], [[b["name"], b["size_kb"], b["at"]] for b in backup.list_backups()])
        return
    s.close()
    f = backup.create_backup("manual", full=a.full)
    print(f"✔ 백업: 09_BACKUP/{f.name}")


def cmd_restore(s, a):
    if not a.yes:
        raise CliError("복구는 현재 DB를 백업 시점으로 되돌립니다. 확인했다면 --yes 를 붙여 실행하세요")
    s.close()
    safety = backup.restore_backup(a.name)
    with db.session_scope() as s2:
        db.log(s2, "복구", a.name, f"복구 직전 상태: {safety.name}", a.by)
        excel_export.refresh_all(s2)
    print(f"✔ {a.name} 으로 복구했습니다. 복구 직전 상태는 09_BACKUP/{safety.name} 에 있습니다")


def cmd_purge(s, a):
    if a.confirm != a.customer_id:
        raise CliError("--confirm 에 파기할 고객 ID를 똑같이 한 번 더 입력해야 합니다")
    by = actor_name(s, a.by)
    st = s.scalar(select(Staff).where(Staff.name == by))
    if st is None or st.role != "관리자":
        raise CliError("관리자만 개인정보를 파기할 수 있습니다 (--by <관리자 이름>)")
    s.commit()
    backup.create_backup("pre_purge")
    counts = privacy.purge_customer(s, a.customer_id, a.reason, by)
    s.commit()
    excel_export.refresh_all(s)
    print(f"✔ {a.customer_id} 개인정보 파기 완료: " + ", ".join(f"{k} {v}" for k, v in counts.items()))
    print("  파기 직전 상태는 09_BACKUP 의 pre_purge 백업에 있습니다 (법적 보존 의무가 없다면 그 백업도 정리하세요)")


def cmd_retention(s, a):
    years = a.years or int(get_settings(s)["retention_years"])
    rows = privacy.retention_candidates(s, years)
    print(f"마지막 접촉이 {years}년 이상 지난 고객 (파기 검토 대상)")
    table(["고객 ID", "이름", "회사", "마지막 접촉"],
          [[r["customer"].id, r["customer"].name_ko or r["customer"].name_en, r["customer"].company_display, r["last"]]
           for r in rows])


def cmd_log(s, a):
    table(["일시", "작업자", "작업", "대상", "내용"],
          [[l.at, l.actor, l.action, l.target, l.detail] for l in
           s.scalars(select(ProcessingLog).order_by(ProcessingLog.id.desc()).limit(a.n))], maxw=60)
    purges = list(s.scalars(select(PurgeLog).order_by(PurgeLog.id.desc()).limit(10)))
    if purges:
        section("개인정보 파기 기록")
        table(["일시", "작업자", "대상", "사유"], [[p.at, p.actor, p.target_id, p.reason] for p in purges])


def cmd_staff(s, a):
    if a.add:
        st = services.add_staff(s, a.add, a.email or "", a.phone or "", a.role)
        s.commit()
        print(f"✔ 담당자 추가: {st.id} {st.name} ({st.role})")
    if a.rename:
        sid, name = a.rename
        st = s.get(Staff, sid)
        if st is None:
            raise CliError("담당자 ID가 없습니다")
        st.name = name
        s.commit()
        print(f"✔ {sid} 이름 → {name}")
    table(["ID", "이름", "역할", "이메일", "전화", "사용"],
          [[x.id, x.name, x.role, x.email, x.phone, x.active] for x in s.scalars(select(Staff).order_by(Staff.id))])


def cmd_settings(s, a):
    if a.set:
        new: dict = {}
        for item in a.set:
            k, _, v = item.partition("=")
            keys = k.split(".")
            val: object = v
            if v.lower() in ("true", "false"):
                val = v.lower() == "true"
            elif v.isdigit():
                val = int(v)
            if keys[0] == "ai" and keys[-1] in ("mode",) and v not in ("manual", "api"):
                raise CliError("ai.mode 는 manual 또는 api")
            if keys[0] == "ai" and keys[-1] == "api_calls_approved" and val is True:
                print("⚠ API 호출 승인을 켰습니다. 유료 호출이 발생할 수 있으니 사용자 승인 후에만 사용하세요")
            d = new
            for kk in keys[:-1]:
                d = d.setdefault(kk, {})
            d[keys[-1]] = val
        save_settings(s, new)
        s.commit()
    cfg = get_settings(s)
    print(f"AI 모드: {cfg['ai']['mode']} · API 호출 승인: {cfg['ai']['api_calls_approved']} · API 키: {masked_api_key() or '미등록'}")
    print(f"기본 모델: {cfg['ai']['default_model']} · 월 한도: {cfg['ai']['monthly_limit_krw']:,}원 · 환율 {cfg['ai']['usd_krw']}")
    for t, label in AI_TASKS.items():
        print(f"  {label}: {cfg['ai']['task_models'].get(t) or '(기본 모델)'}")
    print(f"매칭: 자동 통합 {cfg['matching']['auto_merge_min']}점↑ + 이메일/휴대폰 일치, 확인 필요 {cfg['matching']['review_min']}점↑, "
          f"시간 근접 ±{cfg['matching']['time_window_min']}분")
    print("연락 주기(일): " + ", ".join(f"{k} {v}" for k, v in cfg["contact_cycle_days"].items()))
    print(f"장기 미연락 기준: {cfg['long_no_contact_days']}일 · 개인정보 보존기간: {cfg['retention_years']}년")
    print("사용 가능한 모델: " + ", ".join(f"{k}({v['label']})" for k, v in AI_MODELS.items()))


def cmd_demo(s, a):
    sys.path.insert(0, str(paths.PROGRAM_DIR / "tests"))
    from demo_data import load_demo
    if s.scalar(select(func.count()).select_from(Event)):
        raise CliError("이미 데이터가 있는 폴더입니다. 데모는 --demo 옵션(별도 폴더)에서만 실행하세요")
    info = load_demo(s, a.by or "데모")
    s.commit()
    excel_export.refresh_all(s)
    print(f"✔ 가상 데모 데이터 생성: {info['e1']}, {info['e2']} (폴더: {paths.base_dir()})")


# ───────────────────────── 인자 정의 ─────────────────────────
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="crm.py", description="LICHTZEN CRM 명령 프로그램")
    p.add_argument("--demo", action="store_true", help="실제 데이터 대신 99_PROGRAM/demo_workspace 사용")
    p.add_argument("--by", help="작업자 이름 (기록용)")
    sub = p.add_subparsers(dest="cmd", required=True)

    sub.add_parser("status", help="전체 현황").set_defaults(fn=cmd_status)

    ev = sub.add_parser("event", help="행사 관리").add_subparsers(dest="sub", required=True)
    x = ev.add_parser("add", help="행사 등록")
    x.add_argument("--name", required=True)
    x.add_argument("--type", default="전시회", choices=services.EVENT_TYPES)
    x.add_argument("--start")
    x.add_argument("--end")
    x.add_argument("--location")
    x.add_argument("--memo")
    x.set_defaults(fn=cmd_event_add)
    ev.add_parser("list").set_defaults(fn=cmd_event_list)
    x = ev.add_parser("show", help="행사 현황과 방문 고객")
    x.add_argument("event_id")
    x.add_argument("--cat", help="상담 / 일반 / 확인")
    x.set_defaults(fn=cmd_event_show)
    x = ev.add_parser("status", help="행사 상태 변경 (상담등록완료 등)")
    x.add_argument("event_id")
    x.add_argument("status", choices=services.EVENT_STATUSES)
    x.set_defaults(fn=cmd_event_status)

    im = sub.add_parser("import", help="RAW 자료 등록").add_subparsers(dest="sub", required=True)
    x = im.add_parser("qr", help="QR 방문객 엑셀/CSV")
    x.add_argument("event_id")
    x.add_argument("files", nargs="+")
    x.set_defaults(fn=cmd_import_qr)
    x = im.add_parser("card", help="명함 (사진 및/또는 정보)")
    x.add_argument("--event")
    x.add_argument("--file", nargs="*")
    x.add_argument("--at", help="명함 받은 일시")
    for f in ingest.CARD_FIELDS:
        x.add_argument(f"--{f.replace('_', '-')}", dest=f)
    x.set_defaults(fn=cmd_import_card)
    x = im.add_parser("note", help="상담 내용")
    x.add_argument("--event")
    x.add_argument("--customer", help="고객 ID (알면)")
    x.add_argument("--name")
    x.add_argument("--company")
    x.add_argument("--email")
    x.add_argument("--mobile")
    x.add_argument("--channel", default="현장 상담", choices=["현장 상담", "전화 상담", "방문 미팅", "화상 미팅", "이메일 상담", "기타"])
    x.add_argument("--at", help="상담 일시 (예: 2026-10-14 10:20)")
    x.add_argument("--staff", help="상담 담당자 이름 또는 ID")
    x.add_argument("--text")
    x.add_argument("--text-file", dest="text_file")
    x.set_defaults(fn=cmd_import_note)
    x = im.add_parser("recording", help="상담 녹음 (동의 필수)")
    x.add_argument("file")
    x.add_argument("--event")
    x.add_argument("--consent", help="녹음 동의 방식 (예: 구두 동의). 없으면 등록 불가")
    x.add_argument("--customer")
    x.add_argument("--name")
    x.add_argument("--company")
    x.add_argument("--at")
    x.add_argument("--staff")
    x.set_defaults(fn=cmd_import_recording)
    x = im.add_parser("other", help="기타 자료")
    x.add_argument("files", nargs="+")
    x.add_argument("--event")
    x.add_argument("--desc")
    x.add_argument("--customer")
    x.set_defaults(fn=cmd_import_other)

    x = sub.add_parser("inbox", help="00_START_HERE/INBOX 의 파일 일괄 등록")
    x.add_argument("event_id", nargs="?")
    x.add_argument("--dry-run", action="store_true", help="등록하지 않고 미리보기만")
    x.set_defaults(fn=cmd_inbox)
    sub.add_parser("process", help="미연결 자료 자동 매칭 + 엑셀 갱신").set_defaults(fn=cmd_process)

    cu = sub.add_parser("customer", help="고객 조회/수정").add_subparsers(dest="sub", required=True)
    x = cu.add_parser("search")
    x.add_argument("query", nargs="+")
    x.set_defaults(fn=cmd_customer_search)
    x = cu.add_parser("show")
    x.add_argument("customer_id")
    x.add_argument("--brief", action="store_true")
    x.set_defaults(fn=cmd_customer_show)
    x = cu.add_parser("edit", help="예: title=수석연구원 owner=김영업")
    x.add_argument("customer_id")
    x.add_argument("values", nargs="+")
    x.set_defaults(fn=cmd_customer_edit)

    x = sub.add_parser("activity", help="고객 활동 기록 (전화, 메모 등)")
    x.add_argument("customer_id")
    x.add_argument("--type", default="담당자 메모")
    x.add_argument("--text", required=True)
    x.add_argument("--at")
    x.add_argument("--event")
    x.set_defaults(fn=cmd_activity)

    x = sub.add_parser("detach", help="잘못 통합된 자료를 새 고객으로 분리")
    x.add_argument("customer_id")
    x.add_argument("link_id", type=int)
    x.add_argument("--reason")
    x.set_defaults(fn=cmd_detach)
    x = sub.add_parser("merge", help="두 고객 통합 (source → target)")
    x.add_argument("source")
    x.add_argument("target")
    x.add_argument("--reason")
    x.set_defaults(fn=cmd_merge)
    x = sub.add_parser("undo", help="통합/분리 되돌리기")
    x.add_argument("history_id", type=int)
    x.set_defaults(fn=cmd_undo)

    co = sub.add_parser("company", help="기업 조회").add_subparsers(dest="sub", required=True)
    x = co.add_parser("list")
    x.add_argument("query", nargs="*")
    x.set_defaults(fn=cmd_company_list)
    x = co.add_parser("show")
    x.add_argument("company_id")
    x.set_defaults(fn=cmd_company_show)
    x = co.add_parser("alias", help="회사 표기 추가 (예: 리트젠 ↔ LICHTZEN)")
    x.add_argument("company_id")
    x.add_argument("alias")
    x.set_defaults(fn=cmd_company_alias)

    rv = sub.add_parser("review", help="확인 필요 항목").add_subparsers(dest="sub", required=True)
    x = rv.add_parser("list")
    x.add_argument("--all", action="store_true")
    x.set_defaults(fn=cmd_review_list)
    x = rv.add_parser("same")
    x.add_argument("review_id")
    x.set_defaults(fn=lambda s, a: cmd_review_decide(s, a, True))
    x = rv.add_parser("different")
    x.add_argument("review_id")
    x.set_defaults(fn=lambda s, a: cmd_review_decide(s, a, False))
    x = rv.add_parser("assign")
    x.add_argument("review_id")
    x.add_argument("customer_id")
    x.set_defaults(fn=cmd_review_assign)

    sub.add_parser("export", help="모든 엑셀 다시 만들기").set_defaults(fn=cmd_export)
    x = sub.add_parser("backup")
    x.add_argument("--full", action="store_true", help="업무 폴더 파일까지 포함")
    x.add_argument("--list", action="store_true")
    x.set_defaults(fn=cmd_backup)
    x = sub.add_parser("restore")
    x.add_argument("name")
    x.add_argument("--yes", action="store_true")
    x.set_defaults(fn=cmd_restore)
    x = sub.add_parser("purge", help="[관리자] 고객 개인정보 파기")
    x.add_argument("customer_id")
    x.add_argument("--reason", required=True)
    x.add_argument("--confirm", required=True)
    x.set_defaults(fn=cmd_purge)
    x = sub.add_parser("retention", help="보존기간 경과 고객 목록")
    x.add_argument("--years", type=int)
    x.set_defaults(fn=cmd_retention)
    x = sub.add_parser("log", help="처리 이력")
    x.add_argument("-n", type=int, default=30)
    x.set_defaults(fn=cmd_log)
    x = sub.add_parser("staff", help="담당자 목록/추가")
    x.add_argument("--add", help="추가할 이름")
    x.add_argument("--email")
    x.add_argument("--phone")
    x.add_argument("--role", default="영업", choices=["관리자", "영업", "조회"])
    x.add_argument("--rename", nargs=2, metavar=("ID", "NAME"))
    x.set_defaults(fn=cmd_staff)
    x = sub.add_parser("settings", help="설정 보기/변경 (예: --set ai.default_model=claude-sonnet-5-5)")
    x.add_argument("--set", nargs="*")
    x.set_defaults(fn=cmd_settings)
    sub.add_parser("demo", help="(--demo 와 함께) 가상 데이터 생성").set_defaults(fn=cmd_demo)
    return p


def main(argv: list[str] | None = None) -> int:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(errors="replace")
        except AttributeError:
            pass
    args = build_parser().parse_args(argv)
    import os
    if args.demo:
        os.environ["LICHTZEN_BASE"] = str(paths.PROGRAM_DIR / "demo_workspace")
        db.reset_engine()
    paths.ensure_folders()
    fresh = not db.db_path().exists()
    db.init_db()
    if not fresh and args.cmd not in ("restore", "backup"):
        try:
            backup.auto_backup_if_needed()
        except Exception as e:  # 백업 실패가 작업을 막지 않도록
            print("⚠ 자동 백업 실패:", e)
    s = db.new_session()
    try:
        services.ensure_default_staff(s)
        s.commit()
        args.fn(s, args)
        s.commit()
        return 0
    except (CliError, ingest.IngestError, matching.MatchError, privacy.PurgeError, ValueError,
            FileNotFoundError) as e:
        s.rollback()
        print(f"✖ {e}")
        return 1
    finally:
        s.close()
