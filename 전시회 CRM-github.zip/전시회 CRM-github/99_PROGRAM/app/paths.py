"""폴더 경로 관리.

업무 데이터 폴더(00~11)는 99_PROGRAM 의 상위 폴더에 만들어집니다.
테스트/데모 때는 환경변수 LICHTZEN_BASE 로 다른 폴더를 쓸 수 있습니다.
"""
from __future__ import annotations

import os
import re
from pathlib import Path

PROGRAM_DIR = Path(__file__).resolve().parent.parent  # 99_PROGRAM

TOP_FOLDERS = [
    "00_START_HERE",
    "00_START_HERE/INBOX",
    "01_RAW_DATA/00_ALL_EVENTS",
    "01_RAW_DATA/00_NO_EVENT",
    "02_CUSTOMER_MASTER",
    "03_CONSULTATION_HISTORY",
    "04_OFFICIAL_DOCUMENTS/01_222nm",
    "04_OFFICIAL_DOCUMENTS/02_254nm",
    "04_OFFICIAL_DOCUMENTS/03_UV_LED",
    "04_OFFICIAL_DOCUMENTS/04_UV_LAMP",
    "04_OFFICIAL_DOCUMENTS/05_EXCIMER",
    "04_OFFICIAL_DOCUMENTS/06_TECH_DOCS",
    "04_OFFICIAL_DOCUMENTS/07_TEST_REPORTS",
    "04_OFFICIAL_DOCUMENTS/99_INTERNAL_ONLY",
    "05_EMAIL_DRAFTS/01_BY_EVENT",
    "05_EMAIL_DRAFTS/02_BY_CUSTOMER",
    "05_EMAIL_DRAFTS/03_GENERAL_VISITORS",
    "05_EMAIL_DRAFTS/04_CAMPAIGNS",
    "06_SMS_DRAFTS/02_BY_CUSTOMER",
    "07_FOLLOW_UP",
    "08_REPORTS/행사별",
    "08_REPORTS/월별",
    "08_REPORTS/연도별",
    "09_BACKUP",
    "10_REVIEW_REQUIRED",
    "11_DATABASE",
]

# 행사 폴더 안의 하위 폴더 (RAW 종류별)
EVENT_SUBFOLDERS = {
    "qr": "01_QR",
    "card": "02_BUSINESS_CARDS",
    "note": "03_CONSULTATION_NOTES",
    "recording": "04_RECORDINGS",
    "other": "05_OTHER",
}

# 웹 화면에서 열람을 허용하지 않는 폴더
PROTECTED_FOLDERS = ("11_DATABASE", "99_PROGRAM", "09_BACKUP")


def base_dir() -> Path:
    return Path(os.environ.get("LICHTZEN_BASE") or PROGRAM_DIR.parent).resolve()


def p(*parts: str) -> Path:
    return base_dir().joinpath(*parts)


def rel(path: Path) -> str:
    """업무 폴더 기준 상대 경로 (엑셀/DB 기록용)."""
    try:
        return Path(path).resolve().relative_to(base_dir()).as_posix()
    except ValueError:
        return str(path)


def absolute(relpath: str | None) -> Path | None:
    if not relpath:
        return None
    return (base_dir() / relpath).resolve()


def ensure_folders() -> None:
    for f in TOP_FOLDERS:
        p(*f.split("/")).mkdir(parents=True, exist_ok=True)


def safe_filename(name: str, max_len: int = 80) -> str:
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", str(name or "")).strip(" .")
    if not name:
        name = "file"
    if len(name) > max_len:
        stem, dot, ext = name.rpartition(".")
        if dot and len(ext) <= 6:
            name = stem[: max_len - len(ext) - 1] + "." + ext
        else:
            name = name[:max_len]
    return name


def event_folder(folder_name: str | None) -> Path:
    if not folder_name:
        return p("01_RAW_DATA", "00_NO_EVENT")
    return p("01_RAW_DATA", folder_name)


def ensure_event_folders(folder_name: str | None) -> Path:
    root = event_folder(folder_name)
    for sub in EVENT_SUBFOLDERS.values():
        (root / sub).mkdir(parents=True, exist_ok=True)
    return root
