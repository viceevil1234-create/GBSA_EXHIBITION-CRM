"""RAW 데이터 수집 (M2).

모든 업로드 파일은 01_RAW_DATA/<행사폴더>/<종류>/ 에 원본 그대로 저장되고,
파일 해시(SHA-256)로 같은 파일의 중복 업로드를 막습니다.
"""
from __future__ import annotations

import csv
import hashlib
import io
import json
import re
from datetime import datetime
from pathlib import Path

import yaml
from openpyxl import load_workbook
from sqlalchemy import select
from sqlalchemy.orm import Session

from . import db, paths
from .models import (Event, RawCard, RawFile, RawNote, RawOther, RawQrRow, RawRecording, now)
from .normalize import clean, parse_dt

AUDIO_EXT = {".mp3", ".m4a", ".wav", ".aac", ".ogg", ".flac", ".wma", ".amr", ".3gp", ".webm", ".mp4"}
IMAGE_EXT = {".jpg", ".jpeg", ".png", ".heic", ".webp", ".bmp", ".gif", ".tif", ".tiff", ".pdf"}


class IngestError(Exception):
    pass


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def get_event(s: Session, event_id: str | None) -> Event | None:
    if not event_id:
        return None
    ev = s.get(Event, event_id)
    if ev is None:
        raise IngestError(f"행사 {event_id} 를 찾을 수 없습니다")
    return ev


def find_duplicate_file(s: Session, data: bytes) -> RawFile | None:
    return s.scalar(select(RawFile).where(RawFile.original_sha256 == sha256(data)))


def store_file(s: Session, event: Event | None, kind: str, filename: str, data: bytes,
               actor: str | None, meta: dict | None = None) -> RawFile:
    dup = find_duplicate_file(s, data)
    if dup:
        raise IngestError(f"이미 업로드된 파일입니다 ({dup.id} · {dup.original_name} · "
                          f"{dup.event_id or '행사 없음'} · {dup.uploaded_at:%Y-%m-%d %H:%M})")
    fid = db.next_id(s, "RAWF")
    folder = paths.ensure_event_folders(event.folder_name if event else None) / paths.EVENT_SUBFOLDERS[kind]
    target = folder / f"{fid}_{paths.safe_filename(filename)}"
    target.write_bytes(data)
    digest = sha256(data)
    rf = RawFile(id=fid, event_id=event.id if event else None, kind=kind, original_name=filename,
                 stored_path=paths.rel(target), original_sha256=digest, sha256=digest, size=len(data),
                 meta=meta or {}, uploaded_by=actor, uploaded_at=now())
    s.add(rf)
    s.flush()
    return rf


# ───────────────────────── QR 엑셀 ─────────────────────────
def _norm_header(h) -> str:
    return re.sub(r"[\s\-_()\[\]./:]", "", clean(h).lower())


def load_synonyms() -> dict[str, str]:
    data = yaml.safe_load((paths.PROGRAM_DIR / "config" / "column_synonyms.yaml").read_text(encoding="utf-8"))
    lookup: dict[str, str] = {}
    for field, words in data.items():
        for w in words or []:
            lookup.setdefault(_norm_header(w), field)
    return lookup


def _read_table(filename: str, data: bytes) -> tuple[str | None, list[tuple[int, list]]]:
    """(시트명, [(엑셀 행번호, [셀값...]), ...])"""
    ext = Path(filename).suffix.lower()
    if ext in (".xlsx", ".xlsm"):
        wb = load_workbook(io.BytesIO(data), read_only=True, data_only=True)
        ws = wb.worksheets[0]
        rows = [(i, list(r)) for i, r in enumerate(ws.iter_rows(values_only=True), start=1)]
        title = ws.title
        wb.close()
        return title, rows
    if ext == ".csv":
        for enc in ("utf-8-sig", "cp949", "euc-kr"):
            try:
                text = data.decode(enc)
                break
            except UnicodeDecodeError:
                continue
        else:
            raise IngestError("CSV 파일의 글자 인코딩을 읽을 수 없습니다")
        rows = [(i, r) for i, r in enumerate(csv.reader(io.StringIO(text)), start=1)]
        return None, rows
    if ext == ".xls":
        raise IngestError("오래된 .xls 형식입니다. 엑셀에서 '다른 이름으로 저장 → .xlsx' 후 다시 올려주세요")
    raise IngestError("QR 파일은 .xlsx 또는 .csv 만 가능합니다")


def _detect_header(rows, lookup) -> tuple[int, dict[int, str]]:
    best = (-1, 0, {})
    for pos, (_rowno, cells) in enumerate(rows[:15]):
        mapping = {}
        for ci, c in enumerate(cells):
            f = lookup.get(_norm_header(c))
            if f and f not in mapping.values():
                mapping[ci] = f
        if len(mapping) > best[1]:
            best = (pos, len(mapping), mapping)
    if best[1] < 2 or not ({"name", "email", "mobile", "first_name", "last_name"} & set(best[2].values())):
        raise IngestError("QR 엑셀의 열 이름(이름/회사/이메일/연락처 등)을 인식하지 못했습니다. "
                          "99_PROGRAM/config/column_synonyms.yaml 에 열 이름을 추가해 주세요")
    return best[0], best[2]


def _cell_str(v) -> str:
    if isinstance(v, datetime):
        return v.strftime("%Y-%m-%d %H:%M:%S")
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return clean(v)


def ingest_qr(s: Session, event_id: str, filename: str, data: bytes, actor: str | None) -> dict:
    event = get_event(s, event_id)
    if event is None:
        raise IngestError("QR 파일은 행사를 선택해야 합니다")
    lookup = load_synonyms()
    sheet, rows = _read_table(filename, data)
    hdr_pos, mapping = _detect_header(rows, lookup)
    header_cells = rows[hdr_pos][1]
    headers = [_cell_str(h) or f"열{i + 1}" for i, h in enumerate(header_cells)]
    unmapped = [h for i, h in enumerate(headers) if i not in mapping and h]

    rf = store_file(s, event, "qr", filename, data, actor,
                    meta={"sheet": sheet, "header_row": rows[hdr_pos][0],
                          "mapping": {headers[i]: f for i, f in mapping.items()}, "unmapped": unmapped})
    added = skipped = 0
    for rowno, cells in rows[hdr_pos + 1:]:
        values = {headers[i]: _cell_str(cells[i]) if i < len(cells) else "" for i in range(len(headers))}
        if not any(values.values()):
            continue
        row_hash = sha256(json.dumps(values, ensure_ascii=False, sort_keys=True).encode("utf-8"))
        exists = s.scalar(select(RawQrRow.id).where(RawQrRow.event_id == event.id, RawQrRow.row_hash == row_hash))
        if exists:
            skipped += 1
            continue
        f = {fld: (cells[i] if i < len(cells) else None) for i, fld in mapping.items()}
        name = clean(f.get("name"))
        name_en = clean(f.get("name_en"))
        if not name and (f.get("first_name") or f.get("last_name")):
            name = clean(f"{clean(f.get('first_name'))} {clean(f.get('last_name'))}")
        elif not name_en and (f.get("first_name") or f.get("last_name")):
            name_en = clean(f"{clean(f.get('first_name'))} {clean(f.get('last_name'))}")
        s.add(RawQrRow(
            id=db.next_id(s, "RAW-QR"), event_id=event.id, file_id=rf.id, sheet=sheet, row_index=rowno,
            row_hash=row_hash, raw_json=values, name=name, name_en=name_en, company=clean(f.get("company")),
            department=clean(f.get("department")), title=clean(f.get("title")), email=clean(f.get("email")),
            mobile=_cell_str(f.get("mobile")), phone=_cell_str(f.get("phone")), country=clean(f.get("country")),
            scanned_at=parse_dt(f.get("scanned_at")), interest=clean(f.get("interest")), memo=clean(f.get("memo")),
            created_at=now()))
        added += 1
    s.flush()
    db.log(s, "QR 업로드", rf.id, f"{event.id} · 추가 {added}행 · 중복 제외 {skipped}행", actor)
    return {"file_id": rf.id, "added": added, "skipped": skipped,
            "mapping": {headers[i]: f for i, f in mapping.items()}, "unmapped": unmapped}


# ───────────────────────── 명함 ─────────────────────────
CARD_FIELDS = ["name", "name_en", "company", "company_en", "department", "title", "email", "mobile", "phone",
               "address", "website", "country"]


def ingest_card(s: Session, event_id: str | None, filename: str | None, data: bytes | None, fields: dict,
                actor: str | None, captured_at: datetime | None = None) -> RawCard:
    event = get_event(s, event_id)
    rf = None
    if data:
        if Path(filename or "").suffix.lower() not in IMAGE_EXT:
            raise IngestError("명함은 사진(jpg, png 등) 또는 PDF 파일만 가능합니다")
        rf = store_file(s, event, "card", filename or "card.jpg", data, actor)
    vals = {k: clean(fields.get(k)) for k in CARD_FIELDS}
    has_info = any(vals[k] for k in ("name", "name_en", "email", "mobile"))
    if not rf and not has_info:
        raise IngestError("명함 사진이나 명함 정보(이름/이메일/휴대폰) 중 하나는 있어야 합니다")
    card = RawCard(id=db.next_id(s, "RAW-CARD"), event_id=event.id if event else None, file_id=rf.id if rf else None,
                   entry_method="manual", ocr_status="none" if has_info else "pending",
                   captured_at=captured_at or now(), entered_by=actor, created_at=now(), **vals)
    s.add(card)
    s.flush()
    db.log(s, "명함 등록", card.id, "OCR 대기" if card.ocr_status == "pending" else "정보 입력", actor)
    return card


# ───────────────────────── 상담 원문 ─────────────────────────
def ingest_note(s: Session, event_id: str | None, content: str, actor: str | None, *, customer_id: str | None = None,
                name: str = "", company: str = "", email: str = "", mobile: str = "", channel: str = "현장 상담",
                consulted_at: datetime | None = None, staff_id: str | None = None) -> RawNote:
    event = get_event(s, event_id)
    content = (content or "").strip()
    if not content:
        raise IngestError("상담 내용을 입력해 주세요")
    if not customer_id and not any(clean(x) for x in (name, email, mobile)):
        raise IngestError("고객을 선택하거나 이름/이메일/휴대폰 중 하나를 입력해 주세요")
    consulted_at = consulted_at or now()
    key = json.dumps([event_id, customer_id, clean(name), clean(email), clean(mobile), channel,
                      consulted_at.isoformat(), content], ensure_ascii=False)
    h = sha256(key.encode("utf-8"))
    if s.scalar(select(RawNote.id).where(RawNote.content_hash == h)):
        raise IngestError("같은 상담 내용이 이미 저장되어 있습니다")
    nid = db.next_id(s, "RAW-NOTE")
    folder = paths.ensure_event_folders(event.folder_name if event else None) / paths.EVENT_SUBFOLDERS["note"]
    f = folder / f"{nid}_{consulted_at:%Y%m%d_%H%M}.txt"
    f.write_text(f"상담 ID(원본): {nid}\n행사: {event.name if event else '행사 외'}\n일시: {consulted_at:%Y-%m-%d %H:%M}\n"
                 f"구분: {channel}\n담당자: {staff_id or ''}\n고객: {customer_id or ''} {clean(name)} {clean(company)}\n"
                 f"{'-' * 40}\n{content}\n", encoding="utf-8")
    note = RawNote(id=nid, event_id=event.id if event else None, content_hash=h, customer_id_hint=customer_id or None,
                   name=clean(name), company=clean(company), email=clean(email), mobile=clean(mobile),
                   channel=channel, consulted_at=consulted_at, staff_id=staff_id, content=content,
                   file_path=paths.rel(f), created_at=now())
    s.add(note)
    s.flush()
    db.log(s, "상담 원본 저장", nid, channel, actor)
    return note


# ───────────────────────── 녹음 ─────────────────────────
def ingest_recording(s: Session, event_id: str | None, filename: str, data: bytes, actor: str | None, *,
                     consent: bool, consent_method: str = "", customer_id: str | None = None, name: str = "",
                     company: str = "", recorded_at: datetime | None = None, staff_id: str | None = None) -> RawRecording:
    if not consent:
        raise IngestError("녹음 동의가 확인되지 않은 파일은 등록할 수 없습니다 (개인정보 보호)")
    if Path(filename).suffix.lower() not in AUDIO_EXT:
        raise IngestError("녹음 파일 형식(mp3, m4a, wav 등)이 아닙니다")
    event = get_event(s, event_id)
    rf = store_file(s, event, "recording", filename, data, actor)
    rec = RawRecording(id=db.next_id(s, "RAW-REC"), event_id=event.id if event else None, file_id=rf.id,
                       customer_id_hint=customer_id or None, name=clean(name), company=clean(company),
                       recorded_at=recorded_at or now(), staff_id=staff_id, consent=True,
                       consent_method=clean(consent_method) or "구두 동의", stt_status="pending", created_at=now())
    s.add(rec)
    s.flush()
    db.log(s, "녹음 등록", rec.id, "텍스트 변환 대기", actor)
    return rec


# ───────────────────────── 기타 ─────────────────────────
def ingest_other(s: Session, event_id: str | None, filename: str, data: bytes, actor: str | None, *,
                 description: str = "", customer_id: str | None = None) -> RawOther:
    event = get_event(s, event_id)
    rf = store_file(s, event, "other", filename, data, actor)
    o = RawOther(id=db.next_id(s, "RAW-ETC"), event_id=event.id if event else None, file_id=rf.id,
                 customer_id_hint=customer_id or None, description=clean(description), created_at=now())
    s.add(o)
    s.flush()
    db.log(s, "기타 자료 등록", o.id, None, actor)
    return o
