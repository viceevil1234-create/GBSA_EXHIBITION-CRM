"""백업 및 복구.

- DB 백업: 11_DATABASE 의 DB를 안전하게 복사해 zip으로 저장 (빠름, 매일 자동)
- 전체 백업: DB + 01~08, 10 업무 폴더 전체 (용량 큼, 수동)
- 복구: 복구 직전 상태를 먼저 백업한 뒤 DB를 교체
"""
from __future__ import annotations

import os
import sqlite3
import tempfile
import zipfile
from datetime import datetime
from pathlib import Path

from . import db, paths

FULL_FOLDERS = ["00_START_HERE", "01_RAW_DATA", "02_CUSTOMER_MASTER", "03_CONSULTATION_HISTORY",
                "04_OFFICIAL_DOCUMENTS", "05_EMAIL_DRAFTS", "06_SMS_DRAFTS", "07_FOLLOW_UP",
                "08_REPORTS", "10_REVIEW_REQUIRED"]


def backup_dir() -> Path:
    d = paths.p("09_BACKUP")
    d.mkdir(parents=True, exist_ok=True)
    return d


def _copy_db(dest: Path) -> None:
    src = db.db_path()
    if not src.exists():
        raise FileNotFoundError("DB 파일이 없습니다")
    s = sqlite3.connect(str(src))
    d = sqlite3.connect(str(dest))
    try:
        s.backup(d)
    finally:
        d.close()
        s.close()


def create_backup(kind: str = "manual", full: bool = False) -> Path:
    """kind: auto / manual / pre_restore"""
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    name = f"LICHTZEN_backup_{stamp}_{kind}{'_full' if full else ''}.zip"
    out = backup_dir() / name
    with tempfile.TemporaryDirectory() as tmp:
        tmp_db = Path(tmp) / db.DB_FILENAME
        _copy_db(tmp_db)
        with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
            z.write(tmp_db, f"11_DATABASE/{db.DB_FILENAME}")
            if full:
                base = paths.base_dir()
                for folder in FULL_FOLDERS:
                    root = base / folder
                    if not root.exists():
                        continue
                    for f in root.rglob("*"):
                        if f.is_file():
                            z.write(f, f.relative_to(base).as_posix())
    if kind == "auto":
        rotate_auto_backups()
    return out


def list_backups() -> list[dict]:
    items = []
    for f in sorted(backup_dir().glob("LICHTZEN_backup_*.zip"), reverse=True):
        st = f.stat()
        items.append({"name": f.name, "size_kb": round(st.st_size / 1024, 1),
                      "at": datetime.fromtimestamp(st.st_mtime).replace(microsecond=0)})
    return items


def _parse_stamp(name: str) -> datetime | None:
    try:
        parts = name.split("_")
        return datetime.strptime(parts[2] + parts[3], "%Y%m%d%H%M%S")
    except (IndexError, ValueError):
        return None


def rotate_auto_backups() -> list[str]:
    from .settings import DEFAULTS
    cfg = DEFAULTS["backup"]
    autos = []
    for f in backup_dir().glob("LICHTZEN_backup_*_auto.zip"):
        t = _parse_stamp(f.name)
        if t:
            autos.append((t, f))
    autos.sort(reverse=True)
    keep: set[Path] = set()
    for key_fn, limit in ((lambda t: t.date(), cfg["keep_daily"]),
                          (lambda t: t.isocalendar()[:2], cfg["keep_weekly"]),
                          (lambda t: (t.year, t.month), cfg["keep_monthly"])):
        seen = []
        for t, f in autos:
            k = key_fn(t)
            if k not in seen:
                seen.append(k)
                if len(seen) > limit:
                    break
                keep.add(f)
    removed = []
    for _t, f in autos:
        if f not in keep:
            f.unlink(missing_ok=True)
            removed.append(f.name)
    return removed


def auto_backup_if_needed() -> Path | None:
    if not db.db_path().exists():
        return None
    today = datetime.now().strftime("%Y%m%d")
    if any(backup_dir().glob(f"LICHTZEN_backup_{today}_*_auto.zip")):
        return None
    return create_backup("auto")


def restore_backup(name: str) -> Path:
    src = backup_dir() / Path(name).name
    if not src.exists():
        raise FileNotFoundError("백업 파일을 찾을 수 없습니다")
    with zipfile.ZipFile(src) as z:
        member = f"11_DATABASE/{db.DB_FILENAME}"
        if member not in z.namelist():
            raise ValueError("이 백업에는 DB가 없습니다")
        safety = create_backup("pre_restore")
        db.reset_engine()
        target = db.db_path()
        for ext in ("-wal", "-shm"):
            Path(str(target) + ext).unlink(missing_ok=True)
        with z.open(member) as fin, open(target, "wb") as fout:
            fout.write(fin.read())
    db.init_db()
    return safety
