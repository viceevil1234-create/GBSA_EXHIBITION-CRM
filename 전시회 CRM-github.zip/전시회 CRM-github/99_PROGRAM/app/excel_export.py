"""엑셀 자동 생성. 엑셀은 DB에서 매번 새로 만들어지므로 여러 번 실행해도 행이 중복되지 않습니다.

엑셀 파일이 열려 있어 저장할 수 없으면 '_새버전_시각' 이름으로 저장하고 경고를 돌려줍니다.
"""
from __future__ import annotations

import os
import tempfile
from datetime import datetime
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from sqlalchemy import select
from sqlalchemy.orm import Session

from . import paths
from .models import (RAW_LABEL, Company, CompanyAlias, Consultation, Customer, Event, MatchDecision, ProcessingLog,
                     RawCard, RawFile, RawLink, RawNote, RawOther, RawQrRow, RawRecording, ReviewItem, Staff, Visit)
from .stats import CAT_CONSULT, CAT_GENERAL, classify_event, event_summary, visit_index

HEADER_FILL = PatternFill("solid", fgColor="1F4E78")
HEADER_FONT = Font(color="FFFFFF", bold=True)
LINK_FONT = Font(color="0563C1", underline="single")
NOT_YET = "(M4 이후 단계에서 채워집니다)"


def _fmt(v):
    if isinstance(v, datetime):
        return v.strftime("%Y-%m-%d %H:%M")
    if isinstance(v, bool):
        return "예" if v else "아니오"
    return v


def write_workbook(path: Path, sheets: list[tuple[str, list[str], list[list]]], link_cols: dict | None = None) -> tuple[Path, str | None]:
    """sheets: [(시트명, 헤더, 행들)], link_cols: {시트명: [파일경로 열 이름]} → 클릭하면 파일이 열리는 링크"""
    link_cols = link_cols or {}
    wb = Workbook()
    wb.remove(wb.active)
    for name, headers, rows in sheets:
        ws = wb.create_sheet(name[:31])
        ws.append(headers)
        for c in ws[1]:
            c.fill, c.font = HEADER_FILL, HEADER_FONT
            c.alignment = Alignment(vertical="center", wrap_text=True)
        for r in rows:
            ws.append([_fmt(v) for v in r])
        if not rows:
            ws.append(["(데이터 없음)"])
        for col in link_cols.get(name, []):
            if col not in headers:
                continue
            ci = headers.index(col) + 1
            for row in ws.iter_rows(min_row=2, min_col=ci, max_col=ci):
                cell = row[0]
                if cell.value and isinstance(cell.value, str) and not cell.value.startswith("("):
                    target = paths.absolute(cell.value)
                    cell.hyperlink = str(target) if target else None
                    cell.font = LINK_FONT
        for i, h in enumerate(headers, start=1):
            width = max([len(str(h))] + [len(str(_fmt(r[i - 1]) or "")) for r in rows[:300] if i - 1 < len(r)])
            ws.column_dimensions[get_column_letter(i)].width = min(max(8, width * 1.3 + 2), 60)
        ws.freeze_panes = "A2"
        ws.auto_filter.ref = ws.dimensions
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(suffix=".xlsx", dir=path.parent)
    os.close(fd)
    wb.save(tmp)
    try:
        os.replace(tmp, path)
        return path, None
    except PermissionError:
        alt = path.with_name(f"{path.stem}_새버전_{datetime.now():%Y%m%d_%H%M%S}.xlsx")
        os.replace(tmp, alt)
        return alt, f"'{path.name}' 파일이 열려 있어 '{alt.name}' 으로 저장했습니다. 엑셀을 닫고 다시 생성하면 원래 이름으로 저장됩니다."


# ───────────────────────── 공통 조회 ─────────────────────────
def _customer_of_raw(s: Session) -> dict[tuple[str, str], str]:
    return {(l.raw_type, l.raw_id): l.customer_id for l in s.scalars(select(RawLink))}


def _file_path(s: Session, file_id: str | None) -> str:
    if not file_id:
        return ""
    rf = s.get(RawFile, file_id)
    if rf is None:
        return ""
    return "(파기됨)" if rf.purged_at and rf.kind != "qr" else (rf.stored_path or "")


def _events(s: Session) -> dict[str, Event]:
    return {e.id: e for e in s.scalars(select(Event))}


def _staff(s: Session) -> dict[str, str]:
    return {x.id: x.name for x in s.scalars(select(Staff))}


# ───────────────────────── RAW 엑셀 ─────────────────────────
def raw_sheets(s: Session, event_id: str | None) -> list:
    evs = _events(s)
    cmap = _customer_of_raw(s)
    stf = _staff(s)

    def evname(eid):
        return f"{eid} {evs[eid].name}" if eid in evs else "행사 외"

    def flt(model):
        q = select(model)
        if event_id:
            q = q.where(model.event_id == event_id)
        return list(s.scalars(q.order_by(model.id)))

    qr_rows = []
    extra_cols: list[str] = []
    qrs = flt(RawQrRow)
    for r in qrs:
        for k in (r.raw_json or {}):
            if k not in extra_cols:
                extra_cols.append(k)
    for r in qrs:
        rf = s.get(RawFile, r.file_id)
        qr_rows.append([r.id, evname(r.event_id), cmap.get(("qr", r.id), ""), rf.original_name if rf else "",
                        r.row_index, r.created_at, "예" if r.purged_at else ""] +
                       [(r.raw_json or {}).get(k, "") for k in extra_cols] + [rf.stored_path if rf else ""])
    cards = [[r.id, evname(r.event_id), cmap.get(("card", r.id), ""), r.name, r.name_en, r.company, r.company_en,
              r.department, r.title, r.email, r.mobile, r.phone, r.address, r.website, r.country,
              {"none": "직접 입력", "pending": "OCR 대기", "done": "OCR 완료"}.get(r.ocr_status, r.ocr_status),
              r.captured_at, r.entered_by, _file_path(s, r.file_id)] for r in flt(RawCard)]
    notes = [[r.id, evname(r.event_id), cmap.get(("note", r.id), r.customer_id_hint or ""), r.channel,
              r.consulted_at, stf.get(r.staff_id, r.staff_id), r.name, r.company, r.email, r.mobile, r.content,
              r.file_path or ""] for r in flt(RawNote)]
    recs = [[r.id, evname(r.event_id), cmap.get(("recording", r.id), r.customer_id_hint or ""), r.recorded_at,
             stf.get(r.staff_id, r.staff_id), r.name, r.company, "예" if r.consent else "아니오", r.consent_method,
             {"pending": "변환 대기", "done": "변환 완료", "failed": "변환 실패"}.get(r.stt_status, r.stt_status),
             _file_path(s, r.file_id), r.transcript_path or ""] for r in flt(RawRecording)]
    others = [[r.id, evname(r.event_id), cmap.get(("other", r.id), r.customer_id_hint or ""), r.description,
               r.created_at, _file_path(s, r.file_id)] for r in flt(RawOther)]
    return [
        ("01_QR방문객원본", ["RAW ID", "행사", "연결 고객 ID", "원본 파일명", "원본 행번호", "업로드 일시", "파기"]
         + extra_cols + ["원본 파일 경로"], qr_rows),
        ("02_명함원본", ["RAW ID", "행사", "연결 고객 ID", "이름", "영문이름", "회사", "영문회사", "부서", "직급", "이메일",
                     "휴대폰", "전화", "주소", "웹사이트", "국가", "입력 방식", "등록 일시", "등록자", "명함 사진 경로"], cards),
        ("03_상담원본", ["RAW ID", "행사", "연결 고객 ID", "구분", "상담 일시", "담당자", "이름", "회사", "이메일", "휴대폰",
                     "상담 원문", "원문 파일 경로"], notes),
        ("04_녹음파일정보", ["RAW ID", "행사", "연결 고객 ID", "녹음 일시", "담당자", "이름", "회사", "녹음 동의", "동의 방식",
                       "텍스트 변환", "녹음 파일 경로", "변환 텍스트 경로"], recs),
        ("05_기타업로드원본", ["RAW ID", "행사", "연결 고객 ID", "설명", "등록 일시", "파일 경로"], others),
    ]


RAW_LINKS = {"01_QR방문객원본": ["원본 파일 경로"], "02_명함원본": ["명함 사진 경로"], "03_상담원본": ["원문 파일 경로"],
             "04_녹음파일정보": ["녹음 파일 경로", "변환 텍스트 경로"], "05_기타업로드원본": ["파일 경로"]}


def export_event_raw(s: Session, event: Event):
    out = paths.event_folder(event.folder_name) / f"RAW_{event.id}.xlsx"
    return write_workbook(out, raw_sheets(s, event.id), RAW_LINKS)


def export_all_raw(s: Session):
    return write_workbook(paths.p("01_RAW_DATA", "00_ALL_EVENTS", "RAW_전체행사.xlsx"), raw_sheets(s, None), RAW_LINKS)


# ───────────────────────── 통합 관리 엑셀 ─────────────────────────
def _event_categories(s: Session) -> dict[tuple[str, str], str]:
    cats = {}
    for e in s.scalars(select(Event)):
        for r in classify_event(s, e.id):
            cats[(r["customer"].id, e.id)] = r["category"]
    return cats


def master_sheets(s: Session, event_id: str | None = None) -> list:
    evs = _events(s)
    stf = _staff(s)
    vidx = visit_index(s)
    cats = _event_categories(s)
    comps = {c.id: c for c in s.scalars(select(Company))}
    customers = [c for c in s.scalars(select(Customer).where(Customer.status == "active").order_by(Customer.id))]
    if event_id:
        customers = [c for c in customers if event_id in vidx.get(c.id, [])]
    cust_ids = {c.id for c in customers}

    def evnames(cid):
        return ", ".join(f"{e} {evs[e].name}" for e in vidx.get(cid, []) if e in evs)

    cust_rows = [[c.id, c.name_ko, c.name_en, c.company_id, c.company_display, c.department, c.title, c.email, c.mobile,
                  c.phone, c.country, "국내" if c.is_domestic else ("해외" if c.is_domestic is False else "미확인"),
                  c.language or "", len(vidx.get(c.id, [])), "예" if len(vidx.get(c.id, [])) >= 2 else "",
                  evnames(c.id), c.first_seen_at, stf.get(c.owner_staff_id, ""), c.ai_summary or ""] for c in customers]
    comp_count: dict[str, int] = {}
    for c in customers:
        if c.company_id:
            comp_count[c.company_id] = comp_count.get(c.company_id, 0) + 1
    comp_rows = []
    for comp in sorted(comps.values(), key=lambda x: x.id):
        if comp.status != "active" or (event_id and comp.id not in comp_count):
            continue
        aliases = ", ".join(a.alias for a in s.scalars(select(CompanyAlias).where(CompanyAlias.company_id == comp.id)))
        comp_rows.append([comp.id, comp.name, comp.name_en, aliases, comp.domain, comp.country,
                          comp_count.get(comp.id, 0)])
    visits = [v for v in s.scalars(select(Visit).where(Visit.active.is_(True)).order_by(Visit.id))
              if v.customer_id in cust_ids and (not event_id or v.event_id == event_id)]
    cmap = {c.id: c for c in customers}
    visit_rows = [[v.id, v.event_id, evs[v.event_id].name if v.event_id in evs else "", v.customer_id,
                   cmap[v.customer_id].name_ko or cmap[v.customer_id].name_en, cmap[v.customer_id].company_display,
                   v.first_seen_at, cats.get((v.customer_id, v.event_id), "")] for v in visits]
    cons = [c for c in s.scalars(select(Consultation).order_by(Consultation.id))
            if c.customer_id in cust_ids and (not event_id or c.event_id == event_id)]
    con_rows = [[c.id, c.customer_id, cmap[c.customer_id].name_ko or cmap[c.customer_id].name_en,
                 cmap[c.customer_id].company_display, c.event_id or "행사 외", c.channel, c.consulted_at,
                 stf.get(c.staff_id, c.staff_id), c.content, c.ai_status] for c in cons]
    hist_rows = []
    for l in s.scalars(select(RawLink).order_by(RawLink.seen_at)):
        if l.customer_id in cust_ids and (not event_id or l.event_id == event_id):
            c = cmap[l.customer_id]
            hist_rows.append([l.seen_at or l.linked_at, l.customer_id, c.name_ko or c.name_en, c.company_display,
                              RAW_LABEL.get(l.raw_type, l.raw_type), l.event_id or "", l.raw_id])
    general = [r for r in visit_rows if r[7] == CAT_GENERAL]
    consult = [r for r in visit_rows if r[7] == CAT_CONSULT]
    reviews = [[r.id, r.kind, r.status, r.customer_id, r.candidate_customer_id, r.raw_id, r.summary, r.created_at,
                r.resolution or ""] for r in s.scalars(select(ReviewItem).order_by(ReviewItem.id))]
    logs = [[l.at, l.actor, l.action, l.target, l.detail] for l in
            s.scalars(select(ProcessingLog).order_by(ProcessingLog.id.desc()).limit(5000))]
    perf = []
    for e in sorted(evs.values(), key=lambda x: x.id):
        if event_id and e.id != event_id:
            continue
        sm = event_summary(s, e.id)
        perf.append([e.id, e.name, e.type, e.start_date, sm["visitors"], sm[CAT_CONSULT], sm[CAT_GENERAL],
                     sm["확인 필요 고객"], sm["new"], sm["existing"], sm["revisit"], "미집계", "미집계"])
    visit_hdr = ["방문 ID", "행사 ID", "행사명", "고객 ID", "이름", "회사", "방문 시각", "분류"]
    return [
        ("01_전체고객통합", ["고객 ID", "이름(한글)", "이름(영문)", "기업 ID", "회사", "부서", "직급", "이메일", "휴대폰", "전화",
                       "국가", "국내/해외", "언어", "방문 행사 수", "재방문", "방문 행사", "최초 접촉", "담당자", "AI 요약"], cust_rows),
        ("02_전체기업통합", ["기업 ID", "회사명", "영문명", "표기(별칭)", "이메일 도메인", "국가", "소속 고객 수"], comp_rows),
        ("03_전체행사방문이력", visit_hdr, visit_rows),
        ("04_전체상담이력", ["상담 ID", "고객 ID", "이름", "회사", "행사", "구분", "상담 일시", "담당자", "상담 내용", "AI 분석"], con_rows),
        ("05_전체연락히스토리", ["일시", "고객 ID", "이름", "회사", "활동", "행사", "원본 ID"], hist_rows),
        ("06_일반방문객", visit_hdr, general),
        ("07_상담고객", visit_hdr, consult),
        ("08_후속영업관리", ["영업 건 ID", "고객 ID", "제품", "단계", "다음 연락일", "연락 사유", NOT_YET], []),
        ("09_이메일초안관리", ["초안 ID", "고객 ID", "목적", "상태", "제목", "첨부", "저장 위치", NOT_YET], []),
        ("10_문자초안관리", ["초안 ID", "고객 ID", "목적", "상태", "본문", "저장 위치", NOT_YET], []),
        ("11_공식자료관리", ["자료 ID", "파일명", "제품명", "카테고리", "파장", "자료 종류", "언어", "버전", "최종 수정일",
                       "외부 공개", "저장 경로", NOT_YET], []),
        ("12_확인필요항목", ["확인 ID", "종류", "상태", "고객 ID", "비교 대상 고객", "원본 ID", "내용", "등록 일시", "처리 결과"], reviews),
        ("13_데이터처리이력", ["일시", "작업자", "작업", "대상", "내용"], logs),
        ("14_전시회성과관리", ["행사 ID", "행사명", "유형", "시작일", "방문 고객", "상담 고객", "일반 방문객", "확인 필요", "신규",
                        "기존", "재방문", "발주", "매출 기여"], perf),
    ]


def export_master(s: Session) -> list[str]:
    warns = []
    sheets = master_sheets(s)
    by = {name: (name, h, r) for name, h, r in sheets}
    targets = [
        (paths.p("02_CUSTOMER_MASTER", "LICHTZEN_CRM_통합관리.xlsx"), sheets),
        (paths.p("02_CUSTOMER_MASTER", "전체고객통합.xlsx"), [by["01_전체고객통합"]]),
        (paths.p("02_CUSTOMER_MASTER", "전체기업통합.xlsx"), [by["02_전체기업통합"]]),
        (paths.p("03_CONSULTATION_HISTORY", "전체상담이력.xlsx"), [by["04_전체상담이력"]]),
        (paths.p("03_CONSULTATION_HISTORY", "고객활동이력.xlsx"), [by["05_전체연락히스토리"]]),
        (paths.p("10_REVIEW_REQUIRED", "확인필요항목.xlsx"), [by["12_확인필요항목"]]),
    ]
    for path, sh in targets:
        _p, w = write_workbook(path, sh)
        if w:
            warns.append(w)
    return warns


def export_event_master(s: Session, event: Event):
    return write_workbook(paths.p("08_REPORTS", "행사별", f"{event.id}_통합.xlsx"), master_sheets(s, event.id))


def refresh_all(s: Session, event_ids: list[str] | None = None) -> list[str]:
    """RAW 엑셀 + 통합 엑셀 갱신. event_ids 가 없으면 모든 행사."""
    warns = []
    evs = _events(s)
    for eid in (event_ids if event_ids is not None else list(evs)):
        if eid in evs:
            for fn in (export_event_raw, export_event_master):
                _p, w = fn(s, evs[eid])
                if w:
                    warns.append(w)
    _p, w = export_all_raw(s)
    if w:
        warns.append(w)
    warns += export_master(s)
    return warns
