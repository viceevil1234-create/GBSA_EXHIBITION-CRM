"""환경설정 (DB의 settings 테이블에 저장, 화면에서 변경).

API 키는 DB가 아니라 99_PROGRAM/.env 파일에만 저장합니다 (백업 zip에 포함되지 않음).
"""
from __future__ import annotations

import copy
from pathlib import Path

from sqlalchemy.orm import Session

from . import paths
from .models import Setting

# AI 모델 단가 (1M 토큰당 USD). 가격 변경 시 여기만 수정.
AI_MODELS = {
    "claude-haiku-5-5": {"label": "Haiku 5.5 (최저가)", "input": 0.10, "output": 0.50},
    "claude-sonnet-5-5": {"label": "Sonnet 5.5 (기본·균형)", "input": 2.00, "output": 10.00},
    "claude-opus-5-5": {"label": "Opus 5.5 (최고 품질)", "input": 4.00, "output": 20.00},
}

AI_TASKS = {
    "consultation_analysis": "상담 내용 분석",
    "card_ocr": "명함 OCR",
    "customer_summary": "고객 요약 업데이트",
    "message_draft": "이메일·문자 초안 작성",
}

DEFAULTS: dict = {
    "company_name": "리트젠 (LICHTZEN)",
    "matching": {
        "auto_merge_min": 80,   # 이 점수 이상 + 강한 근거(이메일/휴대폰) → 자동 통합
        "review_min": 30,       # 이 점수 이상 → 확인 필요
        "time_window_min": 30,  # 같은 행사에서 QR 시각과 상담 시각 근접 기준(분)
    },
    "contact_cycle_days": {"상담 고객": 7, "견적 제출": 5, "샘플·테스트": 14, "장기 검토": 60, "일반 방문객": 180},
    "long_no_contact_days": 90,
    "retention_years": 5,
    "ai": {
        "mode": "manual",              # manual: Claude Code에서 처리 / api: 자동 호출
        "api_calls_approved": False,   # 사용자가 승인하기 전에는 API 호출 금지
        "default_model": "claude-sonnet-5-5",
        "task_models": {k: "" for k in AI_TASKS},  # 빈 값 = 기본 모델 사용
        "monthly_limit_krw": 30000,
        "usd_krw": 1400,
    },
    "backup": {"auto_on_start": True, "keep_daily": 7, "keep_weekly": 4, "keep_monthly": 12},
}


def _deep_merge(base: dict, over: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def get_settings(s: Session) -> dict:
    row = s.get(Setting, "app")
    return _deep_merge(DEFAULTS, row.value if row else {})


def save_settings(s: Session, new: dict) -> dict:
    merged = _deep_merge(get_settings(s), new)
    row = s.get(Setting, "app")
    if row is None:
        s.add(Setting(key="app", value=merged))
    else:
        row.value = merged
    s.flush()
    return merged


def model_for_task(cfg: dict, task: str) -> str:
    return (cfg["ai"]["task_models"].get(task) or cfg["ai"]["default_model"])


# ───────── API 키 (.env) ─────────
def _env_path() -> Path:
    return paths.PROGRAM_DIR / ".env"


def get_api_key() -> str:
    f = _env_path()
    if not f.exists():
        return ""
    for line in f.read_text(encoding="utf-8").splitlines():
        if line.startswith("ANTHROPIC_API_KEY="):
            return line.split("=", 1)[1].strip()
    return ""


def set_api_key(key: str) -> None:
    f = _env_path()
    lines = []
    if f.exists():
        lines = [ln for ln in f.read_text(encoding="utf-8").splitlines() if not ln.startswith("ANTHROPIC_API_KEY=")]
    if key.strip():
        lines.append(f"ANTHROPIC_API_KEY={key.strip()}")
    f.write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")


def masked_api_key() -> str:
    k = get_api_key()
    if not k:
        return ""
    return k[:7] + "…" + k[-4:] if len(k) > 12 else "등록됨"
