"""고객 분류(일반 방문객/상담 고객/확인 필요)와 집계. 분류는 저장하지 않고 항상 그때그때 계산합니다."""
from __future__ import annotations

from collections import defaultdict
from datetime import datetime

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .models import (Company, Consultation, Customer, Event, RawCard, ReviewItem, RawRecording, Visit)

CAT_GENERAL, CAT_CONSULT, CAT_REVIEW = "일반 방문객", "상담 고객", "확인 필요 고객"


def review_customer_ids(s: Session) -> set[str]:
    ids = set()
    for a, b in s.execute(select(ReviewItem.customer_id, ReviewItem.candidate_customer_id)
                          .where(ReviewItem.status == "open", ReviewItem.kind == "match")).all():
        ids.add(a)
    return {i for i in ids if i}


def event_order(s: Session) -> dict[str, tuple]:
    return {e.id: (e.start_date or e.created_at, e.id) for e in s.scalars(select(Event))}


def visit_index(s: Session) -> dict[str, list[str]]:
    """고객별 방문 행사 목록 (행사 시작일 순)."""
    order = event_order(s)
    idx: dict[str, list[str]] = defaultdict(list)
    for v in s.scalars(select(Visit).where(Visit.active.is_(True))):
        idx[v.customer_id].append(v.event_id)
    for cid in idx:
        idx[cid].sort(key=lambda e: order.get(e, (datetime.max, e)))
    return idx


def consulted_pairs(s: Session) -> set[tuple[str, str]]:
    return {(c, e) for c, e in s.execute(select(Consultation.customer_id, Consultation.event_id)
                                         .where(Consultation.event_id.is_not(None))).all()}


def classify_event(s: Session, event_id: str) -> list[dict]:
    review = review_customer_ids(s)
    consulted = consulted_pairs(s)
    vidx = visit_index(s)
    rows = []
    for v in s.scalars(select(Visit).where(Visit.event_id == event_id, Visit.active.is_(True))):
        c = s.get(Customer, v.customer_id)
        if c is None or c.status != "active":
            continue
        cat = CAT_REVIEW if c.id in review else (CAT_CONSULT if (c.id, event_id) in consulted else CAT_GENERAL)
        evs = vidx.get(c.id, [])
        is_new = bool(evs) and evs[0] == event_id
        rows.append({"visit": v, "customer": c, "category": cat, "is_new": is_new,
                     "is_revisit": len(evs) >= 2, "events": evs})
    return rows


def event_summary(s: Session, event_id: str) -> dict:
    rows = classify_event(s, event_id)
    out = {"visitors": len(rows), CAT_GENERAL: 0, CAT_CONSULT: 0, CAT_REVIEW: 0, "new": 0, "existing": 0,
           "revisit": 0}
    for r in rows:
        out[r["category"]] += 1
        out["new" if r["is_new"] else "existing"] += 1
        out["revisit"] += 1 if r["is_revisit"] else 0
    out["ocr_pending"] = s.scalar(select(func.count()).select_from(RawCard)
                                  .where(RawCard.event_id == event_id, RawCard.ocr_status == "pending",
                                         RawCard.purged_at.is_(None))) or 0
    out["stt_pending"] = s.scalar(select(func.count()).select_from(RawRecording)
                                  .where(RawRecording.event_id == event_id, RawRecording.stt_status == "pending",
                                         RawRecording.purged_at.is_(None))) or 0
    return out


def dashboard(s: Session) -> dict:
    active = Customer.status == "active"
    vidx = visit_index(s)
    total = s.scalar(select(func.count()).select_from(Customer).where(active)) or 0
    revisit = sum(1 for evs in vidx.values() if len(evs) >= 2)
    return {
        "customers": total,
        "companies": s.scalar(select(func.count()).select_from(Company).where(Company.status == "active")) or 0,
        "events": s.scalar(select(func.count()).select_from(Event)) or 0,
        "consultations": s.scalar(select(func.count()).select_from(Consultation)) or 0,
        "reviews": s.scalar(select(func.count()).select_from(ReviewItem).where(ReviewItem.status == "open")) or 0,
        "revisit": revisit,
        "domestic": s.scalar(select(func.count()).select_from(Customer).where(active, Customer.is_domestic.is_(True))) or 0,
        "overseas": s.scalar(select(func.count()).select_from(Customer).where(active, Customer.is_domestic.is_(False))) or 0,
        "ocr_pending": s.scalar(select(func.count()).select_from(RawCard).where(RawCard.ocr_status == "pending",
                                                                               RawCard.purged_at.is_(None))) or 0,
        "ai_pending": s.scalar(select(func.count()).select_from(Consultation).where(Consultation.ai_status == "대기")) or 0,
    }
