"""고객 매칭 · 통합 · 분리 (M3). AI를 쓰지 않는 점수 규칙 방식.

흐름: RAW 1건 → 사람 정보(PersonRecord) → 기존 고객 후보와 점수 비교
     → 자동 통합 / 확인 필요(임시 고객 생성 + 확인 목록) / 신규 고객
모든 판정은 match_decisions 에 근거와 함께 기록되고, merge_history 로 되돌릴 수 있습니다.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from rapidfuzz import fuzz
from sqlalchemy import delete, false, or_, select, tuple_
from sqlalchemy.orm import Session

from . import db
from .models import (CUSTOMER_REF_MODELS, RAW_LABEL, RAW_MODELS, Company, CompanyAlias, Consultation, Customer,
                     CustomerIdentifier, MatchDecision, MergeHistory, RawCard, RawLink, RawNote, RawQrRow,
                     RawRecording, ReviewItem, Visit, now)
from .normalize import (clean, company_key, corporate_domain, country_from_code, email_is_generic, has_hangul,
                        key_script, name_keys, name_ko_exact, norm_country, norm_email, norm_phone, pretty_phone,
                        split_multi, split_name_field)
from .settings import get_settings

STRONG_KINDS = ("email", "mobile")
PRIORITY = {"card": 3, "qr": 2, "note": 1, "recording": 0, "other": 0}


class MatchError(Exception):
    pass


# ───────────────────────── 사람 정보 ─────────────────────────
@dataclass
class PersonRecord:
    raw_type: str
    raw_id: str
    event_id: str | None
    name_ko: str = ""
    name_en: str = ""
    company: str = ""
    company_en: str = ""
    department: str = ""
    title: str = ""
    emails: list = field(default_factory=list)
    phones: list = field(default_factory=list)
    country: str = ""
    seen_at: datetime | None = None
    hint_customer_id: str | None = None
    pending: bool = False  # 명함 OCR 대기 등: 아직 처리하지 않음

    def has_identity(self) -> bool:
        return bool(self.name_ko or self.name_en or self.emails or self.phones)


def _names(*values) -> tuple[str, str]:
    ko = en = ""
    for v in values:
        k, e = split_name_field(v)
        ko = ko or k
        en = en or e
    return ko, en


def record_for(s: Session, raw_type: str, raw_id: str) -> PersonRecord | None:
    r = s.get(RAW_MODELS[raw_type], raw_id)
    if r is None or r.purged_at:
        return None
    if raw_type == "qr":
        ko, en = _names(r.name, r.name_en)
        return PersonRecord("qr", r.id, r.event_id, ko, en, r.company or "", "", r.department or "", r.title or "",
                            split_multi(r.email), split_multi(r.mobile) + split_multi(r.phone), r.country or "",
                            r.scanned_at)
    if raw_type == "card":
        ko, en = _names(r.name, r.name_en)
        return PersonRecord("card", r.id, r.event_id, ko, en, r.company or "", r.company_en or "", r.department or "",
                            r.title or "", split_multi(r.email), split_multi(r.mobile) + split_multi(r.phone),
                            r.country or "", r.captured_at, pending=(r.ocr_status == "pending"))
    if raw_type == "note":
        ko, en = _names(r.name)
        return PersonRecord("note", r.id, r.event_id, ko, en, r.company or "", emails=split_multi(r.email),
                            phones=split_multi(r.mobile), seen_at=r.consulted_at, hint_customer_id=r.customer_id_hint)
    if raw_type == "recording":
        ko, en = _names(r.name)
        return PersonRecord("recording", r.id, r.event_id, ko, en, r.company or "", seen_at=r.recorded_at,
                            hint_customer_id=r.customer_id_hint)
    if raw_type == "other":
        return PersonRecord("other", r.id, r.event_id, seen_at=r.created_at, hint_customer_id=r.customer_id_hint)
    return None


# ───────────────────────── 식별 정보 ─────────────────────────
def identifiers_for(rec: PersonRecord) -> list[tuple[str, str]]:
    out: list[tuple[str, str]] = []
    region = norm_country(rec.country)[1]
    for e in rec.emails:
        ne = norm_email(e)
        if ne:
            out.append(("email_generic" if email_is_generic(ne) else "email", ne))
            d = corporate_domain(ne)
            if d:
                out.append(("domain", d))
    for ph in rec.phones:
        n = norm_phone(ph, region)
        if n:
            out.append(("mobile" if n[1] else "landline", n[0]))
    for k in name_keys(rec.name_ko, rec.name_en):
        out.append(("name_key", k))
    if rec.name_ko:
        out.append(("name_ko", name_ko_exact(rec.name_ko)))
    for c in (rec.company, rec.company_en):
        k = company_key(c)
        if k:
            out.append(("company_key", k))
    if clean(rec.department):
        out.append(("dept", clean(rec.department).lower()))
    if clean(rec.title):
        out.append(("title", clean(rec.title).lower()))
    return list(dict.fromkeys(out))


@dataclass
class Features:
    ids: dict  # kind -> set(values)
    seen: list  # [(event_id, datetime)]

    def get(self, kind: str) -> set:
        return self.ids.get(kind, set())


def _features(pairs, seen) -> Features:
    ids: dict[str, set] = {}
    for k, v in pairs:
        ids.setdefault(k, set()).add(v)
    return Features(ids, seen)


def record_features(rec: PersonRecord) -> Features:
    return _features(identifiers_for(rec), [(rec.event_id, rec.seen_at)] if rec.event_id and rec.seen_at else [])


def customer_features(s: Session, cid: str) -> Features:
    pairs = [(i.kind, i.value) for i in s.scalars(select(CustomerIdentifier).where(CustomerIdentifier.customer_id == cid))]
    seen = [(l.event_id, l.seen_at) for l in s.scalars(select(RawLink).where(RawLink.customer_id == cid))
            if l.event_id and l.seen_at]
    return _features(pairs, seen)


# ───────────────────────── 점수 계산 ─────────────────────────
def score(a: Features, b: Features, cfg: dict) -> tuple[int, bool, list[dict]]:
    ev: list[dict] = []
    total = 0
    strong = False

    def add(points: int, item: str, detail: str = ""):
        nonlocal total
        total += points
        ev.append({"항목": item, "점수": points, "설명": detail})

    # 이메일
    if a.get("email") & b.get("email"):
        strong = True
        add(60, "이메일 일치", ", ".join(sorted(a.get("email") & b.get("email"))))
    elif a.get("email_generic") & b.get("email_generic"):
        add(15, "공용 이메일 일치", "info@ 같은 공용 주소는 약한 근거로만 사용")
    elif a.get("email") and b.get("email"):
        add(-40, "이메일 불일치", "두 자료의 개인 이메일이 서로 다름")
    # 휴대폰
    if a.get("mobile") & b.get("mobile"):
        strong = True
        add(50, "휴대폰 일치", ", ".join(pretty_phone(x) for x in sorted(a.get("mobile") & b.get("mobile"))))
    elif a.get("mobile") and b.get("mobile"):
        add(-30, "휴대폰 불일치", "두 자료의 휴대폰 번호가 서로 다름")
    if a.get("landline") & (b.get("landline") | b.get("mobile")) or b.get("landline") & a.get("mobile"):
        add(10, "사무실/대표 번호 일치", "대표번호는 여러 직원이 공유할 수 있어 약한 근거")
    # 이름
    an, bn = a.get("name_key"), b.get("name_key")
    if (an & bn) or (a.get("name_ko") & b.get("name_ko")):
        add(20, "이름 일치", "한글/영문 표기 차이 포함")
    elif an and bn:
        best = max(fuzz.ratio(x.replace("|", ""), y.replace("|", "")) for x in an for y in bn)
        if best >= 90:
            add(10, "이름 유사", f"유사도 {best:.0f}%")
        else:
            add(-20, "이름 불일치", f"유사도 {best:.0f}%")
    # 회사
    ac, bc = a.get("company_key"), b.get("company_key")
    if ac & bc:
        add(20, "회사명 일치", "㈜/Co.,Ltd. 등 표기 차이 제외")
    elif a.get("domain") & b.get("domain"):
        add(15, "회사 이메일 도메인 일치", ", ".join(sorted(a.get("domain") & b.get("domain"))))
    elif ac and bc and any(key_script(x) == key_script(y) for x in ac for y in bc):
        def sim(x, y):
            r = fuzz.ratio(x, y)
            if min(len(x), len(y)) >= 4:  # '서울테크대학교' ⊂ '서울테크대학교산학협력단' 같은 경우
                r = max(r, fuzz.partial_ratio(x, y))
            return r
        best = max(sim(x, y) for x in ac for y in bc)
        if best >= 85:
            add(10, "회사명 유사", f"유사도 {best:.0f}%")
        else:
            add(-10, "회사명 다름", "같은 언어 표기인데 회사명이 다름")
    # 부서/직급
    if (a.get("dept") & b.get("dept")) or (a.get("title") & b.get("title")):
        add(5, "부서·직급 일치")
    # 같은 행사에서 시간 근접
    window = cfg["matching"]["time_window_min"] * 60
    for ea, ta in a.seen:
        if any(ea == eb and abs((ta - tb).total_seconds()) <= window for eb, tb in b.seen):
            add(10, "같은 행사·시간 근접", f"±{cfg['matching']['time_window_min']}분 이내 (보조 근거)")
            break
    return total, strong, ev


def decide(total: int, strong: bool, cfg: dict) -> str:
    m = cfg["matching"]
    if total >= m["auto_merge_min"] and strong:
        return "auto_merge"
    if total >= m["review_min"]:
        return "review"
    return "new"


def find_candidates(s: Session, feats: Features, limit: int = 300) -> list[str]:
    keys = [(k, v) for k in ("email", "email_generic", "mobile", "landline", "name_key", "name_ko", "domain")
            for v in feats.get(k)]
    if not keys:
        return []
    rows = s.execute(
        select(CustomerIdentifier.customer_id).join(Customer, Customer.id == CustomerIdentifier.customer_id)
        .where(tuple_(CustomerIdentifier.kind, CustomerIdentifier.value).in_(keys), Customer.status == "active")
        .distinct().limit(limit)).all()
    return [r[0] for r in rows]


# ───────────────────────── 고객 생성/갱신 ─────────────────────────
def active_customer(s: Session, cid: str | None) -> Customer | None:
    c = s.get(Customer, cid) if cid else None
    guard = 0
    while c is not None and c.status == "merged" and c.merged_into and guard < 20:
        c = s.get(Customer, c.merged_into)
        guard += 1
    return c if c is not None and c.status == "active" else None


def create_customer(s: Session) -> Customer:
    c = Customer(id=db.next_id(s, "CUS"), status="active", created_at=now(), updated_at=now(), overrides={})
    s.add(c)
    s.flush()
    return c


def resolve_company(s: Session, names: list[str], domain: str = "") -> Company | None:
    names = [clean(n) for n in names if clean(n)]
    keys = [company_key(n) for n in names if company_key(n)]
    comp = None
    for k in keys:
        comp = s.scalar(select(Company).join(CompanyAlias, CompanyAlias.company_id == Company.id)
                        .where(CompanyAlias.alias_key == k, Company.status == "active"))
        if comp:
            break
    if comp is None and domain:
        comp = s.scalar(select(Company).where(Company.domain == domain, Company.status == "active"))
    if comp is None:
        if not names:
            return None
        ko = next((n for n in names if has_hangul(n)), "")
        en = next((n for n in names if not has_hangul(n)), "")
        comp = Company(id=db.next_id(s, "COM"), name=ko or en, name_en=en or None, domain=domain or None,
                       created_at=now())
        s.add(comp)
        s.flush()
    # 별칭 학습: 이 회사에 아직 없는 표기를 추가 (다른 회사가 이미 쓰는 표기는 제외)
    for n in names:
        k = company_key(n)
        if not k:
            continue
        owner = s.scalar(select(CompanyAlias.company_id).where(CompanyAlias.alias_key == k))
        if owner is None:
            s.add(CompanyAlias(company_id=comp.id, alias=n, alias_key=k, source="auto"))
    if domain and not comp.domain:
        comp.domain = domain
    if not comp.name_en:
        comp.name_en = next((n for n in names if not has_hangul(n)), None)
    s.flush()
    return comp


def links_of(s: Session, cid: str) -> list[RawLink]:
    return list(s.scalars(select(RawLink).where(RawLink.customer_id == cid).order_by(RawLink.id)))


def rebuild_identifiers(s: Session, cid: str) -> None:
    s.execute(delete(CustomerIdentifier).where(CustomerIdentifier.customer_id == cid,
                                               CustomerIdentifier.raw_link_id.is_not(None)))
    for link in links_of(s, cid):
        rec = record_for(s, link.raw_type, link.raw_id)
        if rec is None:
            continue
        for kind, value in identifiers_for(rec):
            s.add(CustomerIdentifier(customer_id=cid, kind=kind, value=value, raw_link_id=link.id))
    s.flush()


def refresh_profile(s: Session, cust: Customer) -> None:
    recs = []
    for link in links_of(s, cust.id):
        r = record_for(s, link.raw_type, link.raw_id)
        if r:
            recs.append(r)
    recs.sort(key=lambda r: (PRIORITY.get(r.raw_type, 0), r.seen_at or datetime.min), reverse=True)

    def pick(attr):
        return next((getattr(r, attr) for r in recs if clean(getattr(r, attr))), "")

    emails = [norm_email(e) for r in recs for e in r.emails if norm_email(e)]
    email = next((e for e in emails if not email_is_generic(e)), emails[0] if emails else "")
    mobiles, lands, codes = [], [], []
    for r in recs:
        region = norm_country(r.country)[1]
        for ph in r.phones:
            n = norm_phone(ph, region)
            if n:
                (mobiles if n[1] else lands).append(n[0])
                codes.append(n[2])
    country_raw = pick("country")
    country, ccode = norm_country(country_raw)
    if not country and codes:
        ccode = codes[0]
        country = country_from_code(ccode)
    if not country and (pick("name_ko") or has_hangul(pick("company"))):
        country, ccode = "대한민국", "KR"

    cust.name_ko = pick("name_ko") or None
    cust.name_en = pick("name_en") or None
    cust.department = pick("department") or None
    cust.title = pick("title") or None
    cust.email = email or None
    cust.mobile = pretty_phone(mobiles[0]) if mobiles else None
    cust.phone = pretty_phone(lands[0]) if lands else None
    cust.country = country or None
    cust.is_domestic = (ccode == "KR") if country else None
    cust.language = "ko" if ccode == "KR" else ("en" if country else None)
    names = [r.company for r in recs if clean(r.company)] + [r.company_en for r in recs if clean(r.company_en)]
    domain = next((corporate_domain(e) for e in emails if corporate_domain(e)), "")
    comp = resolve_company(s, names, domain) if (names or domain) else None
    cust.company_id = comp.id if comp else None
    cust.company_display = (comp.name if comp else None)
    if comp and cust.country and not comp.country:
        comp.country = cust.country
    seen = [r.seen_at for r in recs if r.seen_at]
    cust.first_seen_at = min(seen) if seen else cust.first_seen_at
    for k, v in (cust.overrides or {}).items():
        if v not in (None, "") and hasattr(cust, k):
            setattr(cust, k, v)
    cust.updated_at = now()
    s.flush()


def rebuild_visits(s: Session, cid: str) -> None:
    events: dict[str, datetime | None] = {}
    for l in links_of(s, cid):
        if l.event_id:
            t = l.seen_at
            prev = events.get(l.event_id)
            events[l.event_id] = min(x for x in (prev, t) if x) if (prev or t) else None
    for c in s.scalars(select(Consultation).where(Consultation.customer_id == cid, Consultation.event_id.is_not(None))):
        events.setdefault(c.event_id, c.consulted_at)
    existing = {v.event_id: v for v in s.scalars(select(Visit).where(Visit.customer_id == cid))}
    for eid, v in existing.items():
        if eid not in events:
            v.active = False
    for eid, t in events.items():
        v = existing.get(eid)
        if v:
            v.active = True
            v.first_seen_at = t
        else:
            s.add(Visit(id=db.next_id(s, "VIS"), customer_id=cid, event_id=eid, first_seen_at=t, active=True,
                        created_at=now()))
    s.flush()


def sync_customer(s: Session, cid: str) -> None:
    cust = s.get(Customer, cid)
    if cust is None:
        return
    rebuild_identifiers(s, cid)
    if cust.status == "active":
        refresh_profile(s, cust)
    rebuild_visits(s, cid)


# ───────────────────────── 연결 ─────────────────────────
def _ensure_consultation(s: Session, note: RawNote, cid: str) -> None:
    c = s.scalar(select(Consultation).where(Consultation.raw_note_id == note.id))
    if c is None:
        s.add(Consultation(id=db.next_id(s, "CON"), customer_id=cid, event_id=note.event_id, raw_note_id=note.id,
                           channel=note.channel, consulted_at=note.consulted_at, staff_id=note.staff_id,
                           content=note.content, created_at=now()))
        s.flush()


def link_raw(s: Session, rec: PersonRecord, cid: str, decision_id: str | None) -> RawLink:
    link = RawLink(raw_type=rec.raw_type, raw_id=rec.raw_id, customer_id=cid, event_id=rec.event_id,
                   seen_at=rec.seen_at, decision_id=decision_id, linked_at=now())
    s.add(link)
    s.flush()
    if rec.raw_type == "note":
        _ensure_consultation(s, s.get(RawNote, rec.raw_id), cid)
    return link


def _describe(rec: PersonRecord) -> str:
    who = " ".join(x for x in (rec.name_ko or rec.name_en, f"({rec.company})" if rec.company else "") if x)
    return who or rec.raw_id


def process_record(s: Session, rec: PersonRecord, cfg: dict, actor: str | None = None) -> str:
    """반환: auto_merge / review / new / manual_assign / unassigned / skipped"""
    if s.scalar(select(RawLink.id).where(RawLink.raw_type == rec.raw_type, RawLink.raw_id == rec.raw_id)):
        return "skipped"
    if rec.pending:
        return "skipped"
    if rec.hint_customer_id:
        cust = active_customer(s, rec.hint_customer_id)
        if cust is None:
            raise MatchError(f"지정한 고객 {rec.hint_customer_id} 를 찾을 수 없습니다")
        md = MatchDecision(id=db.next_id(s, "MRG"), raw_type=rec.raw_type, raw_id=rec.raw_id,
                           candidate_customer_id=cust.id, chosen_customer_id=cust.id, score=None,
                           evidence=[{"항목": "담당자 직접 지정", "점수": 0, "설명": "상담 등록 시 고객을 선택함"}],
                           decision="manual_assign", decided_by=actor, decided_at=now())
        s.add(md)
        link_raw(s, rec, cust.id, md.id)
        sync_customer(s, cust.id)
        return "manual_assign"
    if not rec.has_identity():
        exists = s.scalar(select(ReviewItem.id).where(ReviewItem.kind == "unassigned", ReviewItem.raw_id == rec.raw_id,
                                                      ReviewItem.status == "open"))
        if not exists:
            s.add(ReviewItem(id=db.next_id(s, "REV"), kind="unassigned", raw_type=rec.raw_type, raw_id=rec.raw_id,
                             summary=f"{RAW_LABEL[rec.raw_type]} {rec.raw_id}: 어느 고객의 자료인지 지정이 필요합니다",
                             created_at=now()))
            s.flush()
        return "unassigned"

    feats = record_features(rec)
    best = (None, -999, False, [])
    for cid in find_candidates(s, feats):
        total, strong, ev = score(feats, customer_features(s, cid), cfg)
        if total > best[1]:
            best = (cid, total, strong, ev)
    cand, total, strong, ev = best
    decision = decide(total, strong, cfg) if cand else "new"
    md = MatchDecision(id=db.next_id(s, "MRG"), raw_type=rec.raw_type, raw_id=rec.raw_id,
                       candidate_customer_id=cand, score=total if cand else None, evidence=ev,
                       decision=decision, decided_by="자동", decided_at=now())
    s.add(md)
    if decision == "auto_merge":
        md.chosen_customer_id = cand
        link_raw(s, rec, cand, md.id)
        sync_customer(s, cand)
    else:
        new = create_customer(s)
        md.chosen_customer_id = new.id
        link_raw(s, rec, new.id, md.id)
        sync_customer(s, new.id)
        if decision == "review":
            cand_c = s.get(Customer, cand)
            s.add(ReviewItem(
                id=db.next_id(s, "REV"), kind="match", customer_id=new.id, candidate_customer_id=cand,
                raw_type=rec.raw_type, raw_id=rec.raw_id, decision_id=md.id,
                summary=(f"{_describe(rec)} — 기존 고객 {cand} {cand_c.name_ko or cand_c.name_en or ''}"
                         f"({cand_c.company_display or ''})와 동일인인지 확인 필요 ({total}점)"),
                created_at=now()))
    s.flush()
    return decision


def process_pending(s: Session, actor: str | None = None) -> dict:
    """아직 고객에 연결되지 않은 RAW를 시간순으로 모두 처리. 여러 번 실행해도 결과가 같습니다."""
    cfg = get_settings(s)
    linked = {(t, i) for t, i in s.execute(select(RawLink.raw_type, RawLink.raw_id)).all()}
    todo: list[PersonRecord] = []
    for raw_type, model in RAW_MODELS.items():
        for r in s.scalars(select(model).where(model.purged_at.is_(None))):
            if (raw_type, r.id) in linked:
                continue
            rec = record_for(s, raw_type, r.id)
            if rec:
                todo.append(rec)
    todo.sort(key=lambda r: (r.seen_at or datetime.max, PRIORITY.get(r.raw_type, 0) * -1, r.raw_id))
    counts: dict[str, int] = {}
    for rec in todo:
        result = process_record(s, rec, cfg, actor)
        counts[result] = counts.get(result, 0) + 1
    if todo:
        db.log(s, "자동 매칭", None, ", ".join(f"{k} {v}" for k, v in counts.items()), actor)
    return counts


# ───────────────────────── 통합 / 분리 ─────────────────────────
def _move(s: Session, from_cid: str, to_cid: str, link_ids: list[int] | None = None) -> dict:
    """자료를 from → to 로 이동하고 이동한 ID 목록을 반환."""
    q = select(RawLink).where(RawLink.customer_id == from_cid)
    if link_ids is not None:
        q = q.where(RawLink.id.in_(link_ids))
    links = list(s.scalars(q))
    moved = {"raw_links": [l.id for l in links]}
    for l in links:
        l.customer_id = to_cid
    note_ids = [l.raw_id for l in links if l.raw_type == "note"]
    for name, model in CUSTOMER_REF_MODELS.items():
        q2 = select(model).where(model.customer_id == from_cid)
        if link_ids is not None:
            if model is Consultation:
                q2 = q2.where(Consultation.raw_note_id.in_(note_ids or ["-"]))
            else:
                q2 = q2.where(false())
        rows = list(s.scalars(q2))
        moved[name] = [r.id for r in rows]
        for r in rows:
            r.customer_id = to_cid
    s.flush()
    return moved


def _move_back(s: Session, moved: dict, to_cid: str) -> None:
    for l in s.scalars(select(RawLink).where(RawLink.id.in_(moved.get("raw_links", []) or [-1]))):
        l.customer_id = to_cid
    for name, model in CUSTOMER_REF_MODELS.items():
        ids = moved.get(name) or []
        if ids:
            for r in s.scalars(select(model).where(model.id.in_(ids))):
                r.customer_id = to_cid
    s.flush()


def merge_customers(s: Session, src_id: str, dst_id: str, actor: str | None, reason: str = "") -> MergeHistory:
    src, dst = active_customer(s, src_id), active_customer(s, dst_id)
    if src is None or dst is None:
        raise MatchError("통합할 고객을 찾을 수 없습니다 (이미 통합/파기된 고객일 수 있음)")
    if src.id == dst.id:
        raise MatchError("같은 고객입니다")
    moved = _move(s, src.id, dst.id)
    # 열린 확인 항목 정리
    for ri in s.scalars(select(ReviewItem).where(ReviewItem.status == "open",
                                                 or_(ReviewItem.customer_id == src.id,
                                                     ReviewItem.candidate_customer_id == src.id))):
        pair = {ri.customer_id, ri.candidate_customer_id}
        if pair == {src.id, dst.id}:
            ri.status, ri.resolved_at, ri.resolved_by, ri.resolution = "resolved", now(), actor, "같은 사람 → 통합"
        else:
            if ri.customer_id == src.id:
                ri.customer_id = dst.id
            if ri.candidate_customer_id == src.id:
                ri.candidate_customer_id = dst.id
    src.status, src.merged_into, src.updated_at = "merged", dst.id, now()
    if src.overrides and not dst.overrides:
        dst.overrides = dict(src.overrides)
    hist = MergeHistory(action="merge", source_customer=src.id, target_customer=dst.id, moved=moved,
                        reason=reason, actor=actor, at=now())
    s.add(hist)
    s.add(MatchDecision(id=db.next_id(s, "MRG"), candidate_customer_id=src.id, chosen_customer_id=dst.id,
                        decision="confirmed_same", decided_by=actor, decided_at=now(),
                        evidence=[{"항목": "담당자 확인", "점수": 0, "설명": reason or "같은 사람으로 통합"}]))
    sync_customer(s, dst.id)
    sync_customer(s, src.id)
    db.log(s, "고객 통합", f"{src.id}→{dst.id}", reason, actor)
    return hist


def detach_link(s: Session, link_id: int, actor: str | None, reason: str = "") -> Customer:
    link = s.get(RawLink, link_id)
    if link is None:
        raise MatchError("연결 정보를 찾을 수 없습니다")
    orig = s.get(Customer, link.customer_id)
    if len(links_of(s, orig.id)) <= 1:
        raise MatchError("자료가 1건뿐인 고객은 분리할 수 없습니다")
    new = create_customer(s)
    moved = _move(s, orig.id, new.id, [link.id])
    s.add(MergeHistory(action="detach", source_customer=orig.id, target_customer=new.id, moved=moved,
                       reason=reason, actor=actor, at=now()))
    s.add(MatchDecision(id=db.next_id(s, "MRG"), raw_type=link.raw_type, raw_id=link.raw_id,
                        candidate_customer_id=orig.id, chosen_customer_id=new.id, decision="split",
                        decided_by=actor, decided_at=now(),
                        evidence=[{"항목": "담당자 분리", "점수": 0, "설명": reason or "잘못 통합된 자료 분리"}]))
    sync_customer(s, orig.id)
    sync_customer(s, new.id)
    db.log(s, "고객 분리", f"{orig.id}→{new.id}", f"{link.raw_type} {link.raw_id}", actor)
    return new


def undo_history(s: Session, hist_id: int, actor: str | None) -> None:
    h = s.get(MergeHistory, hist_id)
    if h is None or h.reverted_at:
        raise MatchError("되돌릴 수 없는 기록입니다 (이미 되돌렸거나 없음)")
    src, dst = s.get(Customer, h.source_customer), s.get(Customer, h.target_customer)
    if src.status == "purged" or dst.status == "purged":
        raise MatchError("파기된 고객이 포함되어 되돌릴 수 없습니다")
    _move_back(s, h.moved, src.id)
    if h.action == "merge":
        src.status, src.merged_into = "active", None
    else:  # detach 취소: 분리해서 만든 고객은 원래 고객으로 다시 합쳐짐
        if not links_of(s, dst.id):
            dst.status, dst.merged_into = "merged", src.id
    h.reverted_at = now()
    sync_customer(s, src.id)
    sync_customer(s, dst.id)
    db.log(s, "통합/분리 되돌리기", f"{h.source_customer}↔{h.target_customer}", h.action, actor)


def resolve_review(s: Session, review_id: str, same: bool, actor: str | None) -> None:
    ri = s.get(ReviewItem, review_id)
    if ri is None or ri.status != "open":
        raise MatchError("이미 처리된 항목입니다")
    if ri.kind != "match":
        raise MatchError("이 항목은 고객 지정이 필요합니다")
    if same:
        # 기존 고객(후보) 쪽으로 합침
        merge_customers(s, ri.customer_id, ri.candidate_customer_id, actor, f"확인 필요 {ri.id}: 같은 사람")
    else:
        ri.status, ri.resolved_at, ri.resolved_by, ri.resolution = "resolved", now(), actor, "다른 사람"
        s.add(MatchDecision(id=db.next_id(s, "MRG"), candidate_customer_id=ri.candidate_customer_id,
                            chosen_customer_id=ri.customer_id, decision="confirmed_distinct", decided_by=actor,
                            decided_at=now(), evidence=[{"항목": "담당자 확인", "점수": 0, "설명": f"{ri.id}: 다른 사람"}]))
        db.log(s, "확인 필요 처리", ri.id, "다른 사람", actor)
    s.flush()


def assign_raw(s: Session, review_id: str, customer_id: str, actor: str | None) -> None:
    ri = s.get(ReviewItem, review_id)
    if ri is None or ri.status != "open" or ri.kind != "unassigned":
        raise MatchError("처리할 수 없는 항목입니다")
    cust = active_customer(s, customer_id)
    if cust is None:
        raise MatchError(f"고객 {customer_id} 를 찾을 수 없습니다")
    rec = record_for(s, ri.raw_type, ri.raw_id)
    md = MatchDecision(id=db.next_id(s, "MRG"), raw_type=ri.raw_type, raw_id=ri.raw_id,
                       candidate_customer_id=cust.id, chosen_customer_id=cust.id, decision="manual_assign",
                       decided_by=actor, decided_at=now(),
                       evidence=[{"항목": "담당자 직접 지정", "점수": 0, "설명": ri.id}])
    s.add(md)
    link_raw(s, rec, cust.id, md.id)
    sync_customer(s, cust.id)
    ri.status, ri.resolved_at, ri.resolved_by, ri.resolution = "resolved", now(), actor, f"{cust.id} 지정"
    s.flush()


def set_overrides(s: Session, cid: str, values: dict, actor: str | None) -> None:
    cust = active_customer(s, cid)
    if cust is None:
        raise MatchError("고객을 찾을 수 없습니다")
    ov = dict(cust.overrides or {})
    for k, v in values.items():
        v = clean(v)
        if v:
            ov[k] = v
        else:
            ov.pop(k, None)
    cust.overrides = ov
    sync_customer(s, cust.id)
    db.log(s, "고객 정보 수정", cust.id, ", ".join(values.keys()), actor)
