"""화면 버튼과 연결되는 업무 처리 묶음: 저장 → 자동 매칭 → 엑셀 갱신."""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import select
from sqlalchemy.orm import Session

from . import db, excel_export, matching, paths
from .models import Event, Staff, now
from .normalize import clean, parse_dt

EVENT_TYPES = ["전시회", "성과교류회", "비즈니스 미팅", "세미나", "기타"]
EVENT_STATUSES = ["준비", "진행", "종료", "상담등록완료"]


def create_event(s: Session, name: str, type_: str, start: str, end: str, location: str, memo: str,
                 actor: str | None) -> Event:
    name = clean(name)
    if not name:
        raise ValueError("행사명을 입력해 주세요")
    sd, ed = parse_dt(start), parse_dt(end)
    year = (sd or now()).year
    eid = db.next_event_id(s, year)
    ev = Event(id=eid, name=name, type=type_ if type_ in EVENT_TYPES else "기타", start_date=sd, end_date=ed or sd,
               location=clean(location) or None, memo=clean(memo) or None,
               folder_name=f"{eid}_{paths.safe_filename(name, 60)}", status="준비", created_at=now())
    s.add(ev)
    s.flush()
    paths.ensure_event_folders(ev.folder_name)
    db.log(s, "행사 등록", eid, name, actor)
    return ev


def set_event_status(s: Session, event_id: str, status: str, actor: str | None) -> Event:
    ev = s.get(Event, event_id)
    if ev is None or status not in EVENT_STATUSES:
        raise ValueError("행사 또는 상태가 올바르지 않습니다")
    ev.status = status
    if status == "상담등록완료":
        ev.consult_closed_at = now()
    db.log(s, "행사 상태 변경", event_id, status, actor)
    return ev


def after_ingest(s: Session, event_ids: list[str | None], actor: str | None) -> tuple[dict, list[str]]:
    counts = matching.process_pending(s, actor)
    s.flush()
    warns = excel_export.refresh_all(s, [e for e in event_ids if e])
    return counts, warns


def ensure_default_staff(s: Session) -> None:
    if s.scalar(select(Staff.id).limit(1)) is None:
        s.add(Staff(id="STF-001", name="관리자", role="관리자", active=True, created_at=now()))
        s.flush()


def add_staff(s: Session, name: str, email: str, phone: str, role: str) -> Staff:
    name = clean(name)
    if not name:
        raise ValueError("담당자 이름을 입력해 주세요")
    st = Staff(id=db.next_id(s, "STF", 3), name=name, email=clean(email) or None, phone=clean(phone) or None,
               role=role if role in ("관리자", "영업", "조회") else "영업", active=True, created_at=now())
    s.add(st)
    s.flush()
    return st


def counts_message(counts: dict) -> str:
    labels = {"auto_merge": "기존 고객에 자동 통합", "new": "신규 고객", "review": "확인 필요",
              "manual_assign": "지정 고객에 연결", "unassigned": "고객 지정 필요", "skipped": "대기"}
    parts = [f"{labels.get(k, k)} {v}건" for k, v in counts.items() if k != "skipped"]
    return " · ".join(parts) if parts else "새로 처리할 자료 없음"
