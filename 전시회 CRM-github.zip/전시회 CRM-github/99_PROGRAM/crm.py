"""LICHTZEN CRM 실행 파일. 사용법: python crm.py -h"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from app.cli import main  # noqa: E402

if __name__ == "__main__":
    sys.exit(main())
