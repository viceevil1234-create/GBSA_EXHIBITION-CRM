import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))  # 99_PROGRAM
sys.path.insert(0, str(Path(__file__).resolve().parent))


@pytest.fixture()
def base(tmp_path, monkeypatch):
    """테스트마다 빈 임시 업무 폴더 사용 (실제 데이터와 완전히 분리)."""
    monkeypatch.setenv("LICHTZEN_BASE", str(tmp_path / "전시회 crm 테스트"))
    from app import db, paths
    db.reset_engine()
    paths.ensure_folders()
    db.init_db()
    yield paths.base_dir()
    db.reset_engine()


@pytest.fixture()
def s(base):
    from app import db, services
    sess = db.new_session()
    services.ensure_default_staff(sess)
    sess.commit()
    yield sess
    sess.close()
