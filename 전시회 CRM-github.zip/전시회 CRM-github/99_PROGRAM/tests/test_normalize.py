from app.normalize import company_key, name_keys, norm_email, norm_phone, parse_dt


def test_phone_formats_same_number():
    forms = ["010-1234-5678", "01012345678", "010 1234 5678", "+82 10-1234-5678", "82-10-1234-5678",
             "+82 (0)10 1234 5678", "1012345678"]
    results = {norm_phone(f)[0] for f in forms}
    assert results == {"+821012345678"}
    assert norm_phone("010-1234-5678")[1] is True          # 휴대폰
    assert norm_phone("02-555-1000")[1] is False            # 사무실 번호
    assert norm_phone("+81 90-1234-5678")[0] == "+819012345678"
    assert norm_phone("abc") is None


def test_company_legal_forms():
    assert company_key("에이스광학 주식회사") == company_key("에이스광학㈜") == company_key("(주)에이스광학") == "에이스광학"
    assert company_key("ACE Optics Co., Ltd.") == company_key("Ace Optics Co.,Ltd") == "aceoptics"
    assert company_key("BrightCure, Inc.") == company_key("BrightCure Inc") == "brightcure"


def test_korean_english_name_match():
    assert name_keys("홍길동", "") & name_keys("", "Gil-dong Hong")
    assert name_keys("홍길동", "") & name_keys("", "HONG Gil Dong")
    assert name_keys("정수빈", "") & name_keys("", "Jeong Subin")
    assert name_keys("김민수", "") & name_keys("", "Minsoo Kim")
    assert name_keys("", "Sarah Miller") & name_keys("", "Miller, Sarah")
    assert not (name_keys("홍길동", "") & name_keys("김길동", ""))


def test_email_and_dates():
    assert norm_email(" GD.Hong@AceOptics.co.kr ") == "gd.hong@aceoptics.co.kr"
    assert norm_email("not-an-email") == ""
    assert parse_dt("2026. 10. 14. 오후 2:30:00").hour == 14
    assert parse_dt("2026/10/14 09:05").minute == 5
    assert parse_dt(46309.5).year == 2026  # 엑셀 날짜 숫자
