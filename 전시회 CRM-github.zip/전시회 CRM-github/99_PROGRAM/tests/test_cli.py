"""명령 프로그램(crm.py) 검증: Claude Code가 실제로 실행할 명령들."""
import re

from demo_data import E1_QR, E1_QR_HEADERS, make_xlsx

from app import paths
from app.cli import main


def run(capsys, *args):
    code = main(list(args))
    out = capsys.readouterr().out
    return code, out


def test_cli_workflow(base, capsys):
    assert run(capsys, "demo")[0] == 0
    code, out = run(capsys, "status")
    assert code == 0 and "전체 고객" in out and "EVT-2026-001" in out

    code, out = run(capsys, "event", "show", "EVT-2026-001", "--cat", "일반")
    assert code == 0 and "일반 방문객" in out

    code, out = run(capsys, "customer", "search", "홍길동")
    cid = re.search(r"CUS-\d{6}", out).group(0)
    code, out = run(capsys, "customer", "show", cid)
    assert "222nm" in out and "254nm" in out and "이메일 일치" in out and "같은 기업" not in out

    # 전화번호 검색 (형식 무관)
    code, out = run(capsys, "customer", "search", "01012345678")
    assert cid in out

    code, out = run(capsys, "review", "list")
    rev = re.search(r"\[(REV-\d{6})\]", out).group(1)
    assert "판단 근거" in out
    assert run(capsys, "review", "different", rev)[0] == 0

    code, out = run(capsys, "activity", cid, "--type", "전화 상담", "--text", "샘플 일정 문의")
    assert code == 0
    code, out = run(capsys, "customer", "show", cid, "--brief")
    assert "샘플 일정 문의" in out

    code, out = run(capsys, "customer", "edit", cid, "title=수석연구원")
    assert code == 0
    assert "수석연구원" in run(capsys, "customer", "show", cid, "--brief")[1]

    code, out = run(capsys, "import", "note", "--customer", cid, "--channel", "전화 상담", "--text", "견적 진행 상황 문의")
    assert code == 0 and cid in out

    code, out = run(capsys, "import", "recording", "x.m4a")
    assert code == 1  # 동의 없음 / 파일 없음 → 실패


def test_inbox(base, capsys):
    run(capsys, "event", "add", "--name", "테스트 전시회", "--start", "2026-10-14")
    inbox = paths.p("00_START_HERE", "INBOX")
    (inbox / "qr.xlsx").write_bytes(make_xlsx(E1_QR_HEADERS, E1_QR))
    (inbox / "card1.jpg").write_bytes(b"\xff\xd8fakejpg")
    (inbox / "memo.txt").write_text("메모", encoding="utf-8")
    (inbox / "voice.m4a").write_bytes(b"fake")
    code, out = run(capsys, "inbox", "--dry-run")
    assert "행사가 지정되지 않아" in out
    code, out = run(capsys, "inbox", "EVT-2026-001")
    assert code == 0 and "QR 12행 추가" in out and "OCR 대기" in out and "동의 확인이 필요" in out
    assert (inbox / "voice.m4a").exists()          # 녹음은 그대로 남김
    assert not (inbox / "qr.xlsx").exists()
    assert list((inbox / "_처리완료").rglob("처리_qr.xlsx"))
    code, out = run(capsys, "status")
    assert "INBOX 미처리 파일: 1개" in out


def test_purge_requires_admin_and_confirm(base, capsys):
    run(capsys, "demo")
    code, out = run(capsys, "customer", "search", "정수빈")
    cid = re.search(r"CUS-\d{6}", out).group(0)
    assert run(capsys, "purge", cid, "--reason", "삭제 요청", "--confirm", "CUS-999999")[0] == 1
    run(capsys, "staff", "--add", "김영업")
    assert run(capsys, "--by", "김영업", "purge", cid, "--reason", "삭제 요청", "--confirm", cid)[0] == 1
    code, out = run(capsys, "purge", cid, "--reason", "삭제 요청", "--confirm", cid)
    assert code == 0 and "파기 완료" in out
    assert "파기된 고객" in run(capsys, "customer", "show", cid)[1]


def test_settings_and_backup(base, capsys):
    code, out = run(capsys, "settings", "--set", "ai.task_models.card_ocr=claude-haiku-5-5", "retention_years=3")
    assert "명함 OCR: claude-haiku-5-5" in out and "보존기간: 3년" in out and "claude-sonnet-5-5" in out
    assert "AI 모드: manual" in out and "API 호출 승인: False" in out
    code, out = run(capsys, "backup")
    name = re.search(r"LICHTZEN_backup_\S+\.zip", out).group(0)
    assert run(capsys, "restore", name)[0] == 1     # --yes 없으면 거부
    assert run(capsys, "restore", name, "--yes")[0] == 0
