"""가상 전시회 2개로 수집 → 매칭 → 통합/분리 → 파기 → 엑셀 → 백업을 검증."""
import pytest
from openpyxl import load_workbook
from sqlalchemy import func, select

from app import backup, excel_export, ingest, matching, paths, privacy, stats
from app.models import (Consultation, Customer, MergeHistory, RawFile, RawLink, RawQrRow, ReviewItem)
from demo_data import E1_QR, E1_QR_HEADERS, load_demo, make_xlsx


def active(s):
    return list(s.scalars(select(Customer).where(Customer.status == "active")))


def by_name(s, name, company_part=None):
    out = [c for c in active(s) if c.name_ko == name or c.name_en == name]
    if company_part:
        out = [c for c in out if company_part in (c.company_display or "")]
    return out


def open_reviews(s):
    return list(s.scalars(select(ReviewItem).where(ReviewItem.status == "open")))


@pytest.fixture()
def demo(s):
    info = load_demo(s)
    s.commit()
    return info


def test_folders_and_db_created(base):
    for f in ("01_RAW_DATA/00_ALL_EVENTS", "04_OFFICIAL_DOCUMENTS/99_INTERNAL_ONLY", "11_DATABASE"):
        assert (base / f).is_dir()
    assert (base / "11_DATABASE" / "lichtzen_crm.db").exists()


def test_event_folders(demo, base):
    ev_dirs = [d.name for d in (base / "01_RAW_DATA").iterdir() if d.name.startswith("EVT-")]
    assert len(ev_dirs) == 2
    assert (base / "01_RAW_DATA" / ev_dirs[0] / "02_BUSINESS_CARDS").is_dir()


def first_qr_file_bytes(s):
    rf = s.scalar(select(RawFile).where(RawFile.kind == "qr").order_by(RawFile.id))
    return paths.absolute(rf.stored_path).read_bytes()


def test_duplicate_upload_blocked(s, demo):
    data = first_qr_file_bytes(s)
    with pytest.raises(ingest.IngestError, match="이미 업로드된 파일"):
        ingest.ingest_qr(s, demo["e1"], "다른이름.xlsx", data, None)
    # 기존 행 + 새 1행이 든 다른 파일 → 새 행만 추가
    rows = E1_QR + [[13, "신규방문", "테스트상사", "", "", "new@test-demo.kr", "010-9999-0000", "", "2026-10-16 16:00", ""]]
    res = ingest.ingest_qr(s, demo["e1"], "추가본.xlsx", make_xlsx(E1_QR_HEADERS, rows), None)
    assert res["added"] == 1 and res["skipped"] == len(E1_QR)


def test_reprocessing_is_idempotent(s, demo):
    before = len(active(s))
    links = s.scalar(select(func.count()).select_from(RawLink))
    assert matching.process_pending(s) == {}
    assert len(active(s)) == before
    assert s.scalar(select(func.count()).select_from(RawLink)) == links


def test_same_person_merged_across_sources_and_events(s, demo):
    hong = by_name(s, "홍길동")
    assert len(hong) == 1, "QR 2회 + 명함 + 상담 + 2차 행사 QR·상담이 모두 한 사람"
    h = hong[0]
    assert h.name_en == "Gil-dong Hong"              # 명함에서 영문명 학습
    assert h.mobile == "010-1234-5678" and h.phone == "02-555-1000"
    links = matching.links_of(s, h.id)
    assert {l.raw_type for l in links} == {"qr", "card", "note"}
    assert len(links) == 6
    assert len(stats.visit_index(s)[h.id]) == 2     # 재방문
    cons = list(s.scalars(select(Consultation).where(Consultation.customer_id == h.id)))
    assert len(cons) == 2                            # 1차 222nm + 2차 254nm 상담 모두 보존


def test_company_alias_learning(s, demo):
    h = by_name(s, "홍길동")[0]
    c = matching.resolve_company(s, ["ACE Optics Co., Ltd."])
    assert c.id == h.company_id                      # 영문 회사명이 같은 기업으로 인식


def test_homonyms_not_merged(s, demo):
    kims = [c for c in active(s) if c.name_ko == "김민수"]
    companies = {c.company_display for c in kims}
    assert "대성정밀" in companies and any("한빛바이오" in (x or "") for x in companies)


def test_english_name_formats_merged(s, demo):
    sarah = [c for c in active(s) if c.name_en and "Sarah" in c.name_en]
    assert len(sarah) == 1
    assert len(stats.visit_index(s)[sarah[0].id]) == 2
    assert sarah[0].is_domestic is False and sarah[0].country == "미국"


def test_uncertain_cases_go_to_review(s, demo):
    summaries = " ".join(r.summary for r in open_reviews(s))
    assert len(open_reviews(s)) == 4
    for who in ("박지영", "김민수", "이준호", "Tanaka"):
        assert who in summaries, who


def test_classification_general_vs_consult(s, demo):
    sm = stats.event_summary(s, demo["e1"])
    assert sm["visitors"] == 14
    assert sm["상담 고객"] == 2          # 홍길동, Sarah (김민수·이준호 상담은 확인 필요 상태)
    assert sm["확인 필요 고객"] == 3
    assert sm["일반 방문객"] == 9
    assert sm["visitors"] == sm["상담 고객"] + sm["확인 필요 고객"] + sm["일반 방문객"]


def test_review_same_then_undo(s, demo):
    ri = next(r for r in open_reviews(s) if "김민수" in r.summary)
    prov, cand = ri.customer_id, ri.candidate_customer_id
    matching.resolve_review(s, ri.id, True, "테스터")
    s.commit()
    assert s.get(Customer, prov).status == "merged"
    assert s.scalar(select(func.count()).select_from(Consultation).where(Consultation.customer_id == cand)) == 1
    sm = stats.event_summary(s, demo["e1"])
    assert sm["상담 고객"] == 3 and sm["visitors"] == 13
    # 되돌리기
    hist = s.scalar(select(MergeHistory).where(MergeHistory.source_customer == prov))
    matching.undo_history(s, hist.id, "테스터")
    s.commit()
    assert s.get(Customer, prov).status == "active"
    assert s.scalar(select(func.count()).select_from(Consultation).where(Consultation.customer_id == prov)) == 1


def test_review_different(s, demo):
    ri = next(r for r in open_reviews(s) if "Tanaka" in r.summary)
    matching.resolve_review(s, ri.id, False, "테스터")
    s.commit()
    assert s.get(Customer, ri.customer_id).status == "active"
    assert len(open_reviews(s)) == 3


def test_detach_and_undo(s, demo):
    h = by_name(s, "홍길동")[0]
    card_link = next(l for l in matching.links_of(s, h.id) if l.raw_type == "card")
    new = matching.detach_link(s, card_link.id, "테스터", "테스트 분리")
    s.commit()
    assert new.name_ko == "홍길동" and len(matching.links_of(s, h.id)) == 5
    assert s.get(Customer, h.id).name_en is None      # 영문명은 명함에서만 왔음
    hist = s.scalar(select(MergeHistory).where(MergeHistory.action == "detach"))
    matching.undo_history(s, hist.id, "테스터")
    s.commit()
    assert len(matching.links_of(s, h.id)) == 6
    assert s.get(Customer, new.id).status == "merged"


def test_manual_override_survives_refresh(s, demo):
    h = by_name(s, "홍길동")[0]
    matching.set_overrides(s, h.id, {"title": "수석연구원"}, "테스터")
    matching.sync_customer(s, h.id)
    assert s.get(Customer, h.id).title == "수석연구원"


def test_raw_is_protected(s, demo):
    r = s.scalar(select(RawQrRow).limit(1))
    r.name = "변조"
    with pytest.raises(Exception, match="수정할 수 없습니다"):
        s.flush()
    s.rollback()
    with pytest.raises(Exception, match="삭제할 수 없습니다"):
        s.delete(s.scalar(select(RawQrRow).limit(1)))
        s.flush()
    s.rollback()


def test_purge_customer(s, demo, base):
    c = by_name(s, "정수빈")[0]
    qr = s.scalar(select(RawQrRow).join(RawLink, (RawLink.raw_id == RawQrRow.id) & (RawLink.raw_type == "qr"))
                  .where(RawLink.customer_id == c.id))
    rf = s.get(RawFile, qr.file_id)
    old_hash = rf.sha256
    original_bytes = paths.absolute(rf.stored_path).read_bytes()
    counts = privacy.purge_customer(s, c.id, "정보주체 삭제 요청", "관리자")
    s.commit()
    assert counts["qr"] == 1
    c2 = s.get(Customer, c.id)
    assert c2.status == "purged" and c2.email is None
    qr2 = s.get(RawQrRow, qr.id)
    assert qr2.name == privacy.MASK and "sb.jung" not in str(qr2.raw_json)
    # 원본 엑셀 파일 안의 해당 행도 마스킹
    wb = load_workbook(paths.absolute(rf.stored_path))
    ws = wb.worksheets[0]
    values = [cell.value for cell in ws[qr.row_index]]
    assert privacy.MASK in values and "정수빈" not in values
    assert any(cell.value == "홍길동" for row in ws.iter_rows() for cell in row)  # 다른 고객은 유지
    assert s.get(RawFile, rf.id).sha256 != old_hash
    # 원래 파일을 다시 올려도 차단 (파기된 사람 재등록 방지)
    with pytest.raises(ingest.IngestError):
        ingest.ingest_qr(s, demo["e1"], "재업로드.xlsx", original_bytes, None)
    s.rollback()
    # 내용이 같은 새로 저장한 파일이어도 해당 행은 중복으로 건너뜀
    res = ingest.ingest_qr(s, demo["e1"], "재저장본.xlsx", make_xlsx(E1_QR_HEADERS, E1_QR, title_rows=2), None)
    assert res["added"] == 0


def test_retention_candidates(s, demo):
    assert privacy.retention_candidates(s, 5) == []
    assert len(privacy.retention_candidates(s, 0)) == len(active(s))


def test_excel_exports(s, demo, base):
    warns = excel_export.refresh_all(s)
    assert warns == []
    master = base / "02_CUSTOMER_MASTER" / "LICHTZEN_CRM_통합관리.xlsx"
    wb = load_workbook(master)
    assert len(wb.sheetnames) == 14 and wb.sheetnames[0] == "01_전체고객통합"
    assert wb["01_전체고객통합"].max_row == len(active(s)) + 1
    raw_all = load_workbook(base / "01_RAW_DATA" / "00_ALL_EVENTS" / "RAW_전체행사.xlsx")
    assert raw_all.sheetnames[:2] == ["01_QR방문객원본", "02_명함원본"]
    assert raw_all["01_QR방문객원본"].max_row == len(E1_QR) + 6 + 1
    for f in ("전체고객통합.xlsx", "전체기업통합.xlsx"):
        assert (base / "02_CUSTOMER_MASTER" / f).exists()
    assert list((base / "08_REPORTS" / "행사별").glob("EVT-*_통합.xlsx"))
    # 두 번 실행해도 같은 결과 (중복 없음)
    excel_export.refresh_all(s)
    assert load_workbook(master)["01_전체고객통합"].max_row == len(active(s)) + 1


def test_backup_and_restore(s, demo, base):
    n = len(active(s))
    z = backup.create_backup("manual")
    assert z.exists()
    privacy.purge_customer(s, by_name(s, "오세훈")[0].id, "테스트", "관리자")
    s.commit()
    s.close()
    backup.restore_backup(z.name)
    from app import db
    s2 = db.new_session()
    assert len(list(s2.scalars(select(Customer).where(Customer.status == "active")))) == n
    s2.close()
    assert any("pre_restore" in b["name"] for b in backup.list_backups())


def test_recording_requires_consent(s, demo):
    with pytest.raises(ingest.IngestError, match="동의"):
        ingest.ingest_recording(s, demo["e1"], "a.m4a", b"fake", None, consent=False)
    rec = ingest.ingest_recording(s, demo["e1"], "a.m4a", b"fake-audio", None, consent=True, name="홍길동",
                                  company="에이스광학")
    matching.process_pending(s)
    link = s.scalar(select(RawLink).where(RawLink.raw_id == rec.id))
    assert link is not None   # 이름+회사 → 확인 필요 또는 연결
