"""가상 전시회·고객 데이터 (테스트와 데모용). 실제 인물·회사가 아닌 가상의 데이터입니다.

검증 상황:
- 같은 사람 QR 중복 스캔, QR+명함 통합(이메일·휴대폰), 한/영 이름 차이, 회사 표기 차이(㈜/Co.,Ltd.)
- 동명이인(김민수 2명, 다른 회사), 공용 이메일(info@), 정보 불일치(명함 이메일 다름)
- 재방문 고객(1차 222nm → 2차 254nm), 해외 고객, 전화번호 형식 차이(+82, 82-, 하이픈 없음)
"""
from __future__ import annotations

import io
from datetime import datetime

from openpyxl import Workbook

E1_QR_HEADERS = ["No", "성명", "회사명", "부서", "직급", "E-mail", "휴대폰", "국가", "스캔시간", "관심분야"]
E1_QR = [
    [1, "홍길동", "에이스광학 주식회사", "연구소", "책임연구원", "gd.hong@aceoptics.co.kr", "010-1234-5678", "대한민국", "2026-10-14 10:05:00", "UV LED"],
    [2, "홍길동", "에이스광학 주식회사", "연구소", "책임연구원", "gd.hong@aceoptics.co.kr", "010-1234-5678", "대한민국", "2026-10-14 15:40:00", "UV LED"],
    [3, "김민수", "(주)한빛바이오", "품질팀", "과장", "minsu.kim@hanbitbio.com", "010 2222 3333", "대한민국", "2026-10-14 11:20:00", "살균"],
    [4, "김민수", "대성정밀", "생산기술팀", "대리", "mskim@daesung-p.kr", "01098765432", "대한민국", "2026-10-15 09:50:00", "경화"],
    [5, "Sarah Miller", "BrightCure Inc.", "R&D", "Director", "sarah@brightcure.com", "+1 415 555 0134", "USA", "2026-10-15 13:10:00", "Excimer"],
    [6, "박지영", "서울테크대학교 산학협력단", "연구지원팀", "선임", "jypark@seoultech-demo.ac.kr", "010-5555-6666", "대한민국", "2026-10-15 14:00:00", ""],
    [7, "이준호", "그린테크 (주)", "영업부", "부장", "info@greentech-demo.co.kr", "", "대한민국", "2026-10-16 10:30:00", "UV LAMP"],
    [8, "Hiroshi Tanaka", "Nippon UV Co., Ltd.", "Engineering", "Manager", "tanaka@nipponuv-demo.jp", "+81 90-1234-5678", "Japan", "2026-10-16 11:00:00", "254nm"],
    [9, "정수빈", "미래환경", "", "", "sb.jung@mirae-env.co.kr", "010-3030-4040", "", "2026-10-16 13:00:00", ""],
    [10, "오세훈", "케이디전자", "개발팀", "연구원", "shoh@kd-elec.co.kr", "010-6060-7070", "", "2026-10-16 13:30:00", ""],
    [11, "윤하나", "하나메디칼", "", "대표", "hana@hanamedical-demo.com", "010-8080-9090", "", "2026-10-16 14:10:00", ""],
    [12, "강동원", "대한UV", "", "팀장", "dwkang@daehanuv-demo.kr", "010-1212-3434", "", "2026-10-16 15:00:00", ""],
]

E2_QR_HEADERS = ["Name", "Company", "Department", "Title", "Email", "Mobile", "Country", "Timestamp"]
E2_QR = [
    ["홍길동", "에이스광학㈜", "연구소", "책임연구원", "gd.hong@aceoptics.co.kr", "82-10-1234-5678", "Korea", "2026-11-18 10:00:00"],
    ["Miller, Sarah", "BrightCure, Inc.", "R&D", "Director", "sarah@brightcure.com", "+14155550134", "United States", "2026-11-18 10:30:00"],
    ["김민수", "한빛바이오", "품질팀", "차장", "minsu.kim@hanbitbio.com", "010-2222-3333", "대한민국", "2026-11-18 11:00:00"],
    ["최유진", "에코솔루션", "기획팀", "대리", "yj.choi@ecosol-demo.co.kr", "010-4444-1111", "대한민국", "2026-11-18 11:30:00"],
    ["Hiroshi Tanaka", "Nippon UV Co.,Ltd", "Engineering", "Manager", "h.tanaka@nipponuv-demo.jp", "+81-90-1234-5678", "Japan", "2026-11-18 13:00:00"],
    ["서지훈", "블루웨이브", "", "", "jh.seo@bluewave-demo.kr", "010-7878-5656", "", "2026-11-18 14:00:00"],
]

E1_CARDS = [
    # QR과 이메일·휴대폰이 같은 명함 → 자동 통합 (영문명·영문회사명 학습)
    {"name": "홍길동", "name_en": "Gil-dong Hong", "company": "에이스광학㈜", "company_en": "ACE Optics Co., Ltd.",
     "department": "연구소", "title": "책임연구원", "email": "GD.Hong@AceOptics.co.kr", "mobile": "+82 10-1234-5678",
     "phone": "02-555-1000"},
    # 휴대폰은 같지만 이메일이 다름(개인메일) → 정보 불일치 → 확인 필요
    {"name": "박지영", "company": "서울테크대학교", "email": "jiyoung.p@gmail.com", "mobile": "01055556666"},
]

E1_NOTES = [
    {"name": "홍길동", "company": "에이스광학", "mobile": "010-1234-5678", "at": "2026-10-14 10:20",
     "content": "222nm 원자외선 램프에 관심. 의료기기 표면 살균 용도. 카탈로그와 시험성적서 요청."},
    {"select": "Sarah Miller", "at": "2026-10-15 13:30",
     "content": "Interested in Excimer 172nm for surface treatment. Asked for technical datasheet."},
    {"name": "김민수", "company": "한빛바이오", "at": "2026-10-14 11:30",
     "content": "254nm UV 램프 수질 살균 적용 검토. 현재 타사 제품 사용 중, 수명 문제."},
    {"name": "이준호", "company": "그린테크", "email": "info@greentech-demo.co.kr", "at": "2026-10-16 10:40",
     "content": "UV LAMP 교체 수요. 견적 요청."},
]

E2_NOTES = [
    {"name": "홍길동", "email": "gd.hong@aceoptics.co.kr", "at": "2026-11-18 10:15",
     "content": "지난번 222nm에 이어 254nm 램프도 검토 중. 샘플 테스트 요청."},
]


def make_xlsx(headers, rows, title_rows: int = 0) -> bytes:
    wb = Workbook()
    ws = wb.active
    ws.title = "방문객"
    for i in range(title_rows):
        ws.append([f"전시회 방문객 명단 (출력일 2026-10-17)"] if i == 0 else [])
    ws.append(headers)
    for r in rows:
        ws.append(r)
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def load_demo(s, actor="데모") -> dict:
    """가상 행사 2개와 고객 데이터를 등록하고 매칭까지 실행."""
    from app import ingest, matching, services
    from app.models import Customer
    from app.normalize import parse_dt
    from sqlalchemy import select

    e1 = services.create_event(s, "2026 국제 UV 산업전", "전시회", "2026-10-14", "2026-10-16", "킨텍스", "", actor)
    e2 = services.create_event(s, "2026 광기술 성과교류회", "성과교류회", "2026-11-18", "2026-11-18", "대전", "", actor)
    ingest.ingest_qr(s, e1.id, "UV산업전_QR.xlsx", make_xlsx(E1_QR_HEADERS, E1_QR, title_rows=2), actor)
    for c in E1_CARDS:
        ingest.ingest_card(s, e1.id, None, None, c, actor, captured_at=datetime(2026, 10, 14, 10, 10))
    matching.process_pending(s, actor)

    def note(ev, n):
        cid = None
        if n.get("select"):
            cid = s.scalar(select(Customer.id).where(Customer.name_en == n["select"], Customer.status == "active"))
        ingest.ingest_note(s, ev.id, n["content"], actor, customer_id=cid, name=n.get("name", ""),
                           company=n.get("company", ""), email=n.get("email", ""), mobile=n.get("mobile", ""),
                           consulted_at=parse_dt(n["at"]), staff_id="STF-001")

    for n in E1_NOTES:
        note(e1, n)
    matching.process_pending(s, actor)
    ingest.ingest_qr(s, e2.id, "성과교류회_QR.xlsx", make_xlsx(E2_QR_HEADERS, E2_QR), actor)
    for n in E2_NOTES:
        note(e2, n)
    counts = matching.process_pending(s, actor)
    return {"e1": e1.id, "e2": e2.id, "counts": counts}
